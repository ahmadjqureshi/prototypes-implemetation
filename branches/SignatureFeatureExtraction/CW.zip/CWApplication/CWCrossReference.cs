using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CWApplication
{
	/// <summary>
	/// Summary description for CWCrossReference.
	/// </summary>
	public class CWCrossReference : System.Windows.Forms.Form
	{
		public System.Windows.Forms.DataGrid CRefernceGrid;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CWCrossReference()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.CRefernceGrid = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.CRefernceGrid)).BeginInit();
			this.SuspendLayout();
			// 
			// CRefernceGrid
			// 
			this.CRefernceGrid.AlternatingBackColor = System.Drawing.Color.LightGray;
			this.CRefernceGrid.BackColor = System.Drawing.Color.DarkGray;
			this.CRefernceGrid.CaptionBackColor = System.Drawing.Color.White;
			this.CRefernceGrid.CaptionFont = new System.Drawing.Font("Verdana", 10F);
			this.CRefernceGrid.CaptionForeColor = System.Drawing.Color.Navy;
			this.CRefernceGrid.DataMember = "";
			this.CRefernceGrid.ForeColor = System.Drawing.Color.Black;
			this.CRefernceGrid.GridLineColor = System.Drawing.Color.Black;
			this.CRefernceGrid.GridLineStyle = System.Windows.Forms.DataGridLineStyle.None;
			this.CRefernceGrid.HeaderBackColor = System.Drawing.Color.Silver;
			this.CRefernceGrid.HeaderForeColor = System.Drawing.Color.Black;
			this.CRefernceGrid.LinkColor = System.Drawing.Color.Navy;
			this.CRefernceGrid.Name = "CRefernceGrid";
			this.CRefernceGrid.ParentRowsBackColor = System.Drawing.Color.White;
			this.CRefernceGrid.ParentRowsForeColor = System.Drawing.Color.Black;
			this.CRefernceGrid.SelectionBackColor = System.Drawing.Color.Navy;
			this.CRefernceGrid.SelectionForeColor = System.Drawing.Color.White;
			this.CRefernceGrid.Size = new System.Drawing.Size(680, 360);
			this.CRefernceGrid.TabIndex = 0;
			this.CRefernceGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CRefernceGrid_KeyDown);
			this.CRefernceGrid.EnabledChanged += new System.EventHandler(this.CRefernceGrid_EnabledChanged);
			this.CRefernceGrid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CRefernceGrid_KeyPress);
			this.CRefernceGrid.Navigate += new System.Windows.Forms.NavigateEventHandler(this.CRefernceGrid_Navigate);
			this.CRefernceGrid.TextChanged += new System.EventHandler(this.CRefernceGrid_TextChanged);
			this.CRefernceGrid.CurrentCellChanged += new System.EventHandler(this.CRefernceGrid_CurrentCellChanged);
			// 
			// CWCrossReference
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(680, 357);
			this.ControlBox = false;
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.CRefernceGrid});
			this.Name = "CWCrossReference";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "CWCrossReference";
			this.Load += new System.EventHandler(this.CWCrossReference_Load);
			((System.ComponentModel.ISupportInitialize)(this.CRefernceGrid)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void CRefernceGrid_Navigate(object sender, System.Windows.Forms.NavigateEventArgs ne)
		{
			((CWApplication.Form1)(this.MdiParent)).crossrefsave = true;
			((CWApplication.Form1)(this.MdiParent)).SaveButton = true;
		}

		private void CRefernceGrid_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			
		}

		private void CRefernceGrid_TextChanged(object sender, System.EventArgs e)
		{
			
		}

		private void CWCrossReference_Load(object sender, System.EventArgs e)
		{
			if (((CWApplication.Form1)(this.MdiParent)).getverify)
			{
				this.CRefernceGrid.ReadOnly = true;
			}
			((CWApplication.Form1)(this.MdiParent)).crossrefsave = true;
			((CWApplication.Form1)(this.MdiParent)).SaveButton = true;
		}

		private void CRefernceGrid_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			((CWApplication.Form1)(this.MdiParent)).crossrefsave = true;
			((CWApplication.Form1)(this.MdiParent)).SaveButton = true;		
		}

		private void CRefernceGrid_EnabledChanged(object sender, System.EventArgs e)
		{
			((CWApplication.Form1)(this.MdiParent)).crossrefsave = true;
			((CWApplication.Form1)(this.MdiParent)).SaveButton = true;		
		}

		private void CRefernceGrid_CurrentCellChanged(object sender, System.EventArgs e)
		{
			((CWApplication.Form1)(this.MdiParent)).crossrefsave = true;
			((CWApplication.Form1)(this.MdiParent)).SaveButton = true;		
		}
	}
}
