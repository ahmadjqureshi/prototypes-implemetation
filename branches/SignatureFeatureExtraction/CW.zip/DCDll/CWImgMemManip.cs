using System;
using System.Text;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Drawing.Imaging;
using System.Windows.Forms;
using Microsoft.Win32;


namespace DCDll
{
	/// <summary>
	/// Summary description for CWImgMemManip.
	/// </summary>
	
	
	public class CWImgMemManip
	{
		/*
		 ********************************************************
		 Created by Ahmad on 25-02-2004
		 
		 Purpose:
		 Constructor of this class
		 First task is to lock memory in which image is residing 
		 so that any service of operating system get hold of image 
		 data and make any changes there
		 ********************************************************
		*/
		BITMAPINFOHEADER	bmi;
		IntPtr	dibhand;
		IntPtr	bmpptr;
		IntPtr	pixptr;

		public CWImgMemManip(IntPtr DipHand )
		{
			//
			// TODO: Add constructor logic here
			//
			dibhand = DipHand;
			bmpptr = GlobalLock( dibhand );
			pixptr = GetPixelInfo( bmpptr );

			RegistryKey Hkey = Registry.CurrentUser;
			RegistryKey sHkey = Hkey.OpenSubKey("Environment");
			string temppath = (string) sHkey.GetValue("temp");
			
			
			bool res = CWGCodecs.SaveDIBAs( temppath + "\\temp.jpeg", bmpptr, pixptr );
			
			
			
		}
		
		/*
		 ********************************************************
		 Created by Ahmad on 25-02-2004
		 
		 Purpose:
		 To get starting address of pixels in the image
		 ********************************************************
		*/
		protected IntPtr GetPixelInfo( IntPtr bmpptr )
		{
			bmi = new BITMAPINFOHEADER();
			Marshal.PtrToStructure( bmpptr, bmi );


			if( bmi.biSizeImage == 0 )
				bmi.biSizeImage = ((((bmi.biWidth * bmi.biBitCount) + 31) & ~31) >> 3) * bmi.biHeight;

			int p = bmi.biClrUsed;
			if( (p == 0) && (bmi.biBitCount <= 8) )
				p = (1 << bmi.biBitCount);
			p = (p * 4) + bmi.biSize + (int) bmpptr;
			return (IntPtr) p;
		}

		/*
		 *****************************************************
		 Created by Ahmad on 25-02-2004
		 
		 Purpose:
		 These funtions are being imported from Win32 dlls 
		 for memory management of image pixels
		 *****************************************************
		*/
		[DllImport("gdi32.dll", ExactSpelling=true)]
		internal static extern int SetDIBitsToDevice( IntPtr hdc, int xdst, int ydst,
			int width, int height, int xsrc, int ysrc, int start, int lines,
			IntPtr bitsptr, IntPtr bmiptr, int color );

		[DllImport("kernel32.dll", ExactSpelling=true)]
		internal static extern IntPtr GlobalLock( IntPtr handle );
		[DllImport("kernel32.dll", ExactSpelling=true)]
		internal static extern IntPtr GlobalFree( IntPtr handle );

		[DllImport("kernel32.dll", CharSet=CharSet.Auto) ]
		public static extern void OutputDebugString( string outstr );

	}

	[StructLayout(LayoutKind.Sequential, Pack=2)]
internal class BITMAPINFOHEADER
	{
		public int      biSize;
		public int      biWidth;
		public int      biHeight;
		public short    biPlanes;
		public short    biBitCount;
		public int      biCompression;
		public int      biSizeImage;
		public int      biXPelsPerMeter;
		public int      biYPelsPerMeter;
		public int      biClrUsed;
		public int      biClrImportant;
	}

}
