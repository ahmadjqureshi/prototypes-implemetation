using System;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;
using DCDll;
using Microsoft.Win32;



/*
 *****************************************************
 MDI Container of Capture Wise Application
 *****************************************************
*/

namespace CWApplication
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form ,IMessageFilter
	{
		
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private bool msgfilter;
		private System.Windows.Forms.MenuItem menuItem2;
		
		public System.Windows.Forms.ToolBar toolBar1;
		private System.Windows.Forms.MenuItem menuItem3;

		private System.Windows.Forms.ToolBarButton toolBarButton1;
		private System.Windows.Forms.ToolBarButton toolBarButton2;
		private System.Windows.Forms.ToolBarButton toolBarButton3;
		private System.Windows.Forms.ImageList imageList1;
		private System.ComponentModel.IContainer components;
		
		private System.Windows.Forms.ToolBarButton toolBarButton5;
		private System.Windows.Forms.ToolBarButton toolBarButton6;
		private System.Windows.Forms.ToolBarButton toolBarButton7;
		private System.Windows.Forms.ToolBarButton toolBarButton4;

		/*
		 ***********************************************
		 Following self created variables used in application
		 ***********************************************
		*/
		CWBackGroundForm bform;
		string username,domain;

		//Database Connection Reference

		CWDataAccDll.DataAccess dbconn;
		CWCaptureForm cform;
		CWInfoForm iform;
		CWApplication.CWAccountDetailsForm adform;
		bool prop,sign,maindetails,signinfo,sign1=false,sign2=false;
		
		string accountno,accounttitle,captureddate,companyname,signname;
		String currentdev;

		//Signatory information form Reference

		CWSignatoryForm sform;
		
		//Add Signatory form Reference
		AddSignatory asform;
		
		//Twain Reference
		DCDll.Twain tw;
		private System.Windows.Forms.ToolBarButton toolBarButton8;
		private System.Windows.Forms.ToolBarButton toolBarButton9;
		private System.Windows.Forms.ToolBarButton toolBarButton10;
		int identity = 0;
		private System.Windows.Forms.ToolBarButton toolBarButton14;
		
		//Sign Croping form Reference
		CWSignImage siform;
		int signno = 0;
		string sigid;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem dev1;
		private System.Windows.Forms.MenuItem dev2;
		private System.Windows.Forms.MenuItem dev3;
		private System.Windows.Forms.MenuItem dev4;
		private System.Windows.Forms.MenuItem dev5;
		private System.Windows.Forms.ToolBarButton toolBarButton11;
		private System.Windows.Forms.ToolBarButton toolBarButton12;
		private System.Windows.Forms.ToolBarButton toolBarButton13;
		string filename;
		private System.Windows.Forms.ToolBarButton toolBarButton15;
		private System.Windows.Forms.ToolBarButton toolBarButton16;
		private System.Windows.Forms.ToolBarButton toolBarButton17;
		private System.Windows.Forms.ToolBarButton toolBarButton18;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItem11;
		private System.Windows.Forms.MenuItem menuItem12;
		private System.Windows.Forms.MenuItem menuItem13;
		private System.Windows.Forms.MenuItem menuItem14;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.PictureBox pictureBox2;
		int sigcount = 0;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.TabPage tabPage4;
		private System.Windows.Forms.PictureBox pictureBox3;
		private System.Windows.Forms.PictureBox pictureBox4;
		private System.Windows.Forms.ToolBarButton toolBarButton19;
		private System.Windows.Forms.ToolBarButton toolBarButton20;
		
		string pathtemp;
		string accountdetails;
		int resx=200,resy=200;
		private System.Windows.Forms.MenuItem menuItem15;
		private System.Windows.Forms.ToolBarButton toolBarButton21;
		private System.Windows.Forms.ToolBarButton toolBarButton22;
		
		//Set Resolution of image form
		CWApplication.CWSetResolutionForm srform;
		int limit = 0;
		string grp;
		int cosignee = 0;
		string expiry_date;
		int total = 0,current = 0;
		
		// Used for keeping track of identity while navigation
		SortedList slist;
		
		bool addSignatory = false;
		private System.Windows.Forms.ToolBarButton toolBarButton23;
		
		bool onesignadded = true;

		CWCrossReference crform;
		DataTable crDataTable;
		bool dataexists = false;
		bool savecrossref = false;
		bool capture = false ,modify = false,verify = false;
		private System.Windows.Forms.ToolBarButton toolBarButton24;
		private System.Windows.Forms.ToolBarButton toolBarButton25;
		private System.Windows.Forms.ToolBarButton toolBarButton26;
		private System.Windows.Forms.ToolBarButton toolBarButton27;
		private System.Windows.Forms.ToolBarButton toolBarButton28;
		private System.Windows.Forms.ToolBarButton toolBarButton29;
		private System.Windows.Forms.ToolBarButton toolBarButton30;
		private System.Windows.Forms.ToolBarButton toolBarButton31;
		private System.Windows.Forms.ToolBarButton toolBarButton32;
		private System.Windows.Forms.ToolBarButton toolBarButton33;
		private System.Windows.Forms.ToolBarButton toolBarButton34;
		private System.Windows.Forms.ToolBarButton toolBarButton35;
		
		//Modify Form reference
		CWModifyForm mform;
		private System.Windows.Forms.ToolBarButton toolBarButton36;
		private System.Windows.Forms.ToolBarButton toolBarButton37;
		private System.Windows.Forms.ToolBarButton toolBarButton38;
		
		//Verify Form reference
		VerifyForm vform;
		private System.Windows.Forms.ToolBarButton toolBarButton39;
		private System.Windows.Forms.ToolBarButton toolBarButton40;
		private System.Windows.Forms.ToolBarButton toolBarButton41;
		private System.Windows.Forms.MenuItem menuItem16;
		private System.Windows.Forms.MenuItem menuItem17;
		private System.Windows.Forms.MenuItem menuItem18;
		private System.Windows.Forms.ToolBarButton toolBarButton42;
		private System.Windows.Forms.ProgressBar FeatureExtractionProgress;
		
		int acc =0;		

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			/*
			 * 
			 * DB connection creating
			 * 
			 *
			 */
			//connection string
			string constr = "DSN=OraConn;UID=SYSTEM;PWD=TIGER;DBA=W;APA=T;EXC=F;FEN=T;QTO=T;FRC=10;FDL=10;LOB=T;RST=T;GDE=F;FRL=F;BAM=IfAllSuccessful;MTS=F;MDI=F;CSR=F;FWC=F;PFC=10;TLO=0;";
			
			//string constr = "Provider=MSDASQL.1;Persist Security Info=False;User ID=scott;DSN=OraConn;UID=SYSTEM;DBA=W;APA=T;EXC=F;FEN=T;QTO=T;FRC=10;FDL=10;LOB=T;RST=T;GDE=F;FRL=F;BAM=IfAllSuccessful;MTS=F;MDI=F;CSR=F;FWC=F;PFC=10;TLO=0;";
			
			dbconn = new CWDataAccDll.DataAccess(constr);
			
			//Check Wether Image Directory Exists or not if not create
			DirectoryInfo dinfo = new DirectoryInfo("c:\\CaptureWiseFile");
			dinfo.Attributes = FileAttributes.Hidden;
			if (!dinfo.Exists)
			{
				Directory.CreateDirectory("c:\\CaptureWiseFile");
				DirectoryInfo dinfo1 = new DirectoryInfo("c:\\CaptureWiseFile");
				dinfo1.Attributes = FileAttributes.Hidden;
			}
			
			//Get name of logon user		
			try
			{
			RegistryKey Hkey = Registry.CurrentUser;
			//RegistryKey sHkey = Hkey.OpenSubKey("S-1-5-21-117609710-1383384898-842925246-1000");
			RegistryKey sHkey1 = Hkey.OpenSubKey("Software");
			RegistryKey sHkey2 = sHkey1.OpenSubKey("Microsoft");
			RegistryKey sHkey3 = sHkey2.OpenSubKey("Windows");
			RegistryKey sHkey4 = sHkey3.OpenSubKey("CurrentVersion");	
			RegistryKey sHkey5 = sHkey4.OpenSubKey("Explorer");
			username = (string) sHkey5.GetValue("Logon User Name");
			
			
			}
			catch(NullReferenceException enr)
			{
				MessageBox.Show(enr.Message);
				Application.Exit();
			}
			
			//Get name of Domain
			try
			{
			RegistryKey secHkey = Registry.CurrentUser;
			//RegistryKey secHkey1 = secHkey.OpenSubKey("S-1-5-21-117609710-1383384898-842925246-1000");
			
			RegistryKey secHkey2 = secHkey.OpenSubKey("Volatile Environment");
			domain = secHkey2.GetValue("LogonServer").ToString().Remove(0,2);
			
			}
			catch(System.NullReferenceException enr)
			{
				MessageBox.Show(enr.Message );
				Application.Exit();
			}
			
			

			int i=0;
			
			//Creating object of Twain
			tw = new DCDll.Twain();
			tw.Init(this.Handle);
			ArrayList al;
			al = tw.GetDevList();
				
			System.Collections.IEnumerator myEnumerator = al.GetEnumerator();
			
			/*
			 * Embeding Device names in Menu
			 * */

			while (myEnumerator.MoveNext())
			{
				//MessageBox.Show(myEnumerator.Current.ToString());
				if (i==0)
				{
					dev1.Visible = true;
					dev1.Text = myEnumerator.Current.ToString();
					
				}
				if (i==1)
				{
					dev2.Visible = true;
					dev2.Text = myEnumerator.Current.ToString();
					
				}
				if (i == 2)
				{
					dev3.Visible = true;
					dev3.Text = myEnumerator.Current.ToString();
				}
				if (i == 3)
				{
					dev4.Visible = true;
					dev4.Text = myEnumerator.Current.ToString();
				}
				if (i == 4)
				{
					dev5.Visible = true;
					dev5.Text = myEnumerator.Current.ToString();
				}
				i++;
			}
			prop = false;
			sign = false;
			maindetails = false;
			signinfo=false;
			sign1 = false;
			sign2 = false;
			msgfilter = false;
			
			//
			// TODO: Add any constructor code after InitializeComponent call
			//

			//get path of temp folder of current windows logon user
			try
			{
				RegistryKey Hkey = Registry.CurrentUser;
				RegistryKey sHkey = Hkey.OpenSubKey("Environment");
				pathtemp = (string) sHkey.GetValue("temp");
			}
			catch(NullReferenceException enr)
			{
				MessageBox.Show(enr.Message);
			}
			
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem16 = new System.Windows.Forms.MenuItem();
			this.menuItem18 = new System.Windows.Forms.MenuItem();
			this.menuItem15 = new System.Windows.Forms.MenuItem();
			this.menuItem17 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.dev1 = new System.Windows.Forms.MenuItem();
			this.dev2 = new System.Windows.Forms.MenuItem();
			this.dev3 = new System.Windows.Forms.MenuItem();
			this.dev4 = new System.Windows.Forms.MenuItem();
			this.dev5 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.menuItem11 = new System.Windows.Forms.MenuItem();
			this.menuItem12 = new System.Windows.Forms.MenuItem();
			this.menuItem13 = new System.Windows.Forms.MenuItem();
			this.menuItem14 = new System.Windows.Forms.MenuItem();
			this.toolBar1 = new System.Windows.Forms.ToolBar();
			this.toolBarButton35 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton1 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton29 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton2 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton3 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton23 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton21 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton22 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton4 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton5 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton6 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton7 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton19 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton20 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton42 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton8 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton33 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton30 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton31 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton32 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton9 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton10 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton11 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton12 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton13 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton25 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton14 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton15 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton16 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton24 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton34 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton17 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton18 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton26 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton27 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton28 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton36 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton37 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton38 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton39 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton40 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton41 = new System.Windows.Forms.ToolBarButton();
			this.imageList1 = new System.Windows.Forms.ImageList(this.components);
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.pictureBox3 = new System.Windows.Forms.PictureBox();
			this.tabPage4 = new System.Windows.Forms.TabPage();
			this.pictureBox4 = new System.Windows.Forms.PictureBox();
			this.FeatureExtractionProgress = new System.Windows.Forms.ProgressBar();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.tabPage3.SuspendLayout();
			this.tabPage4.SuspendLayout();
			this.SuspendLayout();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.menuItem4,
																					  this.menuItem5,
																					  this.menuItem6,
																					  this.menuItem10,
																					  this.menuItem12});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem2,
																					  this.menuItem3,
																					  this.menuItem16,
																					  this.menuItem18,
																					  this.menuItem15,
																					  this.menuItem17});
			this.menuItem1.Text = "File";
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 0;
			this.menuItem2.Text = "Capture      F3";
			this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 1;
			this.menuItem3.Text = "Modify";
			this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
			// 
			// menuItem16
			// 
			this.menuItem16.Index = 2;
			this.menuItem16.Text = "Verify";
			this.menuItem16.Click += new System.EventHandler(this.menuItem16_Click);
			// 
			// menuItem18
			// 
			this.menuItem18.Index = 3;
			this.menuItem18.Text = "Delete Account";
			this.menuItem18.Visible = false;
			this.menuItem18.Click += new System.EventHandler(this.menuItem18_Click);
			// 
			// menuItem15
			// 
			this.menuItem15.Index = 4;
			this.menuItem15.Text = "Exit";
			this.menuItem15.Click += new System.EventHandler(this.menuItem15_Click);
			// 
			// menuItem17
			// 
			this.menuItem17.Index = 5;
			this.menuItem17.Text = "Close";
			this.menuItem17.Visible = false;
			this.menuItem17.Click += new System.EventHandler(this.menuItem17_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 1;
			this.menuItem4.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.dev1,
																					  this.dev2,
																					  this.dev3,
																					  this.dev4,
																					  this.dev5});
			this.menuItem4.Text = "Device";
			// 
			// dev1
			// 
			this.dev1.Index = 0;
			this.dev1.Text = "Dev1";
			this.dev1.Visible = false;
			this.dev1.Click += new System.EventHandler(this.dev1_Click);
			// 
			// dev2
			// 
			this.dev2.Index = 1;
			this.dev2.Text = "Dev2";
			this.dev2.Visible = false;
			this.dev2.Click += new System.EventHandler(this.dev2_Click);
			// 
			// dev3
			// 
			this.dev3.Index = 2;
			this.dev3.Text = "Dev3";
			this.dev3.Visible = false;
			this.dev3.Click += new System.EventHandler(this.dev3_Click);
			// 
			// dev4
			// 
			this.dev4.Index = 3;
			this.dev4.Text = "Dev4";
			this.dev4.Visible = false;
			this.dev4.Click += new System.EventHandler(this.dev4_Click);
			// 
			// dev5
			// 
			this.dev5.Index = 4;
			this.dev5.Text = "Dev5";
			this.dev5.Visible = false;
			this.dev5.Click += new System.EventHandler(this.dev5_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Enabled = false;
			this.menuItem5.Index = 2;
			this.menuItem5.Text = "Image Settings";
			this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 3;
			this.menuItem6.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem7,
																					  this.menuItem8,
																					  this.menuItem9});
			this.menuItem6.Text = "Reports";
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 0;
			this.menuItem7.Text = "Capture Reports";
			// 
			// menuItem8
			// 
			this.menuItem8.Index = 1;
			this.menuItem8.Text = "Verification Report";
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 2;
			this.menuItem9.Text = "Pending Account Report";
			// 
			// menuItem10
			// 
			this.menuItem10.Index = 4;
			this.menuItem10.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.menuItem11});
			this.menuItem10.Text = "View";
			// 
			// menuItem11
			// 
			this.menuItem11.Index = 0;
			this.menuItem11.Text = "Show/Hide ToolBar";
			this.menuItem11.Click += new System.EventHandler(this.menuItem11_Click);
			// 
			// menuItem12
			// 
			this.menuItem12.Index = 5;
			this.menuItem12.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.menuItem13,
																					   this.menuItem14});
			this.menuItem12.Text = "Help";
			// 
			// menuItem13
			// 
			this.menuItem13.Index = 0;
			this.menuItem13.Text = "Online Help";
			// 
			// menuItem14
			// 
			this.menuItem14.Index = 1;
			this.menuItem14.Text = "About Capture Wise";
			// 
			// toolBar1
			// 
			this.toolBar1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.toolBar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						this.toolBarButton35,
																						this.toolBarButton1,
																						this.toolBarButton29,
																						this.toolBarButton2,
																						this.toolBarButton3,
																						this.toolBarButton23,
																						this.toolBarButton21,
																						this.toolBarButton22,
																						this.toolBarButton4,
																						this.toolBarButton5,
																						this.toolBarButton6,
																						this.toolBarButton7,
																						this.toolBarButton19,
																						this.toolBarButton20,
																						this.toolBarButton42,
																						this.toolBarButton8,
																						this.toolBarButton33,
																						this.toolBarButton30,
																						this.toolBarButton31,
																						this.toolBarButton32,
																						this.toolBarButton9,
																						this.toolBarButton10,
																						this.toolBarButton11,
																						this.toolBarButton12,
																						this.toolBarButton13,
																						this.toolBarButton25,
																						this.toolBarButton14,
																						this.toolBarButton15,
																						this.toolBarButton16,
																						this.toolBarButton24,
																						this.toolBarButton34,
																						this.toolBarButton17,
																						this.toolBarButton18,
																						this.toolBarButton26,
																						this.toolBarButton27,
																						this.toolBarButton28,
																						this.toolBarButton36,
																						this.toolBarButton37,
																						this.toolBarButton38,
																						this.toolBarButton39,
																						this.toolBarButton40,
																						this.toolBarButton41});
			this.toolBar1.ButtonSize = new System.Drawing.Size(32, 32);
			this.toolBar1.DropDownArrows = true;
			this.toolBar1.ImageList = this.imageList1;
			this.toolBar1.Name = "toolBar1";
			this.toolBar1.ShowToolTips = true;
			this.toolBar1.Size = new System.Drawing.Size(728, 37);
			this.toolBar1.TabIndex = 1;
			this.toolBar1.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar1_ButtonClick);
			// 
			// toolBarButton35
			// 
			this.toolBarButton35.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// toolBarButton1
			// 
			this.toolBarButton1.ImageIndex = 34;
			this.toolBarButton1.ToolTipText = "Save";
			this.toolBarButton1.Visible = false;
			// 
			// toolBarButton29
			// 
			this.toolBarButton29.ImageIndex = 1;
			this.toolBarButton29.Visible = false;
			// 
			// toolBarButton2
			// 
			this.toolBarButton2.ImageIndex = 28;
			this.toolBarButton2.ToolTipText = "Details of Accounts";
			this.toolBarButton2.Visible = false;
			// 
			// toolBarButton3
			// 
			this.toolBarButton3.ImageIndex = 2;
			this.toolBarButton3.ToolTipText = "Capture Signatures";
			this.toolBarButton3.Visible = false;
			// 
			// toolBarButton23
			// 
			this.toolBarButton23.ImageIndex = 22;
			this.toolBarButton23.Visible = false;
			// 
			// toolBarButton21
			// 
			this.toolBarButton21.ImageIndex = 35;
			this.toolBarButton21.ToolTipText = "Previous";
			this.toolBarButton21.Visible = false;
			// 
			// toolBarButton22
			// 
			this.toolBarButton22.ImageIndex = 36;
			this.toolBarButton22.ToolTipText = "Next";
			this.toolBarButton22.Visible = false;
			// 
			// toolBarButton4
			// 
			this.toolBarButton4.ImageIndex = 3;
			this.toolBarButton4.ToolTipText = "Add Signatory";
			this.toolBarButton4.Visible = false;
			// 
			// toolBarButton5
			// 
			this.toolBarButton5.ImageIndex = 4;
			this.toolBarButton5.ToolTipText = "Modify Signatory Name";
			this.toolBarButton5.Visible = false;
			// 
			// toolBarButton6
			// 
			this.toolBarButton6.ImageIndex = 5;
			this.toolBarButton6.ToolTipText = "Add Signature";
			this.toolBarButton6.Visible = false;
			// 
			// toolBarButton7
			// 
			this.toolBarButton7.ImageIndex = 6;
			this.toolBarButton7.ToolTipText = "Signature 2";
			this.toolBarButton7.Visible = false;
			// 
			// toolBarButton19
			// 
			this.toolBarButton19.ImageIndex = 18;
			this.toolBarButton19.ToolTipText = "Thumb Impression";
			this.toolBarButton19.Visible = false;
			// 
			// toolBarButton20
			// 
			this.toolBarButton20.ImageIndex = 13;
			this.toolBarButton20.ToolTipText = "Photograph";
			this.toolBarButton20.Visible = false;
			// 
			// toolBarButton42
			// 
			this.toolBarButton42.ImageIndex = 39;
			this.toolBarButton42.ToolTipText = "Verify/Train";
			this.toolBarButton42.Visible = false;
			// 
			// toolBarButton8
			// 
			this.toolBarButton8.ImageIndex = 7;
			this.toolBarButton8.ToolTipText = "Scan";
			this.toolBarButton8.Visible = false;
			// 
			// toolBarButton33
			// 
			this.toolBarButton33.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// toolBarButton30
			// 
			this.toolBarButton30.ImageIndex = 29;
			this.toolBarButton30.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.toolBarButton30.Visible = false;
			// 
			// toolBarButton31
			// 
			this.toolBarButton31.ImageIndex = 30;
			this.toolBarButton31.Visible = false;
			// 
			// toolBarButton32
			// 
			this.toolBarButton32.ImageIndex = 31;
			this.toolBarButton32.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.toolBarButton32.Visible = false;
			// 
			// toolBarButton9
			// 
			this.toolBarButton9.ImageIndex = 8;
			this.toolBarButton9.ToolTipText = "Accept";
			this.toolBarButton9.Visible = false;
			// 
			// toolBarButton10
			// 
			this.toolBarButton10.ImageIndex = 9;
			this.toolBarButton10.ToolTipText = "Reject";
			this.toolBarButton10.Visible = false;
			// 
			// toolBarButton11
			// 
			this.toolBarButton11.ImageIndex = 10;
			this.toolBarButton11.ToolTipText = "Rotate";
			this.toolBarButton11.Visible = false;
			// 
			// toolBarButton12
			// 
			this.toolBarButton12.ImageIndex = 11;
			this.toolBarButton12.ToolTipText = "Rotate";
			this.toolBarButton12.Visible = false;
			// 
			// toolBarButton13
			// 
			this.toolBarButton13.ImageIndex = 12;
			this.toolBarButton13.ToolTipText = "Rotate";
			this.toolBarButton13.Visible = false;
			// 
			// toolBarButton25
			// 
			this.toolBarButton25.ImageIndex = 24;
			this.toolBarButton25.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.toolBarButton25.Visible = false;
			// 
			// toolBarButton14
			// 
			this.toolBarButton14.ImageIndex = 19;
			this.toolBarButton14.ToolTipText = "Logout";
			this.toolBarButton14.Visible = false;
			// 
			// toolBarButton15
			// 
			this.toolBarButton15.ImageIndex = 14;
			this.toolBarButton15.ToolTipText = "Capture";
			// 
			// toolBarButton16
			// 
			this.toolBarButton16.ImageIndex = 15;
			this.toolBarButton16.ToolTipText = "Modify";
			// 
			// toolBarButton24
			// 
			this.toolBarButton24.ImageIndex = 23;
			// 
			// toolBarButton34
			// 
			this.toolBarButton34.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// toolBarButton17
			// 
			this.toolBarButton17.ImageIndex = 16;
			this.toolBarButton17.ToolTipText = "Help";
			// 
			// toolBarButton18
			// 
			this.toolBarButton18.ImageIndex = 17;
			this.toolBarButton18.ToolTipText = "Exit";
			// 
			// toolBarButton26
			// 
			this.toolBarButton26.ImageIndex = 25;
			this.toolBarButton26.Visible = false;
			// 
			// toolBarButton27
			// 
			this.toolBarButton27.ImageIndex = 26;
			this.toolBarButton27.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.toolBarButton27.Visible = false;
			// 
			// toolBarButton28
			// 
			this.toolBarButton28.ImageIndex = 27;
			this.toolBarButton28.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.toolBarButton28.Visible = false;
			// 
			// toolBarButton36
			// 
			this.toolBarButton36.ImageIndex = 32;
			this.toolBarButton36.Visible = false;
			// 
			// toolBarButton37
			// 
			this.toolBarButton37.ImageIndex = 8;
			this.toolBarButton37.Visible = false;
			// 
			// toolBarButton38
			// 
			this.toolBarButton38.ImageIndex = 9;
			this.toolBarButton38.Visible = false;
			// 
			// toolBarButton39
			// 
			this.toolBarButton39.ImageIndex = 10;
			this.toolBarButton39.Visible = false;
			// 
			// toolBarButton40
			// 
			this.toolBarButton40.ImageIndex = 11;
			this.toolBarButton40.Visible = false;
			// 
			// toolBarButton41
			// 
			this.toolBarButton41.ImageIndex = 12;
			this.toolBarButton41.Visible = false;
			// 
			// imageList1
			// 
			this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imageList1.ImageSize = new System.Drawing.Size(24, 24);
			this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
			this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.tabPage1,
																					  this.tabPage2,
																					  this.tabPage3,
																					  this.tabPage4});
			this.tabControl1.Location = new System.Drawing.Point(0, 390);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(795, 144);
			this.tabControl1.TabIndex = 3;
			this.tabControl1.Visible = false;
			this.tabControl1.TabIndexChanged += new System.EventHandler(this.tabControl1_TabIndexChanged);
			this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
			// 
			// tabPage1
			// 
			this.tabPage1.AutoScroll = true;
			this.tabPage1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.pictureBox1});
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Size = new System.Drawing.Size(787, 118);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Signature 1";
			// 
			// pictureBox1
			// 
			this.pictureBox1.Location = new System.Drawing.Point(232, 16);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 96);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.MouseHover += new System.EventHandler(this.pictureBox1_MouseHover);
			this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
			this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
			// 
			// tabPage2
			// 
			this.tabPage2.AutoScroll = true;
			this.tabPage2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.pictureBox2});
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Size = new System.Drawing.Size(787, 118);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Signature 2";
			// 
			// pictureBox2
			// 
			this.pictureBox2.Location = new System.Drawing.Point(232, 8);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(120, 104);
			this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox2.TabIndex = 0;
			this.pictureBox2.TabStop = false;
			this.pictureBox2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseMove);
			this.pictureBox2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseDown);
			// 
			// tabPage3
			// 
			this.tabPage3.AutoScroll = true;
			this.tabPage3.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.pictureBox3});
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Size = new System.Drawing.Size(787, 118);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "Thumb Impression";
			// 
			// pictureBox3
			// 
			this.pictureBox3.Location = new System.Drawing.Point(232, 8);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new System.Drawing.Size(120, 104);
			this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox3.TabIndex = 0;
			this.pictureBox3.TabStop = false;
			this.pictureBox3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox3_MouseMove);
			this.pictureBox3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox3_MouseDown);
			// 
			// tabPage4
			// 
			this.tabPage4.AutoScroll = true;
			this.tabPage4.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.pictureBox4});
			this.tabPage4.Location = new System.Drawing.Point(4, 22);
			this.tabPage4.Name = "tabPage4";
			this.tabPage4.Size = new System.Drawing.Size(787, 118);
			this.tabPage4.TabIndex = 3;
			this.tabPage4.Text = "Photograph";
			// 
			// pictureBox4
			// 
			this.pictureBox4.Location = new System.Drawing.Point(232, 8);
			this.pictureBox4.Name = "pictureBox4";
			this.pictureBox4.Size = new System.Drawing.Size(104, 104);
			this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox4.TabIndex = 0;
			this.pictureBox4.TabStop = false;
			this.pictureBox4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox4_MouseMove);
			this.pictureBox4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox4_MouseDown);
			// 
			// FeatureExtractionProgress
			// 
			this.FeatureExtractionProgress.Location = new System.Drawing.Point(168, 160);
			this.FeatureExtractionProgress.Name = "FeatureExtractionProgress";
			this.FeatureExtractionProgress.Size = new System.Drawing.Size(360, 23);
			this.FeatureExtractionProgress.TabIndex = 5;
			this.FeatureExtractionProgress.Visible = false;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(728, 465);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.FeatureExtractionProgress,
																		  this.tabControl1,
																		  this.toolBar1});
			this.IsMdiContainer = true;
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Capture Wise Application";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			this.tabPage3.ResumeLayout(false);
			this.tabPage4.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		

		/*
		 *****************************************************
		 Created by Ahmad on 23-02-2004
		 
		purpose:
		Catch Messa nges Related to Twain and Process against them
		 *****************************************************
		*/
		bool IMessageFilter.PreFilterMessage( ref Message m )
		{
			TwainCommand cmd = tw.PassMessage( ref m );
			if( cmd == TwainCommand.Not )
				return false;

			switch( cmd )
			{
				case TwainCommand.CloseRequest:
				{
					EndingScan();
					tw.CloseSrc();
					break;
				}
				case TwainCommand.CloseOk:
				{
					EndingScan();
					tw.CloseSrc();
					break;
				}
				case TwainCommand.DeviceEvent:
				{
					break;
				}
				case TwainCommand.TransferReady:
				{
					
					if (siform != null)
					{
						siform.Close();
						siform.Dispose();
						siform = null;
					}
					
					ArrayList pics = tw.TransferPictures();
					EndingScan();
					tw.CloseSrc();
			
					
					//for( int i = 0; i < pics.Count; i++ )
					//{
						IntPtr img = (IntPtr) pics[ 0 ];
						CWImgMemManip imgmem = new CWImgMemManip(img);
					//}
					filename = "c:\\CaptureWiseFile\\" + accountno + identity.ToString() + signno.ToString() + ".jpeg";
					CWButtonState(false,false,false,false,false,false,false,true,true,true,false);

					
					siform = new CWSignImage(filename);
					siform.MdiParent = this;
					siform.Show();
					
					break;
				}
			}

			return true;
		}


		/*
		 ******************************************************
		 Created by Ahmad on 23-02-2004
		 
		 purpose:
		 Take off control from MessageFilter function
		 ******************************************************
		*/
		private void EndingScan()
		{
			if( msgfilter )
			{
				Application.RemoveMessageFilter( this );
				msgfilter = false;
				this.Enabled = true;
				this.Activate();
			}
		}

		
		

		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
		
		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			//Check Rights of user, whether user can use capture or not
			dbconn.ConfUser(username,domain);
			if (dbconn.cap)
			{
				mode(true,false,false);
				CaptureSig();
			}
			else
			{
				MessageBox.Show("No records exists to be captured by this user");
			}
		}
		//
		//Events on ToolBar buttons
		//
		//
		private void toolBar1_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			//
			//Save Button Event
			//
			
			if (e.Button == this.toolBarButton15)
			{
				//Check Rights of user, whether user can use capture or not
				dbconn.ConfUser(username,domain);
				if (dbconn.cap)
				{
					mode(true,false,false);
					CaptureSig();
				}
				else
				{
					MessageBox.Show("No records exists to be captured by this user");
				}
			}
			
			if (e.Button == this.toolBarButton16)
			{
				//Check Rights of user, whether user can use modify or not
				dbconn.ConfUser(username,domain);
				if (dbconn.mod)
				{
					mode(false,true,false);
					ModifyForm();
					this.menuItem18.Visible = true;
				}
				else
					MessageBox.Show("No records exists to be modified by this user");
			}

			if (e.Button == this.toolBarButton24)
			{
				//Check Rights of user, whether user can use verify or not
				dbconn.ConfUser(username,domain);
				if (dbconn.ver)
				{
					mode(false,false,true);
					VerifySig();
				}
				else
					MessageBox.Show("No records exists to be verified by this user");
			}
			/*
			 * 
			 * Save Button
			 * 
			 */
			if (e.Button == toolBarButton1)
			{
			/*	this.toolBarButton1.Enabled= false;
				MessageBox.Show(prop.ToString()+"  " + maindetails.ToString() +"  "+signinfo.ToString());
				if (prop)
				{
					dbconn.UpadteInfo(adform.textBox1.Text,accountno);
					savecrossref = false;
					CWSave(false,false,false);
				}
				if (maindetails)
				{
					
					dbconn.CWUpdateMainDetails(iform.Accounttitle.Text,iform.companyname.Text,accountno,iform.AccountStatus.Text);
					savecrossref = false;
					CWSave(false,false,false);
				}
				if (signinfo)
				{
					SaveSignatoryInfo();
					savecrossref = false;
					CWSave(false,false,false);

				}
				MessageBox.Show(savecrossref.ToString());
				if (savecrossref)
				{
					if (SaveCR())
					{
						MessageBox.Show("done");
						savecrossref = false;
					}
					else
					{
						MessageBox.Show("There were Errors");
						savecrossref = false;
					}

					savecrossref = false;
					CWSave(false,false,false);

				}*/
				SaveEvent();

				
			}

			//
			//Main Details
			//

			if (e.Button == toolBarButton2)
			{
				if (prop || maindetails || signinfo || savecrossref )
				{
					DialogResult result;

					// Displays the MessageBox.
					MessageBoxButtons buttons = MessageBoxButtons.YesNo;

					result = MessageBox.Show(this, "Do you want to save changes made ", "Capture-Wise", buttons,
						MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, 
						MessageBoxOptions.RightAlign);

					if(result == DialogResult.Yes)
					{
						SaveEvent();
					}
					else
					{

					}
				}
				this.ControlBox = true;
				this.toolBarButton14.Visible = true;
				this.menuItem17.Visible = true;

				
				this.toolBarButton1.Enabled = false;
				this.SetNavigateRotateBut = false;
				accountdetails =(string) dbconn.GetDetails(accountno);
				
				adform = new CWAccountDetailsForm(accountdetails);
				adform.MdiParent = this;
				adform.Show();

				if (iform.Visible )
				{
					iform.Visible = false;
				}

				if (crform != null)
					if (crform.Visible)
						crform.Visible = false;

				adform.textBox1.Text = accountdetails;


				this.toolBarButton2.Visible = false;
				this.toolBarButton29.Visible = true;
				this.toolBarButton23.Visible = true;
				this.toolBarButton3.Enabled = true;

				this.SetNavButtons = false;
				
				
				CWButtonState(true,false,true,false,false,false,false,false,false,false,true);
				this.RotateButtons = false;
				
			
				this.signbuttonVisible = false;
				
				this.tabControl1.Visible = false;
				if (sform != null)
					if (sform.Visible)
						sform.Visible = false;
				
				CWSave(false,false,false);
				this.savecrossref = false;
				this.toolBarButton1.Enabled = false;

					
			}
			//
			//stop verify
			//
			if (e.Button == this.toolBarButton36)
			{
				this.menuItem2.Enabled = true;
				this.menuItem3.Enabled = true;
				this.menuItem16.Enabled = true;

				this.toolBarButton36.Visible = false;
				this.toolBarButton37.Visible = false;
				this.toolBarButton38.Visible = false;
				
				this.SetNavigateRotateBut = false;
				this.StartupButtons = true;
				if (sform != null)
				{
					if (sform.Visible)
					{
						sform.Close();
					}
				}
				if (iform != null)
				{
					if (iform.Visible)
					{
						iform.Close();
					}
				}
				this.tabControl1.Visible = false;
				MessageBox.Show("Verifier: " + username);
			}
			//
			//verify accounts 
			//
			if (e.Button == this.toolBarButton37)
			{
				if (acc > 0)
				{
					dbconn.UpdateSigStatus(accountno,"Active",identity.ToString());		
					if (acc < slist.Count)
					{
						
						
					
						identity = Int32.Parse(slist.GetByIndex(acc).ToString());
						iform.Close();
						
						dbconn.GetSignatoryInfo(identity,accountno);
						sform.SignId.Text = identity.ToString();
						sform.SignName.Text = dbconn.signame;
						sform.expirydate.Value = System.DateTime.Parse(dbconn.expirydate);
						sform.limit.Text = dbconn.limit.ToString();
					
						if (dbconn.cosignee == 1)
						{
							sform.CoSigneeReq.Checked = true;
							sform.limit.Enabled = false;
						}
						else
							if (dbconn.cosignee == 0)
						{
							sform.CoSigneeReq.Checked = false;
							sform.limit.Enabled = true;
						}
				
						sform.Group.Text = dbconn.grp;

						

						if (!this.tabControl1.Visible)
							this.tabControl1.Visible = true;
						if (this.pictureBox1.Image != null)
						{
							this.pictureBox1.Image.Dispose();
							this.pictureBox1.Image = null;
						}

						if (dbconn.GetSign1(identity,accountno))
						{
							this.pictureBox1.Image = Image.FromFile(pathtemp+"\\tempsign1.jpeg");
						}


						if (!this.tabControl1.Visible)
							this.tabControl1.Visible = true;
						if (this.pictureBox2.Image != null)
						{
							this.pictureBox2.Image.Dispose();
							this.pictureBox2.Image = null;
						}

						if (dbconn.GetSign2(identity,accountno))
						{
							this.pictureBox2.Image = Image.FromFile(pathtemp+"\\tempsign2.jpeg");
						}


						if (!this.tabControl1.Visible)
							this.tabControl1.Visible = true;
						if (this.pictureBox3.Image != null)
						{
							this.pictureBox3.Image.Dispose();
							this.pictureBox3.Image = null;
						}

						if (dbconn.GetThumb(identity,accountno))
						{
							this.pictureBox3.Image = Image.FromFile(pathtemp+"\\tempThumb.jpeg");
						}

						if (!this.tabControl1.Visible)
							this.tabControl1.Visible = true;
						if (this.pictureBox4.Image != null)
						{
							this.pictureBox4.Image.Dispose();
							this.pictureBox4.Image = null;
						}
					
						if (dbconn.GetPhoto(identity,accountno))
						{
							this.pictureBox4.Image = Image.FromFile(pathtemp+"\\tempPhoto.jpeg");
						}
						
						tabControl1.Refresh();

						switch(tabControl1.SelectedIndex)
						{
							case 0:
							{
								if (pictureBox1.Image ==null)
									this.SetNavigateRotateBut = false;
								else
									this.SetNavigateRotateBut = true;
								break;
							}
							case 1:
							{
								if (pictureBox2.Image ==null)
									this.SetNavigateRotateBut = false;
								else
									this.SetNavigateRotateBut = true;
								break;
							}
							case 2:
							{
								if (pictureBox3.Image ==null)
									this.SetNavigateRotateBut = false;
								else
									this.SetNavigateRotateBut = true;
								break;
							}
							case 3:
							{
								if (pictureBox4.Image ==null)
									this.SetNavigateRotateBut = false;
								else
									this.SetNavigateRotateBut = true;
								break;
							}

						}	

						acc++;
					}
					else
					{

						this.menuItem2.Enabled = true;
						this.menuItem3.Enabled = true;
						this.menuItem16.Enabled = true;

						this.toolBarButton36.Visible = false;
						this.toolBarButton37.Visible = false;
						this.toolBarButton38.Visible = false;
						
						this.SetNavigateRotateBut = false;
						this.StartupButtons = true;
						if (sform != null)
						{
							if (sform.Visible)
							{
								sform.Close();
							}
						}
						if (iform != null)
						{
							if (iform.Visible)
							{
								iform.Close();
							}
						}
						this.tabControl1.Visible = false;
						MessageBox.Show("Verifier: " + username);
					}

				}
				
				
				


				if (acc == 0)
				{
					
					dbconn.UpdateAccountStatus("Active",accountno);
					slist = dbconn.GetSignatories(accountno);
					if (slist.Count != 0)
					{
						identity = Int32.Parse(slist.GetByIndex(acc).ToString());
						iform.Close();
						sform = new CWSignatoryForm();
						sform.MdiParent = this;
						sform.Show();
						dbconn.GetSignatoryInfo(identity,accountno);
						sform.SignId.Text = identity.ToString();
						sform.SignName.Text = dbconn.signame;
						sform.expirydate.Value = System.DateTime.Parse(dbconn.expirydate);
						sform.limit.Text = dbconn.limit.ToString();
					
						if (dbconn.cosignee == 1)
						{
							sform.CoSigneeReq.Checked = true;
							sform.limit.Enabled = false;
						}
						else
							if (dbconn.cosignee == 0)
						{
							sform.CoSigneeReq.Checked = false;
							sform.limit.Enabled = true;
						}
				
						sform.Group.Text = dbconn.grp;


					

						if (!this.tabControl1.Visible)
							this.tabControl1.Visible = true;
						if (this.pictureBox1.Image != null)
						{
							this.pictureBox1.Image.Dispose();
							this.pictureBox1.Image = null;
						}

						if (dbconn.GetSign1(identity,accountno))
						{
							this.pictureBox1.Image = Image.FromFile(pathtemp+"\\tempsign1.jpeg");
						}


						if (!this.tabControl1.Visible)
							this.tabControl1.Visible = true;
						if (this.pictureBox2.Image != null)
						{
							this.pictureBox2.Image.Dispose();
							this.pictureBox2.Image = null;
						}

						if (dbconn.GetSign2(identity,accountno))
						{
							this.pictureBox2.Image = Image.FromFile(pathtemp+"\\tempsign2.jpeg");
						}


						if (!this.tabControl1.Visible)
							this.tabControl1.Visible = true;
						if (this.pictureBox3.Image != null)
						{
							this.pictureBox3.Image.Dispose();
							this.pictureBox3.Image = null;
						}

						if (dbconn.GetThumb(identity,accountno))
						{
							this.pictureBox3.Image = Image.FromFile(pathtemp+"\\tempThumb.jpeg");
						}

						if (!this.tabControl1.Visible)
							this.tabControl1.Visible = true;
						if (this.pictureBox4.Image != null)
						{
							this.pictureBox4.Image.Dispose();
							this.pictureBox4.Image = null;
						}

						if (dbconn.GetPhoto(identity,accountno))
						{
							this.pictureBox4.Image = Image.FromFile(pathtemp+"\\tempPhoto.jpeg");
						}

						switch(tabControl1.SelectedIndex)
						{
							case 0:
							{
								if (pictureBox1.Image ==null)
									this.SetNavigateRotateBut = false;
								else
									this.SetNavigateRotateBut = true;
								break;
							}
							case 1:
							{
								if (pictureBox2.Image ==null)
									this.SetNavigateRotateBut = false;
								else
									this.SetNavigateRotateBut = true;
								break;
							}
							case 2:
							{
								if (pictureBox3.Image ==null)
									this.SetNavigateRotateBut = false;
								else
									this.SetNavigateRotateBut = true;
								break;
							}
							case 3:
							{
								if (pictureBox4.Image ==null)
									this.SetNavigateRotateBut = false;
								else
									this.SetNavigateRotateBut = true;
								break;
							}

						}

						
					}
					else
					{
						this.menuItem2.Enabled = true;
						this.menuItem3.Enabled = true;
						this.menuItem16.Enabled = true;

						this.toolBarButton36.Visible = false;
						this.toolBarButton37.Visible = false;
						this.toolBarButton38.Visible = false;
						
						this.SetNavigateRotateBut = false;
						this.StartupButtons = true;
						if (sform != null)
						{
							if (sform.Visible)
							{
								sform.Close();
							}
						}
						if (iform != null)
						{
							if (iform.Visible)
							{
								iform.Close();
							}
						}
						this.tabControl1.Visible = false;
						MessageBox.Show("Verifier: " + username);
					}


					acc++;
				}
				
				
			}

			if (e.Button == this.toolBarButton38)
			{
				dbconn.UpdateAccountStatus("In-active",accountno);
				slist = dbconn.GetSignatories(accountno);
				for (int i=0;i<slist.Count;i++)
				{
					identity = Int32.Parse(slist.GetByIndex(i).ToString());
					dbconn.UpdateSigStatus(accountno,"In-active",identity.ToString());
				}
				this.menuItem2.Enabled = true;
				this.menuItem3.Enabled = true;
				this.menuItem16.Enabled = true;

				this.toolBarButton36.Visible = false;
				this.toolBarButton37.Visible = false;
				this.toolBarButton38.Visible = false;
				
				this.SetNavigateRotateBut = false;
				this.StartupButtons = true;
				if (sform != null)
				{
					if (sform.Visible)
					{
						sform.Close();
					}
				}
				if (iform != null)
				{
					if (iform.Visible)
					{
						iform.Close();
					}
				}
				this.tabControl1.Visible = false;
				MessageBox.Show("Verifier: " + username);
			}
			

			//
			//Account Details
			//

			if (e.Button == toolBarButton29)
			{
				if (prop || maindetails || signinfo || savecrossref )
				{
					DialogResult result;

					// Displays the MessageBox.
					MessageBoxButtons buttons = MessageBoxButtons.YesNo;

					result = MessageBox.Show(this, "Do you want to save changes made in this signatory", "", buttons,
						MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, 
						MessageBoxOptions.RightAlign);


					if(result == DialogResult.Yes)
					{
						SaveEvent();
					}
					else
					{

					}
				}

				this.ControlBox = true;
				this.toolBarButton14.Visible = true;
				this.menuItem17.Visible = true;

				dbconn.ConfirmAccountNo(accountno);
				captureddate = dbconn.captured;
				companyname = dbconn.companyname;

				iform.Accounttitle.Text = dbconn.accounttitle;
				iform.Captured.Text = captureddate;
				iform.companyname.Text = companyname;

				
				this.toolBarButton3.Enabled = true;
				this.toolBarButton29.Visible = false;
				this.toolBarButton2.Visible = true;
				this.toolBarButton23.Visible = true;

				this.SetNavigateRotateBut = false;

				if (crform != null)
					if (crform.Visible)
						crform.Visible = false;
				if (adform != null)
					if (adform.Visible)
						adform.Visible = false;
				
				iform.Visible = true;
			
				this.SetNavButtons = false;
								
				accounttitle = dbconn.ConfirmAccountNo(accountno);
				captureddate = dbconn.captured;
				companyname = dbconn.companyname;

				iform.Accounttitle.Text = accounttitle;
				
				iform.Captured.Text = captureddate;
				iform.companyname.Text = companyname;
				
				
				CWButtonState(true,true,true,false,false,false,false,false,false,false,true);
				this.RotateButtons = false;
				
				
				this.signbuttonVisible = false;
				
				
				this.tabControl1.Visible = false;
				if (sform != null)
					if (sform.Visible)
						sform.Visible = false;

				CWSave(false,false,false);
				this.savecrossref = false;
				this.toolBarButton1.Enabled = false;

			
			}
			//
			//Signatories
			//

			if (e.Button == toolBarButton3)
			{
				this.ControlBox = false;
				this.toolBarButton14.Visible = false;
				this.menuItem17.Visible = false;

				this.savecrossref = false;
				if (adform != null)
				{
					if(adform.Visible) 
						adform.Visible = false;
				
				}
				if (iform.Visible == true)
				{
					if (iform.Visible)
						iform.Visible = false;
				}

				if (crform != null)
					if (crform.Visible)
						crform.Visible = false;


				
				CWButtonState(true,true,false,true,true,true,true,false,false,false,false);
				//CWButtonEnabled(false,true,false,true,true,false,false,false,false,false,true);
				
				
				this.toolBarButton29.Visible = true;
				
				this.toolBarButton23.Visible = true;
				
				
				if (iform.Visible == true)
				{
					iform.Close();
				}
				sform = new CWSignatoryForm();
				sform.MdiParent = this;
				sform.Show();
				
				identity = dbconn.GetMaxId(accountno);
				if (identity == 0)
				{
					sform.SignName.Enabled = false;
					sform.SignId.Enabled = false;
					sform.expirydate.Enabled = false;
					sform.limit.Enabled = false;
					sform.CoSigneeReq.Enabled = false;
					sform.Group.Enabled = false;
					
					this.toolBarButton21.Enabled = false;
					this.toolBarButton22.Enabled = false;

					this.toolBarButton21.Visible = true;
					this.toolBarButton22.Visible = true;

					signbuttonVisible = false;
					this.SetNavigateRotateBut = false;
					this.toolBarButton1.Enabled = false;
					this.RotateButtons = false;
					

				}
				else
				{
					
					slist = dbconn.GetSignatories(accountno);
					
					identity = Int32.Parse(slist.GetByIndex(0).ToString());
					
					 dbconn.GetSignatoryInfo(identity,accountno);
					
					sform.SignId.Text = identity.ToString();
					sform.SignName.Text = dbconn.signame;
					sform.expirydate.Value = System.DateTime.Parse(dbconn.expirydate);
					sform.limit.Text = dbconn.limit.ToString();
					
					if (dbconn.cosignee == 1)
					{
						sform.CoSigneeReq.Checked = true;
						sform.limit.Enabled = false;
					}
					else
						if (dbconn.cosignee == 0)
					{
						sform.CoSigneeReq.Checked = false;
						sform.limit.Enabled = true;
					}
				
					sform.Group.Text = dbconn.grp;

					this.toolBarButton1.Enabled = false;

					total = slist.Count ;
					current = 0;
					
					this.toolBarButton21.Visible = true;
					this.toolBarButton22.Visible = true;
					
					this.signbuttonVisible = true;
					this.signbuttonEnabled = true;
					this.toolBarButton5.Enabled = true;

					if (!this.tabControl1.Visible)
						this.tabControl1.Visible = true;
					if (this.pictureBox1.Image != null)
					{
						this.pictureBox1.Image.Dispose();
						this.pictureBox1.Image = null;
					}

					if (dbconn.GetSign1(identity,accountno))
					{
						this.pictureBox1.Image = Image.FromFile(pathtemp+"\\tempsign1.jpeg");
					}


					if (!this.tabControl1.Visible)
						this.tabControl1.Visible = true;
					if (this.pictureBox2.Image != null)
					{
						this.pictureBox2.Image.Dispose();
						this.pictureBox2.Image = null;
					}

					if (dbconn.GetSign2(identity,accountno))
					{
						this.pictureBox2.Image = Image.FromFile(pathtemp+"\\tempsign2.jpeg");
					}


					if (!this.tabControl1.Visible)
						this.tabControl1.Visible = true;
					if (this.pictureBox3.Image != null)
					{
						this.pictureBox3.Image.Dispose();
						this.pictureBox3.Image = null;
					}

					if (dbconn.GetThumb(identity,accountno))
					{
						this.pictureBox3.Image = Image.FromFile(pathtemp+"\\tempThumb.jpeg");
					}

					if (!this.tabControl1.Visible)
						this.tabControl1.Visible = true;
					if (this.pictureBox4.Image != null)
					{
						this.pictureBox4.Image.Dispose();
						this.pictureBox4.Image = null;
					}

					if (dbconn.GetPhoto(identity,accountno))
					{
						this.pictureBox4.Image = Image.FromFile(pathtemp+"\\tempPhoto.jpeg");
					}

					CWSave(false,false,false);
					if (slist.Count == 0 || slist.Count == 1)
					{
						this.toolBarButton21.Enabled = false;
						this.toolBarButton22.Enabled = false;
					}
					if (total > 1)
					{
						
						this.toolBarButton21.Enabled = false;
						this.toolBarButton22.Enabled = true;
					}
					
					

				}
			
	
				switch(tabControl1.SelectedIndex)
				{
					case 0:
					{
						if (pictureBox1.Image ==null)
							this.SetNavigateRotateBut = false;
						else
							this.SetNavigateRotateBut = true;
						break;
					}
					case 1:
					{
						if (pictureBox2.Image ==null)
							this.SetNavigateRotateBut = false;
						else
							this.SetNavigateRotateBut = true;
						break;
					}
					case 2:
					{
						if (pictureBox3.Image ==null)
							this.SetNavigateRotateBut = false;
						else
							this.SetNavigateRotateBut = true;
						break;
					}
					case 3:
					{
						if (pictureBox4.Image ==null)
							this.SetNavigateRotateBut = false;
						else
							this.SetNavigateRotateBut = true;
						break;
					}

				}
		
			}

			// 
			// Navigation Button Proceed Forward
			//

			if (e.Button == this.toolBarButton22)
			{

					
				if (signinfo == true)
				{
					DialogResult result;

					// Displays the MessageBox.
					MessageBoxButtons buttons = MessageBoxButtons.YesNo;
					
					result = MessageBox.Show(this, "Do you want to save changes made in this signatory", "Capture-Wise", buttons,
						MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, 
						MessageBoxOptions.RightAlign);

					if(result == DialogResult.Yes)
					{

						// Closes the parent form
						SaveSignatoryInfo();
						CWSave(false,false,false);
						this.savecrossref = false;
						addSignatory = false;
					}
					else if (result == DialogResult.No)
					{
						CWSave(false,false,false);
						this.savecrossref = false;
						addSignatory = false;
					}

				}
				
					this.toolBarButton1.Enabled = false;
				
					current++;
					
				if (sform == null)
				{
					sform = new CWSignatoryForm();
					sform.MdiParent = this;
					sform.Show();
				}

				if (!sform.Visible)
				{
					sform = new CWSignatoryForm();
					sform.MdiParent = this;
					sform.Show();
				}

					identity = Int32.Parse(slist.GetByIndex(current).ToString());
					dbconn.GetSignatoryInfo(identity,accountno);
				


					sform.SignId.Text = identity.ToString();
					sform.SignName.Text = dbconn.signame;
					sform.limit.Text = dbconn.limit.ToString();
				
					sform.expirydate.Value = System.DateTime.Parse(dbconn.expirydate);
					if (dbconn.cosignee == 1)
					{
						sform.CoSigneeReq.Checked = true;
						sform.limit.Enabled = false;
					}
					else
						if (dbconn.cosignee == 0)
					{
						sform.CoSigneeReq.Checked = false;
						sform.limit.Enabled = true;
					}
				
					sform.Group.Text = dbconn.grp;

					if (current == (total-1))
					{
						this.toolBarButton22.Enabled = false;
					}
					if (current > 0 )
					{
						this.toolBarButton21.Enabled = true;
					}

					sform.SignatoryStatus.Text = dbconn.signatorystatus;
				

				this.pictureBox1.Height = 92;
				this.pictureBox1.Width = 138;
				
				this.pictureBox2.Height = 92;
				this.pictureBox2.Width = 138;
					
				this.pictureBox3.Height = 92;
				this.pictureBox3.Width = 138;

				this.pictureBox4.Height = 92;
				this.pictureBox4.Width = 138;


				if (!this.tabControl1.Visible)
					this.tabControl1.Visible = true;
				if (this.pictureBox1.Image != null)
				{
					this.pictureBox1.Image.Dispose();
					this.pictureBox1.Image = null;
				}

				if (dbconn.GetSign1(identity,accountno))
				{
					this.pictureBox1.Image = Image.FromFile(pathtemp+"\\tempsign1.jpeg");
				}


				if (!this.tabControl1.Visible)
					this.tabControl1.Visible = true;
				if (this.pictureBox2.Image != null)
				{
					this.pictureBox2.Image.Dispose();
					this.pictureBox2.Image = null;
				}

				if (dbconn.GetSign2(identity,accountno))
				{
					this.pictureBox2.Image = Image.FromFile(pathtemp+"\\tempsign2.jpeg");
				}


				if (!this.tabControl1.Visible)
					this.tabControl1.Visible = true;
				if (this.pictureBox3.Image != null)
				{
					this.pictureBox3.Image.Dispose();
					this.pictureBox3.Image = null;
				}

				if (dbconn.GetThumb(identity,accountno))
				{
					this.pictureBox3.Image = Image.FromFile(pathtemp+"\\tempThumb.jpeg");
				}

				if (!this.tabControl1.Visible)
					this.tabControl1.Visible = true;
				if (this.pictureBox4.Image != null)
				{
					this.pictureBox4.Image.Dispose();
					this.pictureBox4.Image = null;
				}

				if (dbconn.GetPhoto(identity,accountno))
				{
					this.pictureBox4.Image = Image.FromFile(pathtemp+"\\tempPhoto.jpeg");
				}
					
					CWSave(false,false,false);
					this.savecrossref = false;
					this.toolBarButton1.Enabled = false;
					this.toolBarButton5.Enabled = true;

				switch(tabControl1.SelectedIndex)
				{
					case 0:
					{
						if (pictureBox1.Image ==null)
							this.SetNavigateRotateBut = false;
						else
							this.SetNavigateRotateBut = true;
						break;
					}
					case 1:
					{
						if (pictureBox2.Image ==null)
							this.SetNavigateRotateBut = false;
						else
							this.SetNavigateRotateBut = true;
						break;
					}
					case 2:
					{
						if (pictureBox3.Image ==null)
							this.SetNavigateRotateBut = false;
						else
							this.SetNavigateRotateBut = true;
						break;
					}
					case 3:
					{
						if (pictureBox4.Image ==null)
							this.SetNavigateRotateBut = false;
						else
							this.SetNavigateRotateBut = true;
						break;
					}

				}
				
			}

			if (e.Button == this.toolBarButton21)
			{
				
				
				if (signinfo)
				{
					DialogResult result;

					// Displays the MessageBox.
					MessageBoxButtons buttons = MessageBoxButtons.YesNo;

					result = MessageBox.Show(this, "Do you want to save changes made in this signatory", "Capture-Wise", buttons,
						MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, 
						MessageBoxOptions.DefaultDesktopOnly);

					if(result == DialogResult.Yes)
					{

						// Closes the parent form
						SaveSignatoryInfo();
						addSignatory = false;
					}
					else if (result == DialogResult.No)
					{
						CWSave(false,false,false);
						this.savecrossref = false;
						addSignatory = false;
					}

				}
				
				current--;

				identity = Int32.Parse(slist.GetByIndex(current).ToString());
				
				dbconn.GetSignatoryInfo(identity,accountno);
				
				if (sform == null)
				{
					sform = new CWSignatoryForm();
					sform.MdiParent = this;
					sform.Show();
				}
				if (!sform.Visible)
				{
					sform = new CWSignatoryForm();
					sform.MdiParent = this;
					sform.Show();
				}
				sform.SignId.Text = identity.ToString();
				sform.SignName.Text = dbconn.signame;
				sform.limit.Text = dbconn.limit.ToString();
				sform.expirydate.Value = System.DateTime.Parse(dbconn.expirydate);

				if (dbconn.cosignee == 1)
				{
					sform.CoSigneeReq.Checked = true;
					sform.limit.Enabled = false;
				}
				else
					if (dbconn.cosignee == 0)
				{
					sform.CoSigneeReq.Checked = false;
				}
				
				sform.Group.Text = dbconn.grp;

				sform.SignatoryStatus.Text = dbconn.signatorystatus;
				if (current == 0)
				{
					this.toolBarButton21.Enabled = false;
				}
				if (current == (total-1))
				{
					this.toolBarButton22.Enabled = false;
				}
				if (current < (total-1))
				{
					this.toolBarButton22.Enabled = true;
				}

				if (!this.tabControl1.Visible)
					this.tabControl1.Visible = true;
				if (this.pictureBox1.Image != null)
				{
					this.pictureBox1.Image.Dispose();
					this.pictureBox1.Image = null;
				}

				if (dbconn.GetSign1(identity,accountno))
				{
					this.pictureBox1.Image = Image.FromFile(pathtemp+"\\tempsign1.jpeg");
				}


				this.pictureBox1.Height = 92;
				this.pictureBox1.Width = 138;
				
				this.pictureBox2.Height = 92;
				this.pictureBox2.Width = 138;
					
				this.pictureBox3.Height = 92;
				this.pictureBox3.Width = 138;

				this.pictureBox4.Height = 92;
				this.pictureBox4.Width = 138;

				if (!this.tabControl1.Visible)
					this.tabControl1.Visible = true;
				if (this.pictureBox2.Image != null)
				{
					this.pictureBox2.Image.Dispose();
					this.pictureBox2.Image = null;
				}

				if (dbconn.GetSign2(identity,accountno))
				{
					this.pictureBox2.Image = Image.FromFile(pathtemp+"\\tempsign2.jpeg");
				}


				if (!this.tabControl1.Visible)
					this.tabControl1.Visible = true;
				if (this.pictureBox3.Image != null)
				{
					this.pictureBox3.Image.Dispose();
					this.pictureBox3.Image = null;
				}

				if (dbconn.GetThumb(identity,accountno))
				{
					this.pictureBox3.Image = Image.FromFile(pathtemp+"\\tempThumb.jpeg");
				}

				if (!this.tabControl1.Visible)
					this.tabControl1.Visible = true;
				if (this.pictureBox4.Image != null)
				{
					this.pictureBox4.Image.Dispose();
					this.pictureBox4.Image = null;
				}

				if (dbconn.GetPhoto(identity,accountno))
				{
					this.pictureBox4.Image = Image.FromFile(pathtemp+"\\tempPhoto.jpeg");
				}
			
				CWSave(false,false,false);
				this.savecrossref = false;
				this.toolBarButton1.Enabled = false;
				this.toolBarButton5.Enabled = true;
				switch(tabControl1.SelectedIndex)
				{
					case 0:
					{
						if (pictureBox1.Image ==null)
							this.SetNavigateRotateBut = false;
						else
							this.SetNavigateRotateBut = true;
						break;
					}
					case 1:
					{
						if (pictureBox2.Image ==null)
							this.SetNavigateRotateBut = false;
						else
							this.SetNavigateRotateBut = true;
						break;
					}
					case 2:
					{
						if (pictureBox3.Image ==null)
							this.SetNavigateRotateBut = false;
						else
							this.SetNavigateRotateBut = true;
						break;
					}
					case 3:
					{
						if (pictureBox4.Image ==null)
							this.SetNavigateRotateBut = false;
						else
							this.SetNavigateRotateBut = true;
						break;
					}

				}
			}

			//
			//Cross Reference Event
			//

			if (e.Button == this.toolBarButton23)
			{
				if (prop || maindetails || signinfo || savecrossref )
				{
					DialogResult result;

					// Displays the MessageBox.
					MessageBoxButtons buttons = MessageBoxButtons.YesNo;

					result = MessageBox.Show(this, "Do you want to save changes made in this signatory", "Capture-Wise", buttons,
						MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, 
						MessageBoxOptions.RightAlign);

					if(result == DialogResult.Yes)
					{
						SaveEvent();
					}
					else
					{

					}
				}
				this.ControlBox = true;
				this.toolBarButton14.Visible = true;
				this.menuItem17.Visible = true;

				if (adform != null)
					if (adform.Visible)
						adform.Visible = false;
				
				if (iform.Visible)
					iform.Visible = false;

				this.toolBarButton23.Visible = false;
				this.toolBarButton29.Visible = true;

				this.SetNavButtons = false;
				this.SetNavigateRotateBut = false;
								
				CWButtonState(true,true,true,false,false,false,false,false,false,false,true);
				this.RotateButtons = false;
				
			
				this.signbuttonVisible = false;
				
				this.tabControl1.Visible = false;
				
				if (sform != null)
					if (sform.Visible)
						sform.Visible = false;


				



				crform = new CWCrossReference();
				crform.MdiParent = this;
				

				crDataTable = new DataTable("MyDataTable");
   
				// Declare DataColumn and DataRow variables.
				DataColumn crDataColumn;
				DataRow crDataRow;
				
				//Sr no Col
				crDataColumn = new DataColumn();
				crDataColumn.DataType = System.Type.GetType("System.Int32");
				crDataColumn.ColumnName = "No.";
				crDataColumn.ReadOnly = true;
				crDataColumn.Caption = "";
				crDataTable.Columns.Add(crDataColumn);

				// Create new DataColumn, set DataType, ColumnName and add to DataTable.    
				crDataColumn = new DataColumn();
				crDataColumn.DataType = System.Type.GetType("System.String");
				crDataColumn.ColumnName = "1";
				crDataTable.Columns.Add(crDataColumn);

				// Create second column.
				crDataColumn = new DataColumn();
				crDataColumn.DataType = Type.GetType("System.String");
				crDataColumn.ColumnName = "2";
				crDataTable.Columns.Add(crDataColumn);

				crDataColumn = new DataColumn();
				crDataColumn.DataType = System.Type.GetType("System.String");
				crDataColumn.ColumnName = "3";
				crDataTable.Columns.Add(crDataColumn);

				crDataColumn = new DataColumn();
				crDataColumn.DataType = System.Type.GetType("System.String");
				crDataColumn.ColumnName = "4";
				crDataTable.Columns.Add(crDataColumn);

				crDataColumn = new DataColumn();
				crDataColumn.DataType = System.Type.GetType("System.String");
				crDataColumn.ColumnName = "5";
				crDataTable.Columns.Add(crDataColumn);


				crDataColumn = new DataColumn();
				crDataColumn.DataType = System.Type.GetType("System.String");
				crDataColumn.ColumnName = "6";
				crDataTable.Columns.Add(crDataColumn);

				crDataColumn = new DataColumn();
				crDataColumn.DataType = System.Type.GetType("System.String");
				crDataColumn.ColumnName = "Limit";
				crDataTable.Columns.Add(crDataColumn);
				
				if (dbconn.CheckSigRef(accountno))
				{
					dataexists = true;
				}

				// Create new DataRow objects and add to DataTable.
				if (!dataexists)
				{
					for(int i = 0; i < 20; i++)
					{
						crDataRow = crDataTable.NewRow();
					
						crDataRow[0] = i+1;
						crDataRow[1] = "";
						crDataRow[2] = "";
						crDataRow[3] = "";
						crDataRow[4] = "";
						crDataRow[5] = "";
						crDataRow[6] = "";
						crDataRow[7] = "";
					
						crDataTable.Rows.Add(crDataRow);
						dbconn.InsertCrossReference(accountno,i,"","","","","","","");
					
					}
				}
				else
					if (dataexists)
				{
					for(int i = 0; i < 20; i++)
					{
						dbconn.GetCrossReference(accountno,i);
						crDataRow = crDataTable.NewRow();
						
						crDataRow[0] = i+1;
						crDataRow[1] = dbconn.group1;
						crDataRow[2] = dbconn.group2;
						crDataRow[3] = dbconn.group3;
						crDataRow[4] = dbconn.group4;
						crDataRow[5] = dbconn.group5;
						crDataRow[6] = dbconn.group6;
						crDataRow[7] = dbconn.crlimit;
					
						crDataTable.Rows.Add(crDataRow);
					
					}
				}

				
				
				
				crform.CRefernceGrid.DataSource = crDataTable;
				
				crform.Show();
				
				CWSave(false,false,false);
				this.savecrossref = false;
				this.toolBarButton1.Enabled = false;

			
			}

			

			
			//
			//Signatory Event
			//
			if (e.Button == toolBarButton4)
			{

				sigcount = 0;
				
				
				

				//this.disposeResources();
				if (sform == null)
				{
					sform = new CWSignatoryForm();
					sform.MdiParent = this;
					sform.Show();
				}
				if (sform.Visible == false)
				{
					sform = new CWSignatoryForm();
					sform.MdiParent = this;
					sform.Show();
				}
				ScanButtons = false;
				if (siform != null)
				{
					if (siform.Visible)
							siform.Close();
				}
				
				identity = dbconn.GetMaxId(accountno);
				identity++;
				asform = new AddSignatory(identity);
					
				asform.ShowDialog();
				if (asform.flag)
				{
					if (this.pictureBox1.Image != null)
					{
						this.pictureBox1.Image.Dispose();
						this.pictureBox1.Image = null;
					}

					if (this.pictureBox2.Image != null)
					{
						this.pictureBox2.Image.Dispose();
						this.pictureBox2.Image = null;
					}

					if (this.pictureBox3.Image != null)
					{
						this.pictureBox3.Image.Dispose();
						this.pictureBox3.Image = null;
					}

					if (this.pictureBox4.Image != null)
					{
						this.pictureBox4.Image.Dispose();
						this.pictureBox4.Image = null;
					}


					this.tabControl1.Refresh();

					sform.SignId.Text = identity.ToString();
					sform.SignName.Text = asform.textBox1.Text;
					signname = sform.SignName.Text;
					sform.SignName.Enabled = true;
					sform.CoSigneeReq.Enabled = true;
					sform.CoSigneeReq.Checked = false;
					sform.limit.Enabled = true;
					sform.limit.Text = "";
					sform.Group.Enabled = true;
					sform.Group.Text = "";
					
					sform.expirydate.Enabled = true;
					
					addSignatory = true;


					this.toolBarButton1.Enabled = true;		
					/*this.toolBarButton1.Enabled = true;
						this.toolBarButton1.Visible = true;
						this.toolBarButton4.Enabled= false;
						this.toolBarButton5.Visible = true;
						this.toolBarButton5.Enabled = true;*/
					this.SignButtonsPropertyEnabled = false;
					CWButtonState(true,false,false,true,true,true,true,false,false,false,false);
					//CWButtonEnabled(true,false,false,true,true,false,false,false,false,false,true);

					this.signbuttonVisible = true;
					this.signbuttonEnabled = false;

					CWSave(false,false,true);
										
					this.toolBarButton21.Enabled = false;
					this.toolBarButton22.Enabled = false;

					this.toolBarButton29.Visible = false;
					this.toolBarButton2.Visible = false;
					this.toolBarButton23.Visible = false;
					this.SetNavigateRotateBut = false;

					

					
				}

			}
			

			if (e.Button == this.toolBarButton5)
			{
				/*asform = new AddSignatory(identity);
					
				asform.ShowDialog();
				if (asform.flag)
				{
					sform.SignId.Text = identity.ToString();
					sform.SignName.Text = asform.textBox1.Text;
					signname = sform.SignName.Text;
						
					this.toolBarButton1.Enabled = true;
					signinfo = true;
				}*/
				
				int rowseffected = dbconn.DeleteSignatories(identity,accountno);
				
				
					if (this.pictureBox1.Image != null)
					{
						this.pictureBox1.Image.Dispose();
						this.pictureBox1.Image = null;
					}

				
					this.pictureBox1.Height = 92;
					this.pictureBox1.Width = 138;
				
					this.pictureBox2.Height = 92;
					this.pictureBox2.Width = 138;
					
					this.pictureBox3.Height = 92;
					this.pictureBox3.Width = 138;

					this.pictureBox4.Height = 92;
					this.pictureBox4.Width = 138;

					if (this.pictureBox2.Image != null)
					{
						this.pictureBox2.Image.Dispose();
						this.pictureBox2.Image = null;
					}

				


					if (this.pictureBox3.Image != null)
					{
						this.pictureBox3.Image.Dispose();
						this.pictureBox3.Image = null;
					}

				
				
					if (this.pictureBox4.Image != null)
					{
						this.pictureBox4.Image.Dispose();
						this.pictureBox4.Image = null;
					}

				
					this.tabControl1.Refresh();

					slist = dbconn.GetSignatories(accountno);
						
					total = slist.Count;
					if (slist.Count == 0)
					{
						this.toolBarButton21.Enabled = false;
						this.toolBarButton22.Enabled = false;
						this.signbuttonVisible = false;
						this.SetNavigateRotateBut = false;
						
						this.toolBarButton4.Enabled = true;	

						this.toolBarButton2.Visible= true;
						this.toolBarButton23.Visible = true;
						this.toolBarButton29.Visible = true;


						this.toolBarButton2.Enabled = true;
						this.toolBarButton23.Enabled = true;
						this.toolBarButton29.Enabled = true;

						sform.SignName.Enabled = false;
						sform.expirydate.Enabled = false;
						sform.limit.Enabled = false;
						sform.CoSigneeReq.Enabled = false;
						sform.Group.Enabled = false;
					}
					else
					{
						this.toolBarButton29.Visible = true;
						this.toolBarButton2.Visible = true;
						this.toolBarButton23.Visible = true;
					
						this.tabControl1.Visible = true;

						this.signbuttonEnabled = true;
						current = 0;
						if ( slist.Count == 1)
						{
							this.toolBarButton21.Enabled = false;
							this.toolBarButton22.Enabled = false;
						
						}
						else if (slist.Count > 1)
						{
							this.toolBarButton21.Enabled = false;
							this.toolBarButton22.Enabled = true;
						}

						identity = Int32.Parse(slist.GetByIndex(current).ToString());
						dbconn.GetSignatoryInfo(identity,accountno);
				
						/*
							 if (sform == null)
							{
								sform = new CWSignatoryForm();
								sform.MdiParent = this;
								sform.Show();
							}
							else
							if (sform != null)
							{
								if (sform.Visible == false)
								{
									sform.Visible = true;
								}
								else
									sform.Show();
							}
							*/
				
						sform.SignId.Text = identity.ToString();
						sform.SignName.Text = dbconn.signame;
						sform.limit.Text = dbconn.limit.ToString();
				
						sform.expirydate.Value = System.DateTime.Parse(dbconn.expirydate);
						if (dbconn.cosignee == 1)
						{
							sform.CoSigneeReq.Checked = true;
							sform.limit.Enabled = false;
						}
						else
							if (dbconn.cosignee == 0)
						{
							sform.CoSigneeReq.Checked = false;
							sform.limit.Enabled = true;
						}
				
						sform.Group.Text = dbconn.grp;
					
						if (!this.tabControl1.Visible)
							this.tabControl1.Visible = true;
						if (this.pictureBox1.Image != null)
						{
							this.pictureBox1.Image.Dispose();
							this.pictureBox1.Image = null;
						}

						if (dbconn.GetSign1(identity,accountno))
						{
							this.pictureBox1.Image = Image.FromFile(pathtemp+"\\tempsign1.jpeg");
						}


						this.pictureBox1.Height = 92;
						this.pictureBox1.Width = 138;
				
						this.pictureBox2.Height = 92;
						this.pictureBox2.Width = 138;
					
						this.pictureBox3.Height = 92;
						this.pictureBox3.Width = 138;

						this.pictureBox4.Height = 92;
						this.pictureBox4.Width = 138;

						if (!this.tabControl1.Visible)
							this.tabControl1.Visible = true;
						if (this.pictureBox2.Image != null)
						{
							this.pictureBox2.Image.Dispose();
							this.pictureBox2.Image = null;
						}

						if (dbconn.GetSign2(identity,accountno))
						{
							this.pictureBox2.Image = Image.FromFile(pathtemp+"\\tempsign2.jpeg");
						}


						if (!this.tabControl1.Visible)
							this.tabControl1.Visible = true;
						if (this.pictureBox3.Image != null)
						{
							this.pictureBox3.Image.Dispose();
							this.pictureBox3.Image = null;
						}

						if (dbconn.GetThumb(identity,accountno))
						{
							this.pictureBox3.Image = Image.FromFile(pathtemp+"\\tempThumb.jpeg");
						}

						if (!this.tabControl1.Visible)
							this.tabControl1.Visible = true;
						if (this.pictureBox4.Image != null)
						{
							this.pictureBox4.Image.Dispose();
							this.pictureBox4.Image = null;
						}

						if (dbconn.GetPhoto(identity,accountno))
						{
							this.pictureBox4.Image = Image.FromFile(pathtemp+"\\tempPhoto.jpeg");
						}
					
						this.tabControl1.Refresh();

						CWSave(false,false,false);
						this.toolBarButton1.Enabled = false;
					}
					
				this.signinfo = false;
				}
			if (e.Button == this.toolBarButton6)
			{
				this.toolBarButton27.Pushed = false;
				this.toolBarButton28.Pushed = false;
				
				

				this.toolBarButton23.Visible = false;
				this.toolBarButton29.Visible = false;

				this.SetNavButtons = false;
				signno = 1;
				sign1 = true;
				sign2 = false;
				filename = "c:\\CaptureWiseFile\\" + accountno + identity.ToString() + signno.ToString() + ".jpeg";
			
				tabControl1.Visible = false;
				/*if (this.pictureBox1.Image != null)
				{
					this.pictureBox1.Image.Dispose();
					this.pictureBox1.Image = null;
				}*/
				
				/*this.toolBarButton1.Visible = false;
				this.toolBarButton4.Visible = false;

				this.toolBarButton5.Visible = false;
				this.toolBarButton6.Visible = false;
				this.toolBarButton7.Visible = false;

				this.toolBarButton8.Visible = true;
				
				this.toolBarButton9.Visible = true;
				this.toolBarButton9.Enabled = false;
				

				this.toolBarButton10.Visible = true;
				this.toolBarButton10.Enabled = false;*/
				
				CWButtonState(false,false,false,false,false,false,false,true,true,true,false);
				//CWButtonEnabled(false,false,false,false,false,false,false,true,false,true,false);
				
				this.signbuttonVisible = false;
				this.signbuttonEnabled = false;
				this.RotateButtonsEnable = false;
				sform.Visible = false;
				
				if (siform != null)
				{
					siform.Close();
					siform.Dispose();
						
				}
				this.SetNavigateRotateBut = false;
				
				try
				{
					FileInfo f =new FileInfo(pathtemp + "\\temp.jpeg");
					
					if (f.Exists)
					{
						siform = new CWSignImage(filename);
						siform.MdiParent = this;
						siform.Show();
					}
					else
					{
						MessageBox.Show("No Image Found in Previous Buffer, Please Scan Image");
					}
				}
				catch(System.IO.FileNotFoundException fne)
				{

				}
			}

			if (e.Button == this.toolBarButton7)
			{
				this.toolBarButton27.Pushed = false;
				this.toolBarButton28.Pushed = false;
				

				this.toolBarButton23.Visible = false;
				this.toolBarButton29.Visible = false;


				

				tabControl1.Visible = false;
				this.SetNavButtons = false;
				sign1 = false;
				sign2 = true;
				//this.ImageProcessButs = true;	
				signno = 2;
				/*if (this.pictureBox2.Image != null)
				{
					this.pictureBox2.Image.Dispose();
					this.pictureBox2.Image = null;
				}*/
				/*this.toolBarButton1.Visible = false;
				this.toolBarButton4.Visible = false;

				this.toolBarButton5.Visible = false;
				this.toolBarButton6.Visible = false;
				this.toolBarButton7.Visible = false;

				this.toolBarButton8.Visible = true;
				
				this.toolBarButton9.Visible = true;
				this.toolBarButton9.Enabled = false;
				

				this.toolBarButton10.Visible = true;
				this.toolBarButton10.Enabled = false;*/

				CWButtonState(false,false,false,false,false,false,false,true,true,true,false);
				//CWButtonEnabled(false,false,false,false,false,false,false,true,false,true,false);

				this.signbuttonVisible = false;
				this.signbuttonEnabled = false;
				this.RotateButtonsEnable = false;
				
				sform.Visible = false;

				this.SetNavigateRotateBut = false;
				if (siform != null)
				{
					siform.Close();
					siform.Dispose();
						
				}
				try
				{
					FileInfo f =new FileInfo(pathtemp + "\\temp.jpeg");
					
					if (f.Exists)
					{
						siform = new CWSignImage(filename);
						siform.MdiParent = this;
						siform.Show();
					}
					else
					{
						MessageBox.Show("No Image Found in Previous Buffer Please Scan Image");
					}
				}
				catch(System.IO.FileNotFoundException fne)
				{

				}
				
				
			} 

			if (e.Button == this.toolBarButton19)
			{
				this.toolBarButton27.Pushed = false;
				this.toolBarButton28.Pushed = false;
			
	
				this.toolBarButton23.Visible = false;
				this.toolBarButton29.Visible = false;

				

				tabControl1.Visible = false;
				this.SetNavButtons = false;
				signno = 3;
				sign1 = true;
				sign2 = false;
			
				filename = "c:\\CaptureWiseFile\\" + accountno + identity.ToString() + signno.ToString() + ".jpeg";
				/*if (this.pictureBox3.Image != null)
				{
					this.pictureBox3.Image.Dispose();
					
					this.pictureBox3.Image = null;
				}*/
				
				/*this.toolBarButton1.Visible = false;
				this.toolBarButton4.Visible = false;

				this.toolBarButton5.Visible = false;
				this.toolBarButton6.Visible = false;
				this.toolBarButton7.Visible = false;

				this.toolBarButton8.Visible = true;
				
				this.toolBarButton9.Visible = true;
				this.toolBarButton9.Enabled = false;
				

				this.toolBarButton10.Visible = true;
				this.toolBarButton10.Enabled = false;*/
				
				CWButtonState(false,false,false,false,false,false,false,true,true,true,false);
				//CWButtonEnabled(false,false,false,false,false,false,false,true,false,true,false);
				
				this.signbuttonVisible = false;
				this.signbuttonEnabled = false;
				this.RotateButtonsEnable = false;
				
				sform.Visible = false;
			
				this.SetNavigateRotateBut = false;
				if (siform != null)
				{
					siform.Close();
					siform.Dispose();
						
				}

				try
				{
					FileInfo f =new FileInfo(pathtemp + "\\temp.jpeg");
					
					if (f.Exists)
					{
						siform = new CWSignImage(filename);
						siform.MdiParent = this;
						siform.Show();
					}
					else
					{
						MessageBox.Show("No Image Found in Previous Buffer Please Scan Image");
					}
				}
				catch(System.IO.FileNotFoundException fne)
				{

				}
							
			}

			if (e.Button == this.toolBarButton20)
			{
				this.toolBarButton27.Pushed = false;
				this.toolBarButton28.Pushed = false;
				
				
				
				this.toolBarButton23.Visible = false;
				this.toolBarButton29.Visible = false;

				tabControl1.Visible = false;
				this.SetNavButtons = false;
				signno = 4;

			

				filename = "c:\\CaptureWiseFile\\" + accountno + identity.ToString() + signno.ToString() + ".jpeg";
				/*if (this.pictureBox4.Image != null)
				{
					this.pictureBox4.Image.Dispose();
					this.pictureBox4.Image = null;
				}*/
				
				
				/*this.toolBarButton1.Visible = false;
				this.toolBarButton4.Visible = false;

				this.toolBarButton5.Visible = false;
				this.toolBarButton6.Visible = false;
				this.toolBarButton7.Visible = false;

				this.toolBarButton8.Visible = true;
				
				this.toolBarButton9.Visible = true;
				this.toolBarButton9.Enabled = false;
				

				this.toolBarButton10.Visible = true;
				this.toolBarButton10.Enabled = false;*/
				
				CWButtonState(false,false,false,false,false,false,false,true,true,true,false);
				//CWButtonEnabled(false,false,false,false,false,false,false,true,false,true,false);
				
				this.signbuttonVisible = false;
				this.signbuttonEnabled = false;
				this.RotateButtonsEnable = false;
				
				sform.Visible = false;

				this.SetNavigateRotateBut = false;
				if (siform != null)
				{
					siform.Close();
					siform.Dispose();
						
				}
				
				try
				{
					FileInfo f =new FileInfo(pathtemp + "\\temp.jpeg");
					
					if (f.Exists)
					{
						siform = new CWSignImage(filename);
						siform.MdiParent = this;
						siform.Show();
					}
					else
					{
						MessageBox.Show("No Image Found in Previous Buffer Please Scan Image");
					}
				}
				catch(System.IO.FileNotFoundException fne)
				{

				}
				
			}

			if (e.Button == this.toolBarButton42)
			{
				this.toolBarButton27.Pushed = false;
				this.toolBarButton28.Pushed = false;
				

				this.toolBarButton23.Visible = false;
				this.toolBarButton29.Visible = false;


				

				tabControl1.Visible = false;
				this.SetNavButtons = false;
				sign1 = false;
				sign2 = false;
				//this.ImageProcessButs = true;	
				signno = 5;
				/*if (this.pictureBox2.Image != null)
				{
					this.pictureBox2.Image.Dispose();
					this.pictureBox2.Image = null;
				}*/
				/*this.toolBarButton1.Visible = false;
				this.toolBarButton4.Visible = false;

				this.toolBarButton5.Visible = false;
				this.toolBarButton6.Visible = false;
				this.toolBarButton7.Visible = false;

				this.toolBarButton8.Visible = true;
				
				this.toolBarButton9.Visible = true;
				this.toolBarButton9.Enabled = false;
				

				this.toolBarButton10.Visible = true;
				this.toolBarButton10.Enabled = false;*/

				CWButtonState(false,false,false,false,false,false,false,true,true,true,false);
				//CWButtonEnabled(false,false,false,false,false,false,false,true,false,true,false);

				this.signbuttonVisible = false;
				this.signbuttonEnabled = false;
				this.RotateButtonsEnable = false;
				
				sform.Visible = false;

				this.SetNavigateRotateBut = false;
				if (siform != null)
				{
					siform.Close();
					siform.Dispose();
						
				}
				try
				{
					FileInfo f =new FileInfo(pathtemp + "\\temp.jpeg");
					
					if (f.Exists)
					{
						siform = new CWSignImage(filename);
						siform.MdiParent = this;
						siform.Show();
					}
					else
					{
						MessageBox.Show("No Image Found in Previous Buffer Please Scan Image");
					}
				}
				catch(System.IO.FileNotFoundException fne)
				{

				}
				
				
			}
			
			if (e.Button == this.toolBarButton8)
			{
				/*
				 *************************************************
				code for aquiring data from device to be used later
				 ************************************************* 
				*/
				if (dev1.Checked ||dev2.Checked ||dev3.Checked ||dev4.Checked ||dev5.Checked )
				{
					RotateButtons = true;	
				
					if( ! msgfilter )
					{
						this.Enabled = false;
						msgfilter = true;
						Application.AddMessageFilter( this );
					}
				
					tw.Acquire();
				}
				else
				{
					MessageBox.Show("Please Select Device");
				}
				
			}

			if (e.Button == this.toolBarButton9)
			{
				try
				{
				if (siform.cropbmp == null)
				{
					MessageBox.Show("please crop signature from Image");
				}
				else
				{
					this.toolBarButton23.Visible = true;
					this.toolBarButton29.Visible = true;

					this.toolBarButton25.Visible = true;

					ImageProcessButsofUnCropped = false;
					this.ImageProcessButs = false;
					RotateButtons = false;
					sigcount++;
					if (signno == 1)
					{
						this.toolBarButton29.Visible = true;
						this.toolBarButton2.Visible = true;
						this.toolBarButton23.Visible = true;

						this.SetNavButtons = true;
						if (this.siform.Visible)
						{
							this.siform.Close();
							this.siform.Dispose();
						}
						CWButtonState(true,false,false,true,true,true,true,false,false,false,false);
						//CWButtonEnabled(false,false,false,true,false,true,true,false,false,false,true);

						this.signbuttonVisible = true;
						this.signbuttonEnabled = true;

						this.RotateButtonsEnable = true;
						this.tabControl1.Visible = true;
						
						if (pictureBox1.Image != null)
						{
							pictureBox1.Image.Dispose(); 
							pictureBox1.Image = null;
						}
						this.pictureBox1.Image = Image.FromFile(pathtemp + "\\temp3.jpeg");
						
						filename = "c:\\CaptureWiseFile\\" + accountno + identity.ToString() + "1.jpeg";
						
						Bitmap putinfolder =(Bitmap) Bitmap.FromFile(pathtemp + "\\temp1.jpeg");
						string fileindb=accountno + identity.ToString() + signno.ToString() + ".jpeg";
						
						putinfolder.Save(filename,ImageFormat.Jpeg);
						putinfolder.Dispose();
						
						FileStream fs = new FileStream(filename,FileMode.Open,FileAccess.Read);
						long len = fs.Length;
						fs.Close();

						string sqlinsert="insert into featuresofsig values('"+accountno+"',"+identity.ToString()+",1,BFILENAME('MYDIR', '" + fileindb +"'),"+len+",";
						/*
						 * 
						 * Image Preprocessing for Feature Extraction
						 * 
						 * */
						
						ImgPreprocessing.ImgPreprocessingClass ipc=new ImgPreprocessing.ImgPreprocessingClass();
						object no_return=null;
						ipc.preprocessing(1,ref no_return,(object)filename,(object)"c:\\temp.jpeg");
						
						/*
						 * 
						 * Feature Extraction Starts From Here
						 * 
						 * */
						
						FindEndPoins.FindEndPoinsClass fep=new FindEndPoins.FindEndPoinsClass();
						object no_end_points=null;
						fep.draw_paralleogram(1,ref no_end_points,(object)"c:\\temp.jpeg");
						sqlinsert+="'"+no_end_points.ToString()+"',";

						object hwr=null;
						HWRatio.HWClass hwc=new HWRatio.HWClass();
						hwc.img1(1,ref hwr,(object)"c:\\temp.jpeg");

						sqlinsert += "'"+Convert.ToString(System.Math.Round(Convert.ToDouble(hwr.ToString()),5))+"',";

						object no_ccpatterns=null;
						CCPatterns5.CCPatternsClass ccp=new CCPatterns5.CCPatternsClass();
						ccp.count_connected_pattern1(1,ref no_ccpatterns,(object)"c:\\temp.jpeg");
						Array db3 = no_ccpatterns as Array;
			
						if (db3 != null)
						{
							MessageBox.Show(db3.Length.ToString());
							int j=0;
							foreach (object i in db3)
							{
								if (j!=1)
									sqlinsert+="'"+i.ToString()+"',";
								if (j ==1)
								{
									sqlinsert+="'"+Convert.ToString(System.Math.Round(Convert.ToDouble(i.ToString()),5))+"',";
									break;
								}
								
								j++;
							}
						}

						
						sqlinsert +="'1')";
						MessageBox.Show(sqlinsert);
						




						dbconn.InsertSign1(filename,accountno,identity);
						dbconn.ExecuteNonQuery(sqlinsert);
						
						int kount=0;
						foreach (object i in db3)
						{
							if (kount >= 2)
							{
								sqlinsert= "insert into PatternNormalizedArea values('"+accountno+"',"+identity.ToString()+",1,"+Convert.ToString((kount-1))+",'"+Convert.ToString(System.Math.Round(Convert.ToDouble(i.ToString()),5))+"')";
								dbconn.ExecuteNonQuery(sqlinsert);
							}
							kount++;
						}
						if (!onesignadded)
						{
							
							slist = dbconn.GetSignatories(accountno);
						
							total = slist.Count;
							current = total -1;
							addSignatory = false;
						
							
							
							if ((slist.Count == 1) || (slist.Count == 0))
							{
								this.toolBarButton21.Enabled = false;
								this.toolBarButton22.Enabled = false;
							}
							else if (slist.Count >=2)
							{
								this.toolBarButton21.Enabled = true;
								this.toolBarButton22.Enabled = false;
							}
							onesignadded = true;
							this.SetNavButtons = true;
							this.toolBarButton4.Enabled = true;
						
							
							
							
							//	onesignadded = true;
						}
						
					}
					else
						if (signno == 2)
					{
						this.toolBarButton29.Visible = true;
						this.toolBarButton2.Visible = true;
						this.toolBarButton23.Visible = true;

						this.SetNavButtons = true;
						
						if (this.siform.Visible)
						{
							this.siform.Close();
							this.siform.Dispose();
						}
						CWButtonState(true,false,false,true,true,true,true,false,false,false,false);
						//CWButtonEnabled(false,false,false,true,false,true,true,false,false,false,true);
						
						this.signbuttonVisible = true;
						this.signbuttonEnabled = true;
						this.RotateButtonsEnable = true;
						this.tabControl1.Visible = true;

						if (pictureBox2.Image != null)
						{
							pictureBox2.Image.Dispose(); 
							pictureBox2.Image = null;
						}
						this.pictureBox2.Image = Image.FromFile(pathtemp + "\\temp4.jpeg");
						
						filename = "c:\\CaptureWiseFile\\" + accountno + identity.ToString() + signno.ToString() + ".jpeg";
						
						Bitmap putinfolder = (Bitmap) Bitmap.FromFile(pathtemp + "\\temp1.jpeg");
						putinfolder.Save(filename,ImageFormat.Jpeg);
						putinfolder.Dispose();
						string fileindb = accountno + identity.ToString() + "2.jpeg";

						FileStream fs = new FileStream(filename,FileMode.Open,FileAccess.Read);
						long len = fs.Length;
						fs.Close();

						string sqlinsert="insert into featuresofsig values('"+accountno+"',"+identity.ToString()+",2,BFILENAME('MYDIR', '" + fileindb +"'),"+len+",";
						/*
						 * 
						 * Image Preprocessing for Feature Extraction
						 * 
						 * */
						
						ImgPreprocessing.ImgPreprocessingClass ipc=new ImgPreprocessing.ImgPreprocessingClass();
						object no_return=null;
						ipc.preprocessing(1,ref no_return,(object)filename,(object)"c:\\temp.jpeg");
						
						/*
						 * 
						 * Feature Extraction Starts From Here
						 * 
						 * */
						
						FindEndPoins.FindEndPoinsClass fep=new FindEndPoins.FindEndPoinsClass();
						object no_end_points=null;
						fep.draw_paralleogram(1,ref no_end_points,(object)"c:\\temp.jpeg");
						sqlinsert+="'"+no_end_points.ToString()+"',";

						object hwr=null;
						HWRatio.HWClass hwc=new HWRatio.HWClass();
						hwc.img1(1,ref hwr,(object)"c:\\temp.jpeg");

						sqlinsert += "'"+Convert.ToString(System.Math.Round(Convert.ToDouble(hwr.ToString()),5))+"',";

						object no_ccpatterns=null;
						CCPatterns5.CCPatternsClass ccp=new CCPatterns5.CCPatternsClass();
						ccp.count_connected_pattern1(1,ref no_ccpatterns,(object)"c:\\temp.jpeg");
						Array db3 = no_ccpatterns as Array;
			
						if (db3 != null)
						{
							MessageBox.Show(db3.Length.ToString());
							int j=0;
							foreach (object i in db3)
							{
								if (j!=1)
									sqlinsert+="'"+i.ToString()+"',";
								if (j ==1)
								{
									sqlinsert+="'"+Convert.ToString(System.Math.Round(Convert.ToDouble(i.ToString()),5))+"',";
									break;
								}
								j++;
							}
						}

						
						sqlinsert +="'1')";
						
						
						dbconn.InsertSign2(filename,accountno,identity);
						dbconn.ExecuteNonQuery(sqlinsert);

						int kount1=0;
						foreach (object i in db3)
						{
							if (kount1 >= 2)
							{
								sqlinsert= "insert into PatternNormalizedArea values('"+accountno+"',"+identity.ToString()+",2,"+Convert.ToString((kount1-1))+",'"+Convert.ToString(System.Math.Round(Convert.ToDouble(i.ToString()),5))+"')";
								dbconn.ExecuteNonQuery(sqlinsert);
							}
							kount1++;
						}

						if (!onesignadded)
						{
							
							slist = dbconn.GetSignatories(accountno);
						
							total = slist.Count;
							current = total -1;
							addSignatory = false;
						
							
							
							if ((slist.Count == 1) || (slist.Count == 0))
							{
								this.toolBarButton21.Enabled = false;
								this.toolBarButton22.Enabled = false;
							}
							else if (slist.Count >=2)
							{
								this.toolBarButton21.Enabled = true;
								this.toolBarButton22.Enabled = false;
							}

							
							onesignadded = true;
							this.SetNavButtons = true;
							this.toolBarButton4.Enabled = true;
						}
				
			
					}
					else
						if (signno == 3)
					{
						this.SetNavButtons = true;
						if (this.siform.Visible)
						{
							this.siform.Close();
							this.siform.Dispose();
						}
						CWButtonState(true,false,false,true,true,true,true,false,false,false,false);
						//CWButtonEnabled(false,false,false,true,false,true,true,false,false,false,true);
						
						this.signbuttonVisible = true;
						this.signbuttonEnabled = true;
						this.RotateButtonsEnable = true;
						this.tabControl1.Visible = true;
					
						if (pictureBox3.Image != null)
						{
							pictureBox3.Image.Dispose(); 
							pictureBox3.Image = null;
						}
						this.pictureBox3.Image = Image.FromFile(pathtemp + "\\temp5.jpeg");
						
						filename = "c:\\CaptureWiseFile\\" + accountno + identity.ToString() + signno.ToString() + ".jpeg";

						Bitmap putinfolder = (Bitmap)Bitmap.FromFile(pathtemp + "\\temp1.jpeg");
						putinfolder.Save(filename,ImageFormat.Jpeg);
						putinfolder.Dispose();

						dbconn.InsertThumbImp(filename,accountno,identity);
			
					}
					else
						if (signno == 4)
					{
						this.SetNavButtons = true;
						if (this.siform.Visible)
						{
							this.siform.Close();
							this.siform.Dispose();
						}
						CWButtonState(true,false,false,true,true,true,true,false,false,false,false);
						//CWButtonEnabled(false,false,false,true,false,true,true,false,false,false,true);
						
						this.signbuttonVisible = true;
						this.signbuttonEnabled = true;
						this.RotateButtonsEnable = true;
						this.tabControl1.Visible = true;
					
						if (pictureBox4.Image != null)
						{
							pictureBox4.Image.Dispose(); 
							pictureBox4.Image = null;
						}

						this.pictureBox4.Image = Image.FromFile(pathtemp + "\\temp6.jpeg");
						
						filename = "c:\\CaptureWiseFile\\" + accountno + identity.ToString() + signno.ToString() + ".jpeg";

						Bitmap putinfolder = (Bitmap)Bitmap.FromFile(pathtemp + "\\temp1.jpeg");
						putinfolder.Save(filename,ImageFormat.Jpeg);
						putinfolder.Dispose();

						dbconn.InsertPhoto(filename,accountno,identity);
			
					}
					else if (signno == 5)
					{
						//Initializing Progress Bar
						FeatureExtractionProgress.Visible=true;

						FeatureExtractionProgress.Minimum=1;
						FeatureExtractionProgress.Maximum=10;
						FeatureExtractionProgress.Value = 1;
						FeatureExtractionProgress.Step =1;
						

						this.toolBarButton29.Visible = true;
						this.toolBarButton2.Visible = true;
						this.toolBarButton23.Visible = true;

						this.SetNavButtons = true;
						
						if (this.siform.Visible)
						{
							this.siform.Close();
							this.siform.Dispose();
						}
						CWButtonState(true,false,false,true,true,true,true,false,false,false,false);
						//CWButtonEnabled(false,false,false,true,false,true,true,false,false,false,true);
						
						this.signbuttonVisible = true;
						this.signbuttonEnabled = true;
						this.RotateButtonsEnable = true;
						this.tabControl1.Visible = true;

						if (pictureBox2.Image != null)
						{
							pictureBox2.Image.Dispose(); 
							pictureBox2.Image = null;
						}
						this.pictureBox2.Image = Image.FromFile(pathtemp + "\\temp4.jpeg");
						
						filename = "c:\\CaptureWiseFile\\" + accountno + identity.ToString() + signno.ToString() + ".jpeg";
						
						Bitmap putinfolder = (Bitmap) Bitmap.FromFile(pathtemp + "\\temp1.jpeg");
						putinfolder.Save(filename,ImageFormat.Jpeg);
						putinfolder.Dispose();
						string fileindb = accountno + identity.ToString() + "2.jpeg";

						FileStream fs = new FileStream(filename,FileMode.Open,FileAccess.Read);
						long len = fs.Length;
						fs.Close();
						int signumber = dbconn.getSignNum(accountno,identity.ToString());
						
						FeatureExtractionProgress.PerformStep();

						string sqlinsert="insert into featuresofsig values('"+accountno+"',"+identity.ToString()+","+signumber.ToString()+",BFILENAME('MYDIR', '" + fileindb +"'),"+len+",";
						/*
						 * 
						 * Image Preprocessing for Feature Extraction
						 * 
						 * */
						
						ImgPreprocessing.ImgPreprocessingClass ipc=new ImgPreprocessing.ImgPreprocessingClass();
						object no_return=null;
						ipc.preprocessing(1,ref no_return,(object)filename,(object)"c:\\temp.jpeg");
						
						/*
						 * 
						 * Feature Extraction Starts From Here
						 * 
						 * */
						
						FindEndPoins.FindEndPoinsClass fep=new FindEndPoins.FindEndPoinsClass();
						object no_end_points=null;
						fep.draw_paralleogram(1,ref no_end_points,(object)"c:\\temp.jpeg");
						sqlinsert+="'"+no_end_points.ToString()+"',";
						
						FeatureExtractionProgress.PerformStep();

						object hwr=null;
						HWRatio.HWClass hwc=new HWRatio.HWClass();
						hwc.img1(1,ref hwr,(object)"c:\\temp.jpeg");

						sqlinsert += "'"+Convert.ToString(System.Math.Round(Convert.ToDouble(hwr.ToString()),5))+"',";

						object no_ccpatterns=null;
						CCPatterns5.CCPatternsClass ccp=new CCPatterns5.CCPatternsClass();
						ccp.count_connected_pattern1(1,ref no_ccpatterns,(object)"c:\\temp.jpeg");
						Array db3 = no_ccpatterns as Array;
						FeatureExtractionProgress.PerformStep();
						int number_patterns = 0;
						if (db3 != null)
						{
							MessageBox.Show(db3.Length.ToString());
							int j=0;
							foreach (object i in db3)
							{
								if (j!=1)
								{
									sqlinsert+="'"+i.ToString()+"',";
									number_patterns = Convert.ToInt32(i.ToString());
								}
								if (j ==1)
								{
									sqlinsert+="'"+Convert.ToString(System.Math.Round(Convert.ToDouble(i.ToString()),5))+"',";
									break;
								}
								j++;
							}
						}

						sqlinsert += "'1')";
						
						
						dbconn.ExecuteNonQuery(sqlinsert);
						
						int kount2=0;
						foreach (object i in db3)
						{
							if (kount2 >= 2)
							{
								sqlinsert= "insert into PatternNormalizedArea values('"+accountno+"',"+identity.ToString()+","+signumber.ToString()+","+Convert.ToString((kount2-1))+",'"+Convert.ToString(System.Math.Round(Convert.ToDouble(i.ToString()),5))+"')";
								dbconn.ExecuteNonQuery(sqlinsert);
							}
							kount2++;
						}
						FeatureExtractionProgress.PerformStep();
						FeatureExtractionProgress.Visible = false;
						//Signature Verification Code 

						DataTable SigFeaturesTable = new DataTable();
						DataTable SigPatternFeatureTable = new DataTable();
						DataTable FeatureAccuracy = new DataTable();

						if (signumber >10)
						{
							MessageBox.Show("select SIGNUM,NO_END_POINTS,HWRATIO,NO_PATTERNS,NORMALIZEDRATIO from FEATURESOFSIG where ACCOUNT='"+accountno+"' and SIGID="+identity.ToString()+" and NO_PATTERNS="+number_patterns.ToString()+" and passed=1");
							MessageBox.Show("select PATTERNNO,NORMALIZEDRATIO from PATTERNNORMALIZEDAREA where ACCOUNT='"+accountno+"' and SIGID="+identity.ToString()+" and signum in (select Signum from FEATURESOFSIG where ACCOUNT='"+accountno+"' and SIGID="+identity.ToString()+" and NO_PATTERNS="+number_patterns.ToString()+")");
							SigFeaturesTable = dbconn.GetDataTable("select SIGNUM,NO_END_POINTS,HWRATIO,NO_PATTERNS,NORMALIZEDRATIO from FEATURESOFSIG where ACCOUNT='"+accountno+"' and SIGID="+identity.ToString()+" and NO_PATTERNS="+number_patterns.ToString());
							SigPatternFeatureTable = dbconn.GetDataTable("select PATTERNNO,NORMALIZEDRATIO from PATTERNNORMALIZEDAREA where ACCOUNT='"+accountno+"' and SIGID="+identity.ToString()+" and signum in (select Signum from FEATURESOFSIG where ACCOUNT='"+accountno+"' and SIGID="+identity.ToString()+" and NO_PATTERNS="+number_patterns.ToString()+")");
							int current_sig_number=0;
							int total_sig = 0;
							double total_accuracy = 0;
							double total_accuracy2 = 0;
							ArrayList total_accuracy1 = new ArrayList();
							if (SigFeaturesTable.Rows.Count != 0)
							{
								for (int find1 =0 ;find1 <=SigFeaturesTable.Rows.Count-1;find1++)
								{
									if (Convert.ToInt32(SigFeaturesTable.Rows[find1][0]) == signumber)
									{
										current_sig_number = find1;
										break;
									}
								}

								for (int find2=0 ;find2 <SigFeaturesTable.Rows.Count-1;find2++)
								{
									if (find2 != current_sig_number)
									{
										total_sig++;
										if (find2+1 != current_sig_number)
										{
											/*
											 * 
											 * To Add Accuracy of One Passed Sig with other Passed Sig,
											 *  Except the Current one
											 * 
											 * */
											/*
											 * 
											 * Start Code from Here
											 * 
											 * */
											double N_E_P1 = Convert.ToDouble(SigFeaturesTable.Rows[find2]["NO_END_POINTS"]) - Convert.ToDouble(SigFeaturesTable.Rows[current_sig_number]["NO_END_POINTS"]);
											double HW_RATIO1 = Convert.ToDouble(SigFeaturesTable.Rows[find2]["HWRATIO"]) - Convert.ToDouble(SigFeaturesTable.Rows[current_sig_number]["HWRATIO"]);
											double NO_PATTERNS1 = Convert.ToDouble(SigFeaturesTable.Rows[find2]["NO_PATTERNS"]) - Convert.ToDouble(SigFeaturesTable.Rows[current_sig_number]["NO_PATTERNS"]);
											double NORMALIZEDRATIO1 = Convert.ToDouble(SigFeaturesTable.Rows[find2]["NORMALIZEDRATIO"]) - Convert.ToDouble(SigFeaturesTable.Rows[current_sig_number]["NORMALIZEDRATIO"]);
									
											if (N_E_P1 < 0)
											{
												N_E_P1 = N_E_P1 * (-1);
											}
											if (HW_RATIO1 < 0)
											{
												HW_RATIO1 = HW_RATIO1 *(-1);
											}
											if (NO_PATTERNS1 < 0)
											{
												NO_PATTERNS1 = NO_PATTERNS1 * (-1);
											}
											if (NORMALIZEDRATIO1 < 0)
											{
												NORMALIZEDRATIO1 = NORMALIZEDRATIO1 * (-1);
											}
											/*
											 * 
											 * 
											 * Finding Accuracy
											 * 
											 * */
											if (N_E_P1 < 1)
											{
												N_E_P1 = N_E_P1*N_E_P1;
												N_E_P1 = System.Math.Exp((-2)*N_E_P1);
											}
											else if (N_E_P1 >= 1)
											{
												N_E_P1 = N_E_P1 * N_E_P1;
												N_E_P1 = System.Math.Exp((-0.25)*N_E_P1);
											}

											if (HW_RATIO1 < 1)
											{
												HW_RATIO1 = HW_RATIO1 * HW_RATIO1;
												HW_RATIO1 = System.Math.Exp((-2)*HW_RATIO1);
											}
											else if (HW_RATIO1 >= 1)
											{
												HW_RATIO1 = HW_RATIO1 * HW_RATIO1;
												HW_RATIO1 = System.Math.Exp((-0.25)*HW_RATIO1);
											}

											if (NO_PATTERNS1 < 1)
											{
												NO_PATTERNS1  = NO_PATTERNS1 * NO_PATTERNS1;
												NO_PATTERNS1 = System.Math.Exp((-2)*NO_PATTERNS1);
											}
											else if (NO_PATTERNS1 >= 1)
											{
												NO_PATTERNS1 = NO_PATTERNS1 * NO_PATTERNS1;
												NO_PATTERNS1 = System.Math.Exp((-0.25)*NO_PATTERNS1);
											}

											if (NORMALIZEDRATIO1 < 1)
											{
												NORMALIZEDRATIO1 = NORMALIZEDRATIO1 * NORMALIZEDRATIO1;
												NORMALIZEDRATIO1 = System.Math.Exp((-2)*NORMALIZEDRATIO1);
											}
											else if (NORMALIZEDRATIO1 >= 1)
											{
												NORMALIZEDRATIO1 = NORMALIZEDRATIO1 * NORMALIZEDRATIO1;
												NORMALIZEDRATIO1 = System.Math.Exp((-0.25)*NORMALIZEDRATIO1);
											}

											/*
											 * 
											 * 
											 * Find Mean Accuracy
											 *
											 * 
											 **/ 
											//MessageBox.Show(N_E_P1.ToString() +"  " +HW_RATIO1.ToString() +"  "+NO_PATTERNS.ToString()+"  "+NORMALIZEDRATIO.ToString());
											total_accuracy2 += N_E_P1+HW_RATIO1+NO_PATTERNS1+NORMALIZEDRATIO1;
											total_accuracy1.Add((object)total_accuracy2);
										}



										double N_E_P = Convert.ToDouble(SigFeaturesTable.Rows[find2]["NO_END_POINTS"]) - Convert.ToDouble(SigFeaturesTable.Rows[current_sig_number]["NO_END_POINTS"]);
										double HW_RATIO = Convert.ToDouble(SigFeaturesTable.Rows[find2]["HWRATIO"]) - Convert.ToDouble(SigFeaturesTable.Rows[current_sig_number]["HWRATIO"]);
										double NO_PATTERNS = Convert.ToDouble(SigFeaturesTable.Rows[find2]["NO_PATTERNS"]) - Convert.ToDouble(SigFeaturesTable.Rows[current_sig_number]["NO_PATTERNS"]);
										double NORMALIZEDRATIO = Convert.ToDouble(SigFeaturesTable.Rows[find2]["NORMALIZEDRATIO"]) - Convert.ToDouble(SigFeaturesTable.Rows[current_sig_number]["NORMALIZEDRATIO"]);
									
										if (N_E_P < 0)
										{
											N_E_P = N_E_P * (-1);
										}
										if (HW_RATIO < 0)
										{
											HW_RATIO = HW_RATIO *(-1);
										}
										if (NO_PATTERNS < 0)
										{
											NO_PATTERNS = NO_PATTERNS * (-1);
										}
										if (NORMALIZEDRATIO < 0)
										{
											NORMALIZEDRATIO = NORMALIZEDRATIO * (-1);
										}
										/*
										 * 
										 * 
										 * Finding Accuracy
										 * 
										 * */
										if (N_E_P < 1)
										{
											N_E_P = N_E_P*N_E_P;
											N_E_P = System.Math.Exp((-2)*N_E_P);
										}
										else if (N_E_P >= 1)
										{
											N_E_P = N_E_P * N_E_P;
											N_E_P = System.Math.Exp((-0.25)*N_E_P);
										}

										if (HW_RATIO < 1)
										{
											HW_RATIO = HW_RATIO * HW_RATIO;
											HW_RATIO = System.Math.Exp((-2)*HW_RATIO);
										}
										else if (HW_RATIO >= 1)
										{
											HW_RATIO = HW_RATIO * HW_RATIO;
											HW_RATIO = System.Math.Exp((-0.25)*HW_RATIO);
										}

										if (NO_PATTERNS < 1)
										{
											NO_PATTERNS  = NO_PATTERNS * NO_PATTERNS;
											NO_PATTERNS = System.Math.Exp((-2)*NO_PATTERNS);
										}
										else if (NO_PATTERNS >= 1)
										{
											NO_PATTERNS = NO_PATTERNS * NO_PATTERNS;
											NO_PATTERNS = System.Math.Exp((-0.25)*NO_PATTERNS);
										}

										if (NORMALIZEDRATIO < 1)
										{
											NORMALIZEDRATIO = NORMALIZEDRATIO * NORMALIZEDRATIO;
											NORMALIZEDRATIO = System.Math.Exp((-2)*NORMALIZEDRATIO);
										}
										else if (NORMALIZEDRATIO >= 1)
										{
											NORMALIZEDRATIO = NORMALIZEDRATIO * NORMALIZEDRATIO;
											NORMALIZEDRATIO = System.Math.Exp((-0.25)*NORMALIZEDRATIO);
										}

										/*
										 * 
										 * 
										 * Find Mean Accuracy
										 *
										 * 
										 **/ 
										MessageBox.Show(N_E_P.ToString() +"  " +HW_RATIO.ToString() +"  "+NO_PATTERNS.ToString()+"  "+NORMALIZEDRATIO.ToString());
										total_accuracy += N_E_P+HW_RATIO+NO_PATTERNS+NORMALIZEDRATIO;
										
									}
								}
								total_accuracy = total_accuracy/total_sig;
								if (total_accuracy > 0.9)
								{
									MessageBox.Show("Got it OKEY");
								}
							}//eof if
							else
							{
								MessageBox.Show("No Match Found in this Signatory");
							}
							
						}


						
						if (!onesignadded)
						{
							
							slist = dbconn.GetSignatories(accountno);
						
							total = slist.Count;
							current = total -1;
							addSignatory = false;
						
							
							
							if ((slist.Count == 1) || (slist.Count == 0))
							{
								this.toolBarButton21.Enabled = false;
								this.toolBarButton22.Enabled = false;
							}
							else if (slist.Count >=2)
							{
								this.toolBarButton21.Enabled = true;
								this.toolBarButton22.Enabled = false;
							}

							
							onesignadded = true;
							this.SetNavButtons = true;
							this.toolBarButton4.Enabled = true;
						}
				
			
					}
					this.tabControl1.Refresh();

					sform.Visible = true;
					/*	if (signno == 1)
						{
							MessageBox.Show("inserting sign1");
							siform.Close();
							FileStream fs = new FileStream(filename,FileMode.Open,FileAccess.Read);
							int len =(int) fs.Length;
							fs.Close();
							string fname = accountno + identity.ToString()+signno.ToString()+".jpeg";
							dbconn.InsertSign1(fname,accountno,identity,len);
						//	this.toolBarButton9.Enabled = false;
						//	this.toolBarButton10.Enabled = false;
						//	this.toolBarButton8.Enabled = true;
							CWButtonState(false,false,false,false,false,false,false,true,false,false,false);
							signno = 2;
						}
						else if (signno == 2)
						{

							filename = "c:\\CaptureWiseFile\\" + accountno + identity.ToString() + signno.ToString() + ".jpeg";
							FileStream fs = new FileStream(filename,FileMode.Open,FileAccess.Read);
							int len =(int) fs.Length;
							fs.Close();
						
							MessageBox.Show("inserting sign2");
							siform.Close();
							string fname = accountno + identity.ToString()+signno.ToString()+".jpeg";
							dbconn.InsertSign2(fname,accountno,identity,len);
						
							//		this.toolBarButton8.Visible = false;
							//		this.toolBarButton9.Visible = false;
							//		this.toolBarButton10.Visible= false;
						
							//		this.toolBarButton4.Visible = true;
							//		this.toolBarButton4.Enabled = true;
							//		this.toolBarButton14.Visible = true;

							CWButtonState(false,false,false,true,false,false,false,false,false,false,true);
						


						
						}*/
					/*if (this.siform.Visible)
					{
						this.siform.Close();
						this.siform.Dispose();
					}
					CWButtonState(true,false,false,true,true,true,true,false,false,false,true);
					CWButtonEnabled(false,false,false,true,false,true,true,false,false,false,true);
					this.RotateButtonsEnable = false;
					this.tabControl1.Visible = true;
					
					if (sign1)
						this.pictureBox1.Image = Image.FromFile("c:\\temp3.jpeg");
					if (sign2)
						this.pictureBox2.Image = Image.FromFile("c:\\temp4.jpeg");
					int imgid = dbconn.GetMaxImgId();
					imgid++;
					string fname = accountno+ identity.ToString() + imgid.ToString() + ".jpeg";
					dbconn.InsertImage(imgid,accountno,identity,fname);*/
				}
				this.tabControl1.SelectedIndex = this.tabControl1.SelectedIndex;
			}
			catch(System.NullReferenceException nre)
			{
					MessageBox.Show("Please Scan Image, There is no image in buffer");
			}

			}

			if (e.Button == this.toolBarButton10)
			{
			
				ImageProcessButsofUnCropped = false;	

				
				
				this.toolBarButton23.Visible = true;
				this.toolBarButton29.Visible = true;

				CWButtonState(true,false,false,true,true,true,true,false,false,false,false);
				//CWButtonEnabled(false,false,false,true,true,true,true,false,false,false,true);
				
				this.ImageProcessButs = false;

				this.SetNavButtons = true;
				this.signbuttonVisible = true;
				this.signbuttonEnabled = true;
				if (!onesignadded)
				{
						
						this.SetNavButtons = false;
						this.toolBarButton4.Enabled = false;	
						this.toolBarButton23.Visible = false;
						this.toolBarButton29.Visible = false;

				}
				this.RotateButtons = false;
				
				if (sign1)
					sign1= false;

				if(sign2)
					sign2=false;

				if (siform != null)
				{
					if (siform.Visible)
					{
						siform.Close();
						siform.Dispose();
					}
				}
				this.tabControl1.Visible = true;
				sform.Visible = true;
				
				
			}
			//
			//Logout Button
			//
			if (e.Button == this.toolBarButton14)
			{
				this.Text = "Capture Wise Application";
				this.menuItem2.Enabled = true;
				this.menuItem3.Enabled = true;
				this.menuItem16.Enabled = true;
				
				this.menuItem15.Visible = true;
				this.menuItem17.Visible = false;
				this.menuItem18.Visible = false;
				
				
				if (dbconn.cap)
				{
					this.menuItem2.Enabled = true;
					this.toolBarButton15.Enabled = true;
				}
				else
				{
					this.menuItem2.Enabled = false;
					this.toolBarButton15.Enabled = false;
				}

				if (dbconn.mod)
				{
					this.menuItem3.Enabled = true;
					this.toolBarButton16.Enabled = true;
				}
				else
				{
					this.menuItem3.Enabled = false;
					this.toolBarButton16.Enabled = false;
				}

				if (dbconn.ver)
				{
					this.menuItem16.Enabled = true;
					this.toolBarButton24.Enabled = true;
				}
				else
				{
					this.menuItem16.Enabled = false;
					this.toolBarButton24.Enabled = false;
				}
				

				this.SetNavButtons = false;
				sign1 = false;
				sign2 = false;
				sigcount = 0;
				this.menuItem2.Enabled = true;
				CWButtonState(false,false,false,false,false,false,false,false,false,false,false);
				this.RotateButtons = false;
				this.toolBarButton25.Visible = false;
				this.StartupButtons = true;
				this.signbuttonVisible = false;
				this.toolBarButton23.Visible = false;
				this.toolBarButton29.Visible = false;
				this.SetNavigateRotateBut = false;
				this.disposeResources();

				
				try
				{
					if (iform != null)
					{
						if (this.iform.Visible == true)
						{
							iform.Close();
							iform.Dispose();
						}
					}
					if (adform != null)
					{
						if (adform.Visible == true)
						{
							adform.Visible = false;
							adform.Dispose();
						}
					}
					if (sform != null)
					{
						if (this.sform.Visible == true)
						{
							sform.Close();
							sform.Dispose();
						}
					}
					
					if (siform != null)
					{
						if (siform.Visible)
						{
							siform.Close();
							siform.Dispose();
						}
					}

					if (asform != null)
					{
						if (asform.Visible)
						{
							asform.Close();
							asform.Dispose();
						}
					}

					if (crform != null)
					{
						if (crform.Visible)
						{
							crform.Close();
							crform.Dispose();
						}
					}
					
				}
				catch( System.Exception ee)
				{
					
				}
				
			}
			if (e.Button == this.toolBarButton11)
			{
				siform.cropbmpshow.RotateFlip(RotateFlipType.Rotate90FlipX);
				siform.pictureBox2.Image = (Image) siform.cropbmpshow;
				siform.Invalidate();
			}

			if (e.Button == this.toolBarButton12)
			{
				siform.cropbmpshow.RotateFlip(RotateFlipType.Rotate90FlipNone);
				siform.pictureBox2.Image = (Image) siform.cropbmpshow;
				siform.Invalidate();
			}

			if (e.Button == this.toolBarButton13)
			{
				siform.cropbmpshow.RotateFlip(RotateFlipType.Rotate180FlipNone);
				siform.pictureBox2.Image = (Image) siform.cropbmpshow;
				siform.Invalidate();
			}
			if (e.Button == this.toolBarButton18)
			{
				Application.Exit();
			}

			if (e.Button == this.toolBarButton26)
			{
				siform.pictureBox2.Height = 250;
				siform.pictureBox2.Width = 180;
				siform.pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
				siform.pictureBox2.Refresh();
			}

			if (e.Button == this.toolBarButton27)
			{
				if (this.toolBarButton28.Pushed)
				{
					this.toolBarButton28.Pushed = false;
				}
				siform.pictureBox2.Height = 250;
				siform.pictureBox2.Width = 180;
				siform.pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
				siform.pictureBox2.Refresh();
			}

			if (e.Button == this.toolBarButton28)
			{
				if (this.toolBarButton27.Pushed)
				{
					this.toolBarButton27.Pushed = false;
				}
				siform.pictureBox2.SizeMode = PictureBoxSizeMode.AutoSize;
				siform.pictureBox2.Refresh();
			}

			
			if (e.Button == this.toolBarButton30)
			{
				if (this.toolBarButton32.Pushed)
				{
					this.toolBarButton32.Pushed = false;
				}
			}

			if (e.Button == this.toolBarButton31)
			{
				siform.pictureBox1.Width = Image.FromFile(pathtemp + "\\temp.jpeg").Width/siform.scale;
				siform.pictureBox1.Height = Image.FromFile(pathtemp + "\\temp.jpeg").Height/siform.scale;
				siform.currentscale = siform.scale;
			}

			if (e.Button == this.toolBarButton32)
			{
				if (this.toolBarButton30.Pushed)
				{
					this.toolBarButton30.Pushed = false;
				}
			}

			if (e.Button == this.toolBarButton39)
			{
				switch (tabControl1.SelectedIndex)
				{
					case 0:
					{
						((Bitmap)(pictureBox1.Image)).RotateFlip(RotateFlipType.Rotate90FlipNone);
						pictureBox1.Invalidate();
						break;
					}
					case 1:
					{
						((Bitmap)(pictureBox2.Image)).RotateFlip(RotateFlipType.Rotate90FlipNone);
						pictureBox2.Invalidate();
						break;
					}
					case 2:
					{
						((Bitmap)(pictureBox3.Image)).RotateFlip(RotateFlipType.Rotate90FlipNone);
						pictureBox3.Invalidate();
						break;
					}
					case 3:
					{
						((Bitmap)(pictureBox4.Image)).RotateFlip(RotateFlipType.Rotate90FlipNone);
						pictureBox4.Invalidate();
						break;
					}
				}

			}

			if (e.Button == this.toolBarButton40)
			{
				switch (tabControl1.SelectedIndex)
				{
					case 0:
					{
						((Bitmap)(pictureBox1.Image)).RotateFlip(RotateFlipType.Rotate180FlipNone);
						pictureBox1.Invalidate();
						break;
					}
					case 1:
					{
						((Bitmap)(pictureBox2.Image)).RotateFlip(RotateFlipType.Rotate180FlipNone);
						pictureBox2.Invalidate();
						break;
					}
					case 2:
					{
						((Bitmap)(pictureBox3.Image)).RotateFlip(RotateFlipType.Rotate180FlipNone);
						pictureBox3.Invalidate();
						break;
					}
					case 3:
					{
						((Bitmap)(pictureBox4.Image)).RotateFlip(RotateFlipType.Rotate180FlipNone);
						pictureBox4.Invalidate();
						break;
					}
				}
			}

			if (e.Button == this.toolBarButton41)
			{
				switch (tabControl1.SelectedIndex)
				{
					case 0:
					{
						((Bitmap)(pictureBox1.Image)).RotateFlip(RotateFlipType.Rotate270FlipNone);
						pictureBox1.Invalidate();
						break;
					}
					case 1:
					{
						((Bitmap)(pictureBox2.Image)).RotateFlip(RotateFlipType.Rotate270FlipNone);
						pictureBox2.Invalidate();
						break;
					}
					case 2:
					{
						((Bitmap)(pictureBox3.Image)).RotateFlip(RotateFlipType.Rotate270FlipNone);
						pictureBox3.Invalidate();
						break;
					}
					case 3:
					{
						((Bitmap)(pictureBox4.Image)).RotateFlip(RotateFlipType.Rotate270FlipNone);
						pictureBox4.Invalidate();
						break;
					}
				}
			}
							
		}

		public void CWButtonState(bool button1,bool button2,bool button3,bool button4,bool button5,bool button6,bool button7,bool button8,bool button9,bool button10,bool button11)
		{
			this.toolBarButton1.Visible = button1;
			this.toolBarButton2.Visible = button2;
			this.toolBarButton3.Visible = button3;
			this.toolBarButton4.Visible = button4;
			this.toolBarButton5.Visible = button5;
			this.toolBarButton6.Visible = button6;
			this.toolBarButton7.Visible = button7;
			this.toolBarButton8.Visible = button8;
			this.toolBarButton9.Visible = button9;
			this.toolBarButton10.Visible = button10;
			this.toolBarButton14.Visible = button11;
		}

		public void CWButtonEnabled(bool button1,bool button2,bool button3,bool button4,bool button5,bool button6,bool button7,bool button8,bool button9,bool button10,bool button11)
		{
			this.toolBarButton1.Enabled = button1;
			this.toolBarButton2.Enabled= button2;
			this.toolBarButton3.Enabled = button3;
			this.toolBarButton4.Enabled = button4;
			this.toolBarButton5.Enabled = button5;
			this.toolBarButton6.Enabled = button6;
			this.toolBarButton7.Enabled = button7;
			this.toolBarButton8.Enabled = button8;
			this.toolBarButton9.Enabled = button9;
			this.toolBarButton10.Enabled = button10;
			this.toolBarButton14.Enabled = button11;
		}

		public void CWSave(bool properties,bool maindet,bool sinfo)
		{
			prop = properties;
			maindetails = maindet;
			signinfo = sinfo;
		}

		private void dev1_Click(object sender, System.EventArgs e)
		{
			tw.SelectDev(dev1.Text);
			this.CheckMenu(true,false,false,false,false);
			
		}

		private void dev2_Click(object sender, System.EventArgs e)
		{
			tw.SelectDev(dev2.Text);
			this.CheckMenu(false,true,false,false,false);
		}

		private void dev3_Click(object sender, System.EventArgs e)
		{
			tw.SelectDev(dev3.Text);
			this.CheckMenu(false,false,true,false,false);
		}

		private void dev4_Click(object sender, System.EventArgs e)
		{
			tw.SelectDev(dev4.Text);
			this.CheckMenu(false,false,false,true,false);
		}

		private void dev5_Click(object sender, System.EventArgs e)
		{
			tw.SelectDev(dev5.Text);
			this.CheckMenu(false,false,false,false,true);
		}

		private void menuItem11_Click(object sender, System.EventArgs e)
		{
			if (this.toolBar1.Visible)
			{
				this.toolBar1.Hide();
			}
			else
			if (!this.toolBar1.Visible)
			{
				this.toolBar1.Visible = true;
			}
			
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			tabControl1.Width = this.Width;
			
	 		this.tabControl1.Location = new System.Drawing.Point(0, this.Height - tabControl1.Height - 40);
			if (!dbconn.connected)
			{
				MessageBox.Show("DataBase is not present or There is some problem with drivers");
				Application.Exit();
			}
			if (!dbconn.ConfUser(username,domain))
			{
				MessageBox.Show("You are not Autherized to use this Application");
				Application.Exit();
			}
			else
			{
				if (dbconn.cap)
				{
					this.menuItem2.Enabled = true;
					this.toolBarButton15.Enabled = true;
				}
				else
				{
					this.menuItem2.Enabled = false;
					this.toolBarButton15.Enabled = false;
				}

				if (dbconn.mod)
				{
					this.menuItem3.Enabled = true;
					this.toolBarButton16.Enabled = true;
				}
				else
				{
					this.menuItem3.Enabled = false;
					this.toolBarButton16.Enabled = false;
				}

				if (dbconn.ver)
				{
					this.menuItem16.Enabled = true;
					this.toolBarButton24.Enabled = true;
				}
				else
				{
					this.menuItem16.Enabled = false;
					this.toolBarButton24.Enabled = false;
				}
			}
		}

		public bool SaveButton
		{
			get
			{
				return this.toolBarButton1.Enabled;
			}
			set
			{
				this.toolBarButton1.Enabled = value;
			}
		}
		
		public bool RotateButtons
		{

			set
			{
				this.toolBarButton11.Visible = value;
				this.toolBarButton12.Visible = value;
				this.toolBarButton13.Visible = value;
			}
		}
		

		public bool RotateButtonsEnable
		{
			set
			{
				this.toolBarButton11.Enabled = value;
				this.toolBarButton12.Enabled = value;
				this.toolBarButton13.Enabled = value;
			}
		}

		public bool ScanButtons
		{
			set
			{
				this.toolBarButton8.Visible = value;
				this.toolBarButton9.Visible = value;
				this.toolBarButton10.Visible = value;
			}
		}
		
		

		public bool StartupButtons
		{
			set
			{
				this.toolBarButton15.Visible = value;
				this.toolBarButton16.Visible = value;
				this.toolBarButton17.Visible = value;
				this.toolBarButton18.Visible = value;
				this.toolBarButton24.Visible = value;
			}
		}
		public bool SignButtonsPropertyEnabled
		{
			set
			{
				this.toolBarButton6.Enabled = value;
				this.toolBarButton7.Enabled = value;
			}
		}

		public bool Signaccept
		{
			set
			{
				this.toolBarButton9.Enabled = value;
			}
		}
		public bool sign1val
		{
			get
			{
				return this.sign1;
			}
		}
		public bool sign2val
		{
			get
			{
				return this.sign2;
			}
		}

		public string tempval
		{
			get
			{
				return pathtemp;
			}
		}
		public int signnoval
		{
			get
			{
				return signno;
			}
		}
		
		public bool signbuttonEnabled
		{
			set
			{
				this.toolBarButton6.Enabled = value;
				this.toolBarButton7.Enabled = value;
				this.toolBarButton19.Enabled = value;
				this.toolBarButton20.Enabled = value;
				this.toolBarButton42.Enabled = value;
			}
		}

		public bool signbuttonVisible
		{
			set
			{
				this.toolBarButton6.Visible = value;
				this.toolBarButton7.Visible = value;
				this.toolBarButton19.Visible = value;
				this.toolBarButton20.Visible = value;
				this.toolBarButton42.Visible = value;
			}
		}

		public bool savesignname
		{
			set
			{
				signinfo = value;
			}
		}


		public void disposeResources()
		{
			if (this.tabControl1 != null)
			{
				if (this.tabControl1.Visible)
				{
					if (this.pictureBox1.Image != null)
					{
						this.pictureBox1.Image.Dispose();
					}
					if (this.pictureBox2.Image != null)
					{
						this.pictureBox2.Image.Dispose();
					}
					if (this.pictureBox3.Image != null)
					{
						this.pictureBox3.Image.Dispose();
					}
					if (this.pictureBox4.Image != null)
					{
						this.pictureBox4.Image.Dispose();
					}
					this.tabControl1.Visible = false;
				}
			}
		}

		private void menuItem5_Click(object sender, System.EventArgs e)
		{
			srform = new CWApplication.CWSetResolutionForm();
			srform.MdiParent = this;
			srform.Show();
			
			if (srform.flag)
			{
	
				resx = Int32.Parse(srform.Xlen.Text);
				resy = Int32.Parse(srform.Ylen.Text);
			}
		}

		private void Form1_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			
		}

		private void menuItem15_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		public int Xlen
		{
			get
			{
				return resx;
			}
		}
		public int Ylen
		{
			get
			{
				return resy;
			}
		}
		public bool SetNavButtons
		{
			set
			{
				this.toolBarButton21.Visible = value;
				this.toolBarButton22.Visible = value;
			}
		}

		public void CheckMenu(bool men1,bool men2,bool men3,bool men4,bool men5)
		{
			this.dev1.Checked = men1;
			this.dev2.Checked = men2;
			this.dev3.Checked = men3;
			this.dev4.Checked = men4;
			this.dev5.Checked = men5;
		}

		public bool SaveSignInfo
		{
			set
			{
				this.signinfo = value;
			}
		}

		/*
		 * 
		 * Created on 25-03-2004
		 * Purpose Contains Code for Save Signatory
		 * 
		 * 
			*/
		public void SaveSignatoryInfo()
		{
			
			bool correct = true;
			if (sform.CoSigneeReq.Checked)
			{
				cosignee = 1;
				limit = 0;
			}
			else
			{
				cosignee = 0;
				if (sform.limit.Text == "" || sform.limit.Text.Length > 8)
				{
					MessageBox.Show("please Enter Valid Limit");
					sform.limit.Text = "";
					correct = false;
				}
				else
				{
					try
					{
						limit = Int32.Parse(sform.limit.Text);
					}
					catch(System.FormatException fe)
					{
						MessageBox.Show("Please Enter valid limit1");
						sform.limit.Text = "";
						correct = false;

					}
				}
						
			}


							

			if ( sform.expirydate.Value.ToShortDateString() == "")
			{
				MessageBox.Show("Please Select Date");
				correct = false;
			}
			else
				expiry_date = sform.expirydate.Value.ToShortDateString();

			signname = sform.SignName.Text;
			if (signname == "")
			{
				MessageBox.Show("Please Enter Name");
				correct = false;
			}

			identity = Int32.Parse(sform.SignId.Text);
			
			grp = sform.Group.Text;
					
			

			if (correct)
			{
				if (dbconn.checkSignatoryExists(identity,accountno))
				{
					MessageBox.Show("update");
					dbconn.UpdateSignatory(identity,accountno,signname,expiry_date,cosignee,limit,grp,sform.SignatoryStatus.Text);
				}
				else
				{
					
						MessageBox.Show("To Save this Signatory Please Capture Atleast One sign");
						

						
						dbconn.EnterNewSignatory(identity,signname,accountno,expiry_date,cosignee,limit,grp,sform.SignatoryStatus.Text);
						onesignadded = false;
						this.toolBarButton21.Enabled = false;
						this.toolBarButton22.Enabled = false;
						this.toolBarButton4.Enabled = false;						
						/*if (addSignatory)
						{
							slist = dbconn.GetSignatories(accountno);
						
							total = slist.Count;
							current = total -1;
							addSignatory = false;
						
							
							
							if ((slist.Count == 1) || (slist.Count == 0))
							{
								this.toolBarButton21.Enabled = false;
								this.toolBarButton22.Enabled = false;
							}
							else if (slist.Count >=2)
							{
								this.toolBarButton21.Enabled = true;
								this.toolBarButton22.Enabled = false;
							}


						}*/
					
				}
					

				/*		this.toolBarButton1.Enabled = false;
								this.toolBarButton5.Enabled = false;
								this.toolBarButton6.Visible = true;
								this.toolBarButton6.Enabled = true;*/
				//CWBututonState(false,false,false,false,false,true,false,false,false,false,true);
				//this.SignButtonsPropertyEnabled = true;
				this.signbuttonVisible = true;
				this.signbuttonEnabled = true;
				this.toolBarButton1.Enabled = false;
				
				
				CWSave(false,false,false);
			}
		}

		public bool SaveCR()
		{
			string gp1;
			string gp2;
			string gp3;
			string gp4; 
			string gp5;
			string gp6;
			int crosslimit;
			string crlimit ;
			crform.CRefernceGrid.SelectNextControl((Control)crform.CRefernceGrid,true,true,true,true);
			
			DataTable dt = (DataTable) crform.CRefernceGrid.DataSource;
			

			
				
				for (int i=0;i<20;i++)
				{
					gp1 = dt.Rows[i][1].ToString();
					
					gp2 = dt.Rows[i][2].ToString();
					gp3 = dt.Rows[i][3].ToString();
					gp4 = dt.Rows[i][4].ToString();
					gp5 = dt.Rows[i][5].ToString();
					gp6 = dt.Rows[i][6].ToString();

					

					//if ((gp1 != null)||(gp2 != null)||(gp3 != null)||(gp4 != null)||(gp5 != null)||(gp6 != null))
					if ((gp1.Length > 0)||(gp2.Length > 0 )||(gp3.Length > 0)||(gp4.Length > 0)||(gp5.Length > 0 )||(gp6.Length > 0 ))
					{
						if (dt.Rows[i][7].ToString().Length == 0)
						{
							
								return false;
						}
					}
					
			
					if (dt.Rows[i][7].ToString() != null)
					{
						if ((gp1 != null)||(gp2 != null)||(gp2 != null)||(gp3 != null)||(gp4 != null)||(gp5 != null)||(gp6 != null))
						{
						}
						else
						{
							
							return false;
						}
					}




					if (dt.Rows[i][7].ToString().Length > 0)
					{
						try
						{
							crosslimit = Int32.Parse(dt.Rows[i][7].ToString());

						}
						catch(System.FormatException fe)
						{
							
							MessageBox.Show(fe.Message);
							return false;
						}
						crlimit = crosslimit.ToString();

					}
					else
						crlimit = dt.Rows[i][7].ToString();
				
					
					dbconn.UpdateCrossReference(accountno,i,gp1,gp2,gp3,gp4,gp5,gp6,crlimit);
				
		
				}
			
			return true;

		}

		public bool crossrefsave
		{
			set
			{
				savecrossref = value;
			}
		}

		public bool MainDetailsUpdate
		{
			set
			{
				maindetails = value;
			}
		}
		/*
		 * Created on 27 march
		 * purpose displaying capture startup form
		 * 
		 * */
		public void CaptureSig()
		{
			this.menuItem5.Enabled = true;
			
			cform = new CWCaptureForm(dbconn,username);
			cform.Enabled = true;
			this.menuItem2.Enabled = false;
			this.StartupButtons = false;
			cform.ShowInTaskbar = false;
			cform.ShowDialog();
			
			
			if (cform.flag == true)
			{
				this.menuItem2.Enabled = false;
				this.menuItem3.Enabled = false;
				this.menuItem16.Enabled = false;
				this.menuItem15.Visible = false;
				this.menuItem17.Visible = true;

				toolBar1.Visible = true;
				toolBar1.Show();
				/*	this.toolBarButton1.Visible = true;
						this.toolBarButton1.Enabled = true;
						this.toolBarButton2.Visible = true;
						this.toolBarButton2.Enabled = true;
				
						this.toolBarButton3.Visible = true;*/
				CWButtonState(true,true,true,false,false,false,false,false,false,false,true);
				this.toolBarButton1.Enabled = false;
				this.toolBarButton2.Enabled = true;
				this.toolBarButton3.Enabled = true;
				this.toolBarButton23.Visible = true;
				this.Refresh();
				
			
				accountno = cform.GetAccNo();
				accounttitle = cform.GetAccTitle();
				dbconn.ConfirmAccountNo(accountno);
				captureddate = dbconn.captured;
				companyname = dbconn.companyname;
				this.Text  = "Capture Wise Application" + "  [" + accountno + "]";
				
				iform = new CWInfoForm(accountno,accounttitle,captureddate,companyname);
				iform.MdiParent = this;
				
				iform.Show();
				iform.AccountStatus.Text = dbconn.accountstatus;
				this.toolBarButton1.Enabled = false;
				CWSave(false,false,false);
			}
			else
			{
				this.menuItem2.Enabled = true;
				this.StartupButtons = true;
			}



		}
		
		/*
		 * Created on 27 march
		 * purpose displaying Modify startup form
		 * 
		 * */
		public void ModifyForm()
		{
			this.menuItem5.Enabled = true;
			mform = new CWModifyForm(dbconn);
			mform.Enabled = true;
			this.menuItem2.Enabled = false;
			this.StartupButtons = false;
			mform.ShowInTaskbar = false;
			mform.ShowDialog();
			
			if (mform.flag == true)
			{

				this.menuItem2.Enabled = false;
				this.menuItem3.Enabled = false;
				this.menuItem16.Enabled = false;

				this.menuItem15.Visible = false;
				this.menuItem17.Visible = true;


				toolBar1.Visible = true;
				toolBar1.Show();
				/*	this.toolBarButton1.Visible = true;
						this.toolBarButton1.Enabled = true;
						this.toolBarButton2.Visible = true;
						this.toolBarButton2.Enabled = true;
				
						this.toolBarButton3.Visible = true;*/
				CWButtonState(true,true,true,false,false,false,false,false,false,false,true);
				this.toolBarButton1.Enabled = false;
				this.toolBarButton2.Enabled = true;
				this.toolBarButton3.Enabled = true;
				this.toolBarButton23.Visible = true;
				this.toolBarButton24.Visible = false;

				this.Refresh();
				
			
				accountno = mform.GetAccNo();
				accounttitle = mform.GetAccTitle();
				dbconn.ConfirmAccountNo(accountno);
				captureddate = dbconn.captured;
				companyname = dbconn.companyname;
				this.Text  = "Capture Wise Application" + "  [" + accountno + "]";
			//	CWSave(false,true,false);
				iform = new CWInfoForm(accountno,accounttitle,captureddate,companyname);
				iform.MdiParent = this;
				iform.Show();
				iform.AccountStatus.Text = dbconn.accountstatus;
				
				dbconn.UpdateModified("192.168.1.1",accountno);
				this.toolBarButton1.Enabled = false;
				CWSave(false,false,false);
			}
			else
			{
				this.menuItem2.Enabled = true;
				this.StartupButtons = true;
			}

		
		}
		

		/*
		 * Created on 27 march
		 * purpose displaying Verify startup form
		 * 
		 * */
		public void VerifySig()
		{
			vform = new VerifyForm(dbconn,username);
			vform.ShowInTaskbar = false;
			vform.ShowDialog();
			
			if (vform.flag)
			{
				this.menuItem2.Enabled = false;
				this.menuItem3.Enabled = false;
				this.menuItem16.Enabled = false;

				acc=0;
				accountno = vform.comboBox1.Text;
				accounttitle = dbconn.ConfirmAccountNo(accountno);
				
				
				captureddate = dbconn.captured;
				companyname = dbconn.companyname;
				
				iform = new CWInfoForm(accountno,accounttitle,captureddate,companyname);
				iform.MdiParent = this;
				iform.Show();
				iform.AccountStatus.Text = dbconn.accountstatus;
				dbconn.UpdateVerified("192.168.1.1",accountno);
				this.StartupButtons = false;
				
				this.toolBarButton36.Visible = true;
				this.toolBarButton37.Visible = true;
				this.toolBarButton38.Visible = true;

			}

		}

		/*
		 * Purpose set flag to current used feature
		 * */
		public void mode(bool cap,bool modi,bool ver)
		{
			capture = cap;
			modify = modi;
			verify = ver;
		}
		
		/*
		 * Its main Purpose is of Zomming while navigation
		 * 
		 * */
		private void pictureBox1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			//if zoom button is pressed
			if (this.toolBarButton25.Pushed)
			{
				pictureBox1.Cursor = Cursors.NoMove2D;
				pictureBox1.Height = pictureBox1.Height + 20;
				pictureBox1.Width  = pictureBox1.Width + 20 ;

			}
		}

		private void pictureBox1_MouseHover(object sender, System.EventArgs e)
		{
			
		}
		

		/*
		 * Purpose for changinf mouse cursor on picturebox while navigation
		 * */

		private void pictureBox1_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			//if zoom button is pressed then chage cursor if it comes on picturebox
			if (this.toolBarButton25.Pushed)
			{
				pictureBox1.Cursor = Cursors.NoMove2D;
			}
			else
			{
				pictureBox1.Cursor = Cursors.Arrow;
			}
		}


		/*
		 * Purpose for Zooming
		 * */
		
		private void pictureBox2_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (this.toolBarButton25.Pushed)
			{
				pictureBox2.Cursor = Cursors.NoMove2D;
				pictureBox2.Height = pictureBox2.Height + 20;
				pictureBox2.Width  = pictureBox2.Width + 20 ;

			}
		}

		/*
		 * Purpose for changinf mouse cursor on picturebox while navigation
		 * */

		private void pictureBox2_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (this.toolBarButton25.Pushed)
			{
				pictureBox2.Cursor = Cursors.NoMove2D;
			}
			else
			{
				pictureBox2.Cursor = Cursors.Arrow;
			}
		}
		
		//Purpose is for zooming
		private void pictureBox3_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (this.toolBarButton25.Pushed)
			{
				pictureBox3.Cursor = Cursors.NoMove2D;
				pictureBox3.Height = pictureBox3.Height + 20;
				pictureBox3.Width  = pictureBox3.Width + 20;
			}
		}
		

		/*
		 * Purpose for changinf mouse cursor on picturebox while navigation
		 * */

		private void pictureBox3_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (this.toolBarButton25.Pushed)
			{
				pictureBox3.Cursor = Cursors.NoMove2D;
			}
			else
			{
				pictureBox3.Cursor = Cursors.Arrow;
			}
		}

		private void pictureBox4_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (this.toolBarButton25.Pushed)
			{
				pictureBox4.Cursor = Cursors.NoMove2D;
				pictureBox4.Height = pictureBox4.Height + 20;
				pictureBox4.Width  = pictureBox4.Width + 20;
			}
		}

		/*
		 * Purpose for changinf mouse cursor on picturebox while navigation
		 * */

		private void pictureBox4_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (this.toolBarButton25.Pushed)
			{
				pictureBox4.Cursor = Cursors.NoMove2D;
			}
			else
			{
				pictureBox4.Cursor = Cursors.Arrow;
			}
		}
		

		/*
		 * Purpose is to hide and unhide rotate buttons while navigation
		 * */
		private void tabControl1_TabIndexChanged(object sender, System.EventArgs e)
		{
			switch(tabControl1.SelectedIndex)
			{
				case 1:
				{
					if (pictureBox1.Image ==null)
						this.SetNavigateRotateBut = false;
					else
						this.SetNavigateRotateBut = true;
					break;
				}
				case 2:
				{
					if (pictureBox2.Image ==null)
						this.SetNavigateRotateBut = false;
					else
						this.SetNavigateRotateBut = true;
					break;
				}
				case 3:
				{
					if (pictureBox3.Image ==null)
						this.SetNavigateRotateBut = false;
					else
						this.SetNavigateRotateBut = true;
					break;
				}
				case 4:
				{
					if (pictureBox4.Image ==null)
						this.SetNavigateRotateBut = false;
					else
						this.SetNavigateRotateBut = true;
					break;
				}

			}
			
		}


		/*
		 * Purpose is to hide and unhide rotate buttons while navigation when tab is changed in tabcontrol
		 * */

		private void tabControl1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			switch(tabControl1.SelectedIndex)
			{
				case 0:
				{
					if (pictureBox1.Image ==null)
						this.SetNavigateRotateBut = false;
					else
						this.SetNavigateRotateBut = true;
					break;
				}
				case 1:
				{
					if (pictureBox2.Image ==null)
						this.SetNavigateRotateBut = false;
					else
						this.SetNavigateRotateBut = true;
					break;
				}
				case 2:
				{
					if (pictureBox3.Image ==null)
						this.SetNavigateRotateBut = false;
					else
						this.SetNavigateRotateBut = true;
					break;
				}
				case 3:
				{
					if (pictureBox4.Image ==null)
						this.SetNavigateRotateBut = false;
					else
						this.SetNavigateRotateBut = true;
					break;
				}

			}
		}

		private void menuItem3_Click(object sender, System.EventArgs e)
		{
			dbconn.ConfUser(username,domain);
			if (dbconn.mod)
			{
				mode(false,true,false);
				ModifyForm();
			}
			else
				MessageBox.Show("No records exists to be modified by this user");

		}

		private void menuItem16_Click(object sender, System.EventArgs e)
		{
			//Check Rights of user, whether user can use verify or not
			dbconn.ConfUser(username,domain);
			if (dbconn.ver)
			{
				mode(false,false,true);
				VerifySig();
			}
			else
				MessageBox.Show("No records exists to be verified by this user");
			
		}




		public bool getcapture
		{
			get
			{
				return this.capture;
			}
		}

		public bool getmodify
		{
			get
			{
				return this.modify;
			}
		}

		public bool getverify
		{
			get
			{
				return this.verify;
			}
		}
	
		/*
		 * Property made to hide and unhide image process buttons of croped image i.e. rubing, zooming, view at 100%
		 * */

		public bool ImageProcessButs
		{
			set
			{
				this.toolBarButton26.Visible = value;
				this.toolBarButton27.Visible = value;
				this.toolBarButton28.Visible = value;
			}
		}
		 
		
		/*
		 * Property made to hide and unhide image process buttons of un-croped image i.e. rubing, zooming, view at 100%
		 */

		public bool ImageProcessButsofUnCropped
		{
			set
			{
				this.toolBarButton30.Visible = value;
				this.toolBarButton31.Visible = value;
				this.toolBarButton32.Visible = value;
			}
		}
		


		public bool CropButPressed
		{
			get
			{
				return this.toolBarButton30.Pushed;
			}
		}

		public bool zoomButPressed
		{
			get
			{
				return this.toolBarButton32.Pushed;
			}
		}
		

		//get current state of buttons of zoom & rubbing
		public bool GetZoomButton
		{
			get
			{
				return this.toolBarButton27.Pushed;
			}
		}

		public bool GetRubButton
		{
			get
			{
				return this.toolBarButton28.Pushed;
			}
		}

		//property to obtain username of currently loged user in win
		public string GetUsername
		{
			get
			{
				return username;
			}
		}
		
		public bool SetNavigateRotateBut
		{
			set
			{
				this.toolBarButton39.Visible = value;
				this.toolBarButton40.Visible = value;
				this.toolBarButton41.Visible = value;
				this.toolBarButton25.Visible = value;
			}
		}
		public bool SetProperties
		{
			set
			{
				prop = value;
			}
		}

		public void SaveEvent()
		{
			this.toolBarButton1.Enabled= false;
			
			if (prop)
			{
				if (adform.textBox1.Text.Length > 0)
				{
					dbconn.UpadteInfo(adform.textBox1.Text,accountno);
				}
				else
				{
					MessageBox.Show("Please Enter Details of Account");
				}
				savecrossref = false;
				CWSave(false,false,false);
			}
			if (maindetails)
			{
				if ((iform.Accounttitle.Text.Length > 0 )&& (iform.companyname.Text.Length > 0))
				{
					dbconn.CWUpdateMainDetails(iform.Accounttitle.Text,iform.companyname.Text,accountno,iform.AccountStatus.Text);
				}
				else
				{
					MessageBox.Show("Please Enter Valid Account Title or Comany Name");
				}
				savecrossref = false;
				CWSave(false,false,false);
			}
			if (signinfo)
			{
				SaveSignatoryInfo();
				savecrossref = false;
				CWSave(false,false,false);

			}
			
			if (savecrossref)
			{
				if (SaveCR())
				{
					savecrossref = false;
				}
				else
				{
					MessageBox.Show("There were Errors");
					savecrossref = false;
				}

				savecrossref = false;
				CWSave(false,false,false);

			}
			
		}

		private void Form1_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
		{
		
		}

		private void menuItem17_Click(object sender, System.EventArgs e)
		{
			this.Text = "Capture Wise Application";
			this.menuItem2.Enabled = true;
			this.menuItem3.Enabled = true;
			this.menuItem16.Enabled = true;
			
	
			

			this.menuItem15.Visible = true;
			this.menuItem17.Visible = false;
			this.menuItem18.Visible = false;


			if (dbconn.cap)
			{
				this.menuItem2.Enabled = true;
				this.toolBarButton15.Enabled = true;
			}
			else
			{
				this.menuItem2.Enabled = false;
				this.toolBarButton15.Enabled = false;
			}

			if (dbconn.mod)
			{
				this.menuItem3.Enabled = true;
				this.toolBarButton16.Enabled = true;
			}
			else
			{
				this.menuItem3.Enabled = false;
				this.toolBarButton16.Enabled = false;
			}

			if (dbconn.ver)
			{
				this.menuItem16.Enabled = true;
				this.toolBarButton24.Enabled = true;
			}
			else
			{
				this.menuItem16.Enabled = false;
				this.toolBarButton24.Enabled = false;
			}


			this.SetNavButtons = false;
			sign1 = false;
			sign2 = false;
			sigcount = 0;
			this.menuItem2.Enabled = true;
			CWButtonState(false,false,false,false,false,false,false,false,false,false,false);
			this.RotateButtons = false;
			this.toolBarButton25.Visible = false;
			this.StartupButtons = true;
			this.signbuttonVisible = false;
			this.toolBarButton23.Visible = false;
			this.toolBarButton29.Visible = false;
			this.SetNavigateRotateBut = false;
			this.disposeResources();

				
			try
			{
				if (iform != null)
				{
					if (this.iform.Visible == true)
					{
						iform.Close();
						iform.Dispose();
					}
				}
				if (adform != null)
				{
					if (adform.Visible == true)
					{
						adform.Visible = false;
						adform.Dispose();
					}
				}
				if (sform != null)
				{
					if (this.sform.Visible == true)
					{
						sform.Close();
						sform.Dispose();
					}
				}
					
				if (siform != null)
				{
					if (siform.Visible)
					{
						siform.Close();
						siform.Dispose();
					}
				}

				if (asform != null)
				{
					if (asform.Visible)
					{
						asform.Close();
						asform.Dispose();
					}
				}

				if (crform != null)
				{
					if (crform.Visible)
					{
						crform.Close();
						crform.Dispose();
					}
				}
					
			}
			catch( System.Exception ee)
			{
						
			}
		}

		private void Form1_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			dbconn.closecon();	
		}

		private void menuItem18_Click(object sender, System.EventArgs e)
		{
			dbconn.DeleteAccount(identity,accountno);

			this.Text = "Capture Wise Application";
			this.menuItem2.Enabled = true;
			this.menuItem3.Enabled = true;
			this.menuItem16.Enabled = true;
				
			this.menuItem15.Visible = true;
			this.menuItem17.Visible = false;
			this.menuItem18.Visible = false;

			this.SetNavButtons = false;
			sign1 = false;
			sign2 = false;
			sigcount = 0;
			this.menuItem2.Enabled = true;
			CWButtonState(false,false,false,false,false,false,false,false,false,false,false);
			this.RotateButtons = false;
			this.toolBarButton25.Visible = false;
			this.StartupButtons = true;
			this.signbuttonVisible = false;
			this.toolBarButton23.Visible = false;
			this.toolBarButton29.Visible = false;
			this.SetNavigateRotateBut = false;
			this.disposeResources();

				
			try
			{
				if (iform != null)
				{
					if (this.iform.Visible == true)
					{
						iform.Close();
						iform.Dispose();
					}
				}
				if (adform != null)
				{
					if (adform.Visible == true)
					{
						adform.Visible = false;
						adform.Dispose();
					}
				}
				if (sform != null)
				{
					if (this.sform.Visible == true)
					{
						sform.Close();
						sform.Dispose();
					}
				}
					
				if (siform != null)
				{
					if (siform.Visible)
					{
						siform.Close();
						siform.Dispose();
					}
				}

				if (asform != null)
				{
					if (asform.Visible)
					{
						asform.Close();
						asform.Dispose();
					}
				}

				if (crform != null)
				{
					if (crform.Visible)
					{
						crform.Close();
						crform.Dispose();
					}
				}
					
			}
			catch( System.Exception ee)
			{
						
			}
		}

		public bool DeleteAccVisible
		{
			set
			{
				this.menuItem18.Visible = value;
			}
		}


	}
}
