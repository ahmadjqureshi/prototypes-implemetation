using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Drawing.Imaging;
using Microsoft.Win32;

namespace CWApplication
{
	/// <summary>
	/// Summary description for CWSignImage.
	/// </summary>
	public class CWSignImage : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		
		public bool crop,cropstarted,endcrop;
		int startx=0,starty=0,endx=0,endy=0;
		int dx=0,dy=0;
		
		bool rub = false;
		Bitmap bmp;
		public Bitmap cropbmp,cropbmpshow,fortab,fortab1,fortab2,fortab3;
		int xbounds=0,ybounds=0;
		int tempdx =0;
		int tempdy =0;
		int ResX,ResY;

		string filename;
		public int scale = 4,currentscale;
		private System.Windows.Forms.Panel panel1;
		public System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Panel panel2;
		public System.Windows.Forms.PictureBox pictureBox2;
		string tempvalue;
		
		public CWSignImage(string fname)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			RegistryKey Hkey = Registry.CurrentUser;
			RegistryKey sHkey = Hkey.OpenSubKey("Environment");
			tempvalue = (string) sHkey.GetValue("temp");

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			

			filename = fname;

			crop = true;
			cropstarted = false;
			endcrop = false;
			
			bmp = new Bitmap(tempvalue + "\\temp.jpeg");
			if (bmp.Width > 1000 && bmp.Height > 1800)
			{
				scale  = 8;
				currentscale = scale;
			}
			else
			{
				scale = 4;
				currentscale = scale;
			}
			xbounds = bmp.Width/scale;
			ybounds = bmp.Height/scale;

			panel1.Width = xbounds + 30;
			panel1.Height = ybounds + 30;

			pictureBox1.Width = xbounds;
			pictureBox1.Height = ybounds;
			pictureBox1.Image = (Image) bmp;
			

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new System.Windows.Forms.Panel();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.AutoScroll = true;
			this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.pictureBox1});
			this.panel1.Location = new System.Drawing.Point(8, 16);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(200, 296);
			this.panel1.TabIndex = 0;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Location = new System.Drawing.Point(8, 24);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(168, 224);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
			this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp_1);
			this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove_1);
			this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown_1);
			// 
			// panel2
			// 
			this.panel2.AutoScroll = true;
			this.panel2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.pictureBox2});
			this.panel2.Location = new System.Drawing.Point(320, 16);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(184, 296);
			this.panel2.TabIndex = 1;
			// 
			// pictureBox2
			// 
			this.pictureBox2.Location = new System.Drawing.Point(24, 24);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(120, 248);
			this.pictureBox2.TabIndex = 0;
			this.pictureBox2.TabStop = false;
			this.pictureBox2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
			this.pictureBox2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
			this.pictureBox2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
			// 
			// CWSignImage
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.AutoScroll = true;
			this.ClientSize = new System.Drawing.Size(560, 341);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panel2,
																		  this.panel1});
			this.Name = "CWSignImage";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "Extract Sign";
			this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.CWSignImage_MouseDown);
			this.Closing += new System.ComponentModel.CancelEventHandler(this.CWSignImage_Closing);
			this.Load += new System.EventHandler(this.CWSignImage_Load);
			this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.CWSignImage_MouseUp);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.CWSignImage_Paint);
			this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.CWSignImage_MouseMove);
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void CWSignImage_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
		
		}

		private void CWSignImage_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			
			if (e.X > xbounds || e.Y > ybounds)
				MessageBox.Show("Please crop Image");
			else
			{
				cropstarted = true;
				crop = true;
			}
			if (crop && cropstarted)
			{
				Invalidate();					
				Invalidate();
				startx = e.X;
				starty = e.Y;
				tempdx = startx;
				tempdx = starty;
	
			}
		}

		private void CWSignImage_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (crop && cropstarted)
			{
				if (startx > e.X)
				{
					crop = false;
					cropstarted = false;
					MessageBox.Show("Please Crop from Top to down");
				}
				if (e.X > xbounds)
				{
					dx = xbounds - startx;
				}
				else
					if (e.Y > ybounds)
				{
					dy = ybounds - starty;
				}
				else
					if (e.X > xbounds && e.Y > ybounds)
				{
					dx = xbounds - startx;
					dy = ybounds - starty;
				}
				else
				{
					dx = e.X - startx;
					dy = e.Y - starty;
				}
				
					if (dx <tempdx && dy < tempdy)
						Invalidate(new Rectangle(startx,starty,tempdx+5,tempdy+5));
					else
						if (dx < tempdx)
						Invalidate(new Rectangle(startx,starty,tempdx+5,dy));
					else
						if (dy < tempdy)
						Invalidate(new Rectangle(startx,starty,dx,tempdy+5));
					else
						Invalidate(new Rectangle(startx,starty,dx,dy));
					
				tempdx = dx;
				tempdy = dy;
			}
		}

		private void CWSignImage_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (crop && cropstarted)
			{
				endx = e.X;
				endy = e.Y;
				
				if (endx > xbounds)
				{
					endx = xbounds;
					MessageBox.Show("Please crop on Image");
				}
				else
					if (endy > ybounds)
				{
					endy = ybounds;
					MessageBox.Show("Please crop on Image");
				}
				if ((endx > xbounds) && (endy > ybounds))
				{
					endx = xbounds;
					endy = ybounds;
				}
								
					crop = false;
					cropstarted = false;
					((CWApplication.Form1)(this.MdiParent)).ImageProcessButs = true;	
					cropbmp = bmp.Clone(new Rectangle(startx*scale,starty*scale,dx*scale,dy*scale),bmp.PixelFormat);
					cropbmp.Save(tempvalue + "\\temp1.jpeg",ImageFormat.Jpeg);
					
					cropbmpshow = bmp.Clone(new Rectangle(startx*scale,starty*scale,dx*scale,dy*scale),bmp.PixelFormat);
					
					cropbmpshow.Save(tempvalue + "\\temp2.jpeg",ImageFormat.Jpeg);

					pictureBox1.Image = (Image) cropbmpshow;
					
				
				if (((CWApplication.Form1)(this.MdiParent)).signnoval == 1)
				{
					if (fortab != null)
					{
						fortab = null;
						Invalidate();
					}
					try
					{
						//fortab = bmp.Clone(new Rectangle(startx*scale,starty*scale,dx*scale,dy*scale),bmp.PixelFormat);
						fortab = (Bitmap) cropbmp;
						fortab.Save(tempvalue + "\\temp3.jpeg",ImageFormat.Jpeg);
					}
					catch(System.Exception eee)
					{
						MessageBox.Show(eee.Message);
					}
				}
				if (((CWApplication.Form1)(this.MdiParent)).signnoval == 2)
				{
					if (fortab1 != null)
					{
						fortab1 = null;
						Invalidate();
					}
					//fortab1 = bmp.Clone(new Rectangle(startx*scale,starty*scale,dx*scale,dy*scale),bmp.PixelFormat);
					fortab1 =(Bitmap) cropbmp;
					
					fortab1.Save(tempvalue + "\\temp4.jpeg",ImageFormat.Jpeg);
				}

				if (((CWApplication.Form1)(this.MdiParent)).signnoval == 3)
				{
					if (fortab2 != null)
					{
						fortab2 = null;
						Invalidate();
					}
					//fortab1 = bmp.Clone(new Rectangle(startx*scale,starty*scale,dx*scale,dy*scale),bmp.PixelFormat);
					fortab2 =(Bitmap) cropbmp;
					fortab2.Save(tempvalue + "\\temp5.jpeg",ImageFormat.Jpeg);
				}

				if (((CWApplication.Form1)(this.MdiParent)).signnoval == 4)
				{
					if (fortab3 != null)
					{
						fortab3 = null;
						Invalidate();
					}
					//fortab1 = bmp.Clone(new Rectangle(startx*scale,starty*scale,dx*scale,dy*scale),bmp.PixelFormat);
					fortab3 =(Bitmap) cropbmp;
					fortab3.Save(tempvalue + "\\temp6.jpeg",ImageFormat.Jpeg);
				}

					Invalidate();
					endcrop = true;
					((CWApplication.Form1)(this.MdiParent)).RotateButtons = true;
					((CWApplication.Form1)(this.MdiParent)).RotateButtonsEnable = true;
					((CWApplication.Form1)(this.MdiParent)).Signaccept = true;
				
			}
		}

		private void CWSignImage_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			bmp.Dispose();
		}

		private void CWSignImage_Load(object sender, System.EventArgs e)
		{
			((CWApplication.Form1)(this.MdiParent)).ImageProcessButsofUnCropped = true;
		}

		private void pictureBox1_Move(object sender, System.EventArgs e)
		{

		}

		private void pictureBox1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (((CWApplication.Form1)(this.MdiParent)).GetRubButton)
			{
				rub = true;
			}


			if (((CWApplication.Form1)(this.MdiParent)).GetZoomButton)
			{
				this.pictureBox2.Height += 20;
				this.pictureBox2.Width  += 20;

				Invalidate();
			}


		}

		private void pictureBox1_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (((CWApplication.Form1)(this.MdiParent)).GetZoomButton)
			{
				pictureBox2.Cursor = Cursors.NoMove2D;
			}
			else if (((CWApplication.Form1)(this.MdiParent)).GetRubButton)
			{
				pictureBox2.Cursor = Cursors.Cross;
			}
			else
			{
				pictureBox2.Cursor = Cursors.Arrow;
			}
			
			if (rub)
			{
				if (e.X > pictureBox2.Width || e.Y > pictureBox2.Height)
				{
				}
				else
				{
					try
					{
						for (int x= e.X,y = e.Y;x < e.X + 8 ; x++,y++)
							((Bitmap)(pictureBox2.Image)).SetPixel(x,y,Color.Transparent);
						
						pictureBox2.Refresh();
					}
					catch (System.ArgumentException ae)
					{
						MessageBox.Show("Please Rub on Image only");
						rub = false;
					}
				}
			}
		
		}

		private void pictureBox1_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (rub)
			{
				

				Bitmap cropbmpag = (Bitmap) pictureBox2.Image;
				cropbmpag.Save(tempvalue + "\\temp1.jpeg",ImageFormat.Jpeg);
					
					
				
				if (((CWApplication.Form1)(this.MdiParent)).signnoval == 1)
				{
					if (fortab != null)
					{
						fortab = null;
						
					}
					try
					{
						//fortab = bmp.Clone(new Rectangle(startx*scale,starty*scale,dx*scale,dy*scale),bmp.PixelFormat);
						fortab = (Bitmap) pictureBox2.Image;
						fortab.Save(tempvalue + "\\temp3.jpeg",ImageFormat.Jpeg);
					}
					catch(System.Exception eee)
					{
						MessageBox.Show(eee.Message);
					}
				}
				if (((CWApplication.Form1)(this.MdiParent)).signnoval == 2)
				{
					if (fortab1 != null)
					{
						fortab1 = null;
						Invalidate();
					}
					//fortab1 = bmp.Clone(new Rectangle(startx*scale,starty*scale,dx*scale,dy*scale),bmp.PixelFormat);
					fortab1 =(Bitmap) pictureBox2.Image;
					
					fortab1.Save(tempvalue + "\\temp4.jpeg",ImageFormat.Jpeg);
				}

				if (((CWApplication.Form1)(this.MdiParent)).signnoval == 3)
				{
					if (fortab2 != null)
					{
						fortab2 = null;
						Invalidate();
					}
					//fortab1 = bmp.Clone(new Rectangle(startx*scale,starty*scale,dx*scale,dy*scale),bmp.PixelFormat);
					fortab2 =(Bitmap) pictureBox2.Image;
					fortab2.Save(tempvalue + "\\temp5.jpeg",ImageFormat.Jpeg);
				}

				if (((CWApplication.Form1)(this.MdiParent)).signnoval == 4)
				{
					if (fortab3 != null)
					{
						fortab3 = null;
						Invalidate();
					}
					//fortab1 = bmp.Clone(new Rectangle(startx*scale,starty*scale,dx*scale,dy*scale),bmp.PixelFormat);
					fortab3 =(Bitmap) pictureBox2.Image;
					fortab3.Save(tempvalue + "\\temp6.jpeg",ImageFormat.Jpeg);
				}

				Invalidate();
				endcrop = true;
				
			}
			rub = false;

		}

		private void pictureBox1_MouseDown_1(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (((CWApplication.Form1)(this.MdiParent)).zoomButPressed)
			{
				if (currentscale > 1)
				{
					currentscale--;
					pictureBox1.Width = (bmp.Width / currentscale);
					pictureBox1.Height = (bmp.Height / currentscale);
					pictureBox1.Refresh();
					xbounds = bmp.Width/currentscale;
					ybounds = bmp.Height/currentscale;
				}
			}

			if (((CWApplication.Form1)(this.MdiParent)).CropButPressed)
			{
				if (e.X > xbounds || e.Y > ybounds)
					MessageBox.Show("Please crop Image");
				else
				{
					cropstarted = true;
					crop = true;
				}
				if (crop && cropstarted)
				{
					Invalidate();					
					Invalidate();
					startx = e.X;
					starty = e.Y;
					tempdx = startx;
					tempdx = starty;
	
				}
			}
		}

		private void pictureBox1_MouseMove_1(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (((CWApplication.Form1)(this.MdiParent)).CropButPressed)
			{
				pictureBox1.Cursor = Cursors.Cross;
			}
			else
			if (((CWApplication.Form1)(this.MdiParent)).zoomButPressed)
			{
				pictureBox1.Cursor = Cursors.NoMove2D;
			}
			else
				pictureBox1.Cursor = Cursors.Arrow;
			

			if (((CWApplication.Form1)(this.MdiParent)).CropButPressed)
			{
				if (crop && cropstarted)
				{
					if (startx > e.X || starty > e.Y)
					{
						crop = false;
						cropstarted = false;
						MessageBox.Show("Please Crop from Top to down");
					}
					if (e.X > xbounds)
					{
						dx = xbounds - startx;
					}
					else
						if (e.Y > ybounds)
					{
						dy = ybounds - starty;
					}
					else
						if (e.X > xbounds && e.Y > ybounds)
					{
						dx = xbounds - startx;
						dy = ybounds - starty;
					}
					else
					{
						dx = e.X - startx;
						dy = e.Y - starty;
					}
				
					if (dx <tempdx && dy < tempdy)
						pictureBox1.Invalidate(new Rectangle(startx,starty,tempdx+5,tempdy+5));
					else
						if (dx < tempdx)
						pictureBox1.Invalidate(new Rectangle(startx,starty,tempdx+5,dy));
					else
						if (dy < tempdy)
						pictureBox1.Invalidate(new Rectangle(startx,starty,dx,tempdy+5));
					else
						pictureBox1.Invalidate(new Rectangle(startx,starty,dx,dy));
					
					tempdx = dx;
					tempdy = dy;
				}
			}
		}

		private void pictureBox1_MouseUp_1(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (((CWApplication.Form1)(this.MdiParent)).CropButPressed)
			{
				if (crop && cropstarted)
				{
					endx = e.X;
					endy = e.Y;
				
					if (endx > xbounds)
					{
						endx = xbounds;
						MessageBox.Show("Please crop on Image");
					}
					else
						if (endy > ybounds)
					{
						endy = ybounds;
						MessageBox.Show("Please crop on Image");
					}
					if ((endx > xbounds) && (endy > ybounds))
					{
						endx = xbounds;
						endy = ybounds;
					}
								
					crop = false;
					cropstarted = false;
					((CWApplication.Form1)(this.MdiParent)).ImageProcessButs = true;	
					cropbmp = bmp.Clone(new Rectangle(startx*currentscale,starty*currentscale,dx*currentscale,dy*currentscale),bmp.PixelFormat);
					cropbmp.Save(tempvalue + "\\temp1.jpeg",ImageFormat.Jpeg);
					
					cropbmpshow = bmp.Clone(new Rectangle(startx*currentscale,starty*currentscale,dx*currentscale,dy*currentscale),bmp.PixelFormat);
					
					cropbmpshow.Save(tempvalue + "\\temp2.jpeg",ImageFormat.Jpeg);

					pictureBox2.Image = (Image) cropbmpshow;
					pictureBox2.Height = cropbmpshow.Height;
					pictureBox2.Width = cropbmpshow.Width;
					
				
					if (((CWApplication.Form1)(this.MdiParent)).signnoval == 1)
					{
						if (fortab != null)
						{
							fortab = null;
							Invalidate();
						}
						try
						{
							//fortab = bmp.Clone(new Rectangle(startx*scale,starty*scale,dx*scale,dy*scale),bmp.PixelFormat);
							fortab = (Bitmap) cropbmp;
							fortab.Save(tempvalue + "\\temp3.jpeg",ImageFormat.Jpeg);
						}
						catch(System.Exception eee)
						{
							MessageBox.Show(eee.Message);
						}
					}
					if (((CWApplication.Form1)(this.MdiParent)).signnoval == 2)
					{
						if (fortab1 != null)
						{
							fortab1 = null;
							Invalidate();
						}
						//fortab1 = bmp.Clone(new Rectangle(startx*scale,starty*scale,dx*scale,dy*scale),bmp.PixelFormat);
						fortab1 =(Bitmap) cropbmp;
					
						fortab1.Save(tempvalue + "\\temp4.jpeg",ImageFormat.Jpeg);
					}

					if (((CWApplication.Form1)(this.MdiParent)).signnoval == 3)
					{
						if (fortab2 != null)
						{
							fortab2 = null;
							Invalidate();
						}
						//fortab1 = bmp.Clone(new Rectangle(startx*scale,starty*scale,dx*scale,dy*scale),bmp.PixelFormat);
						fortab2 =(Bitmap) cropbmp;
						fortab2.Save(tempvalue + "\\temp5.jpeg",ImageFormat.Jpeg);
					}

					if (((CWApplication.Form1)(this.MdiParent)).signnoval == 4)
					{
						if (fortab3 != null)
						{
							fortab3 = null;
							Invalidate();
						}
						//fortab1 = bmp.Clone(new Rectangle(startx*scale,starty*scale,dx*scale,dy*scale),bmp.PixelFormat);
						fortab3 =(Bitmap) cropbmp;
						fortab3.Save(tempvalue + "\\temp6.jpeg",ImageFormat.Jpeg);
					}

					Invalidate();
					endcrop = true;
					((CWApplication.Form1)(this.MdiParent)).RotateButtons = true;
					((CWApplication.Form1)(this.MdiParent)).RotateButtonsEnable = true;
					((CWApplication.Form1)(this.MdiParent)).Signaccept = true;
				
				}		
			}
		}

		private void pictureBox1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			if (crop && cropstarted)
			e.Graphics.DrawRectangle(Pens.Blue,startx,starty,dx-1,dy-1);		
		}

	}
}
