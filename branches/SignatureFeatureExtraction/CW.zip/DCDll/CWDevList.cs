using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace DCDll
{
	/// <summary>
	/// Summary description for CWDevList.
	/// </summary>
	public class CWDevList : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.Button button1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		public String SelectedDev;		
		public CWDevList()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/*
		 *******************************************************
		 Created on 22-02-2004 by Ahmad
		 
		 Purpose of this function:
		 Displaying Devices in Combo Box
		 *******************************************************
		*/
		
		public void AddCombo(ArrayList al)
		{
			for (int i=0;i<al.Count;i++)
			{
				comboBox1.Items.Add(al[i].ToString());
			}
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		
		
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(25, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(144, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Select Device from the List";
			// 
			// comboBox1
			// 
			this.comboBox1.Location = new System.Drawing.Point(25, 35);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(176, 21);
			this.comboBox1.TabIndex = 1;
			this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
			// 
			// button1
			// 
			this.button1.Enabled = false;
			this.button1.Location = new System.Drawing.Point(153, 72);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(48, 24);
			this.button1.TabIndex = 2;
			this.button1.Text = "OK";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// CWDevList
			// 
			this.AccessibleRole = System.Windows.Forms.AccessibleRole.Dialog;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(210, 101);
			this.ControlBox = false;
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button1,
																		  this.comboBox1,
																		  this.label1});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Name = "CWDevList";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Select Device";
			this.ResumeLayout(false);

		}
		#endregion

		private void button1_Click(object sender, System.EventArgs e)
		{
			SelectedDev = comboBox1.SelectedItem.ToString();
			MessageBox.Show(SelectedDev);
			if (SelectedDev.Equals( "Select"))
			{
				MessageBox.Show("Please Select any device from list");
			}
			else
				this.Close();
		}

		private void comboBox1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			SelectedDev = comboBox1.Text;
			MessageBox.Show(SelectedDev + "    :hhh");
			button1.Enabled = true;
		}
	}
}
