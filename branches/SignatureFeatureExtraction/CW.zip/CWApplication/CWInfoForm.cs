using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CWApplication
{
	/// <summary>
	/// Summary description for CWInfoForm.
	/// </summary>
	public class CWInfoForm : System.Windows.Forms.Form
	{
		public System.Windows.Forms.TabControl tabControl1;
		public System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		public System.Windows.Forms.TextBox accountno;
		public System.Windows.Forms.TextBox Captured;
		private System.Windows.Forms.Label label3;
		public System.Windows.Forms.TextBox Accounttitle;
		private System.Windows.Forms.Label label4;
		public System.Windows.Forms.TextBox companyname;
		private System.Windows.Forms.Label label5;
		public System.Windows.Forms.ComboBox AccountStatus;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CWInfoForm(string accountnum,string title,string captureddate,string compname)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			this.accountno.Text = accountnum;
			this.Accounttitle.Text = title;
			this.Captured.Text = captureddate;
			this.companyname.Text = compname;
			// defining max length allowed by text box
			this.Accounttitle.MaxLength = 255;
			this.companyname.MaxLength = 255;


			
			
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.AccountStatus = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.companyname = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.Accounttitle = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.Captured = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.accountno = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.SuspendLayout();
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.tabPage1});
			this.tabControl1.Location = new System.Drawing.Point(8, 8);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(424, 184);
			this.tabControl1.TabIndex = 0;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.AccountStatus,
																				   this.label5,
																				   this.companyname,
																				   this.label4,
																				   this.Accounttitle,
																				   this.label3,
																				   this.Captured,
																				   this.label2,
																				   this.accountno,
																				   this.label1});
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Size = new System.Drawing.Size(416, 158);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Main Details";
			// 
			// AccountStatus
			// 
			this.AccountStatus.Items.AddRange(new object[] {
															   "Active",
															   "Pending for verification",
															   "In-active",
															   "To-be deleted",
															   "Expired "});
			this.AccountStatus.Location = new System.Drawing.Point(113, 112);
			this.AccountStatus.Name = "AccountStatus";
			this.AccountStatus.Size = new System.Drawing.Size(159, 21);
			this.AccountStatus.TabIndex = 9;
			this.AccountStatus.Text = "Select Status";
			this.AccountStatus.Visible = false;
			this.AccountStatus.SelectedIndexChanged += new System.EventHandler(this.AccountStatus_SelectedIndexChanged);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(16, 115);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(96, 16);
			this.label5.TabIndex = 8;
			this.label5.Text = "Signatory Status:";
			this.label5.Visible = false;
			// 
			// companyname
			// 
			this.companyname.Location = new System.Drawing.Point(114, 84);
			this.companyname.MaxLength = 255;
			this.companyname.Name = "companyname";
			this.companyname.Size = new System.Drawing.Size(286, 20);
			this.companyname.TabIndex = 7;
			this.companyname.Text = "";
			this.companyname.TextChanged += new System.EventHandler(this.companyname_TextChanged);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(16, 88);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(96, 16);
			this.label4.TabIndex = 6;
			this.label4.Text = "Company Name:";
			// 
			// Accounttitle
			// 
			this.Accounttitle.Location = new System.Drawing.Point(115, 43);
			this.Accounttitle.MaxLength = 255;
			this.Accounttitle.Name = "Accounttitle";
			this.Accounttitle.Size = new System.Drawing.Size(285, 20);
			this.Accounttitle.TabIndex = 5;
			this.Accounttitle.Text = "";
			this.Accounttitle.TextChanged += new System.EventHandler(this.Accounttitle_TextChanged);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 48);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(88, 16);
			this.label3.TabIndex = 4;
			this.label3.Text = "Account Title:";
			// 
			// Captured
			// 
			this.Captured.Enabled = false;
			this.Captured.HideSelection = false;
			this.Captured.Location = new System.Drawing.Point(301, 14);
			this.Captured.Name = "Captured";
			this.Captured.TabIndex = 3;
			this.Captured.Text = "";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(248, 16);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(56, 16);
			this.label2.TabIndex = 2;
			this.label2.Text = "Captured:";
			// 
			// accountno
			// 
			this.accountno.Enabled = false;
			this.accountno.Location = new System.Drawing.Point(116, 14);
			this.accountno.Name = "accountno";
			this.accountno.TabIndex = 1;
			this.accountno.Text = "";
			this.accountno.TextChanged += new System.EventHandler(this.accountno_TextChanged);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(96, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Account Number:";
			// 
			// CWInfoForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(440, 205);
			this.ControlBox = false;
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.tabControl1});
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "CWInfoForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "CWInfoForm";
			this.Load += new System.EventHandler(this.CWInfoForm_Load);
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void textBox1_TextChanged(object sender, System.EventArgs e)
		{
			if(this.MdiParent != null)				
			{
				((CWApplication.Form1)(this.MdiParent)).SaveButton = true;
				((CWApplication.Form1)(this.MdiParent)).MainDetailsUpdate = true;
			}
		}
		
		private void companyname_TextChanged(object sender, System.EventArgs e)
		{
			if(this.MdiParent != null)				
			{
				((CWApplication.Form1)(this.MdiParent)).SaveButton = true;
				((CWApplication.Form1)(this.MdiParent)).MainDetailsUpdate = true;
			}
		}

		private void Accounttitle_TextChanged(object sender, System.EventArgs e)
		{	
			if(this.MdiParent != null)				
			{
				((CWApplication.Form1)(this.MdiParent)).SaveButton = true;
				((CWApplication.Form1)(this.MdiParent)).MainDetailsUpdate = true;
			}
		}

		private void label5_Click(object sender, System.EventArgs e)
		{
		
		}

		private void label5_Click_1(object sender, System.EventArgs e)
		{
		
		}

		private void AccountStatus_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if(this.MdiParent != null)				
			{
				((CWApplication.Form1)(this.MdiParent)).SaveButton = true;
				((CWApplication.Form1)(this.MdiParent)).MainDetailsUpdate = true;
			}
		}

		private void CWInfoForm_Load(object sender, System.EventArgs e)
		{
			if (((CWApplication.Form1)(this.MdiParent)).getverify)
			{
				this.accountno.ReadOnly = true;
				this.Accounttitle.ReadOnly= true;
				this.Captured.ReadOnly = true;
				this.companyname.ReadOnly = true;
				this.AccountStatus.Enabled = false;
			}

		}

		private void accountno_TextChanged(object sender, System.EventArgs e)
		{
		
		}
	}
}
