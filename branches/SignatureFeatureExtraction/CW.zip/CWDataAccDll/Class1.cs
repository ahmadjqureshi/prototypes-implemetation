using System;
using System.IO;
using Microsoft.Data.Odbc;
using Microsoft.Win32;
using System.Windows.Forms;
using System.Collections;
using System.Data;



namespace CWDataAccDll
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class DataAccess
	{
		OdbcConnection myConnection ;
	
		OdbcCommand myCommand ;
	
		OdbcDataReader myReader;
		
		public string accounttitle;		
		public string captured;
		public string companyname;
		public string accountstatus;
		string DirName = "c:\\CaptureWiseFile";
		string temppath;
		int resx,resy;
		bool rowexists = false;
		int totalsignatories = 0;
		SortedList sl;

		public bool ver=false,mod=false,cap=false;

		public string group1,group2,group3,group4,group5,group6,crlimit;
		
		public string signame;
		public int limit;
		public string expirydate;
		public int cosignee;
		public string grp;
		public string signatorystatus;
		ArrayList accnumbers;
		public bool connected = true;

		
		/*
		 ********************************************************
		 Created by Ahmad on 27-02-2004
		 Purpose:
		 Constructor in which database connection is created
		 ********************************************************
		*/
		
		public DataAccess(string constr)
		{
			//
			// TODO: Add constructor logic here
			RegistryKey Hkey = Registry.CurrentUser;
			RegistryKey sHkey = Hkey.OpenSubKey("Environment");
			temppath = (string) sHkey.GetValue("temp");
			sl = new SortedList();
			try
			{
				myConnection = new OdbcConnection(constr);
				myConnection.Open();
				myCommand = myConnection.CreateCommand();
	
				myCommand.CommandText = "create or replace directory MyDir as '"+ DirName +"'";
				myCommand.ExecuteNonQuery();

			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
				connected = false;
			}
			//
		}

		/*
		 ********************************************************
		 Created by Ahmad on 27-02-2004
		 Purpose:
		 Get connection for furthur use
		 ********************************************************
		*/

		public OdbcConnection GetConnection()
		{
			return myConnection;
		}

		/*
		 ********************************************************
		 Created by Ahmad on 27-02-2004
		 Purpose:
		 For checking account number in the database
		 ********************************************************
		*/
		public string ConfirmAccountNo(string accountno)
		{
			
			myCommand.CommandText = "select * from AccountInfo where Account = '" + accountno + "'";
			
			try
			{
				myReader = myCommand.ExecuteReader();
				try
				{
					using (myReader) 
					{
						while(myReader.Read())
						{
							
							captured = myReader.GetString(2);
							if (!myReader.IsDBNull(3))
								companyname = myReader.GetString(3);		
							else
								companyname = "";
							accountstatus = myReader.GetString(5);
							return myReader.GetString(1);
						}
					}
				}
				catch(IndexOutOfRangeException ie)
				{
					MessageBox.Show(ie.Message);
				}
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}

			return "";
		}
		/*
		 ********************************************************
		 Created by Ahmad on 01-03-2004
		 
		 Purpose:
		 Update information in details of account
		 ********************************************************
		*/
		public void UpadteInfo(string info,string accno)
		{
			myCommand.CommandText = "Update AccountInfo set AccountDetails = '" + info + "' where Account = '" + accno +"'";
			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException e)
			{
				MessageBox.Show(e.Message);
			}
		}

		public void CWUpdateMainDetails(string title, string companyname,string accno,string accstatus)
		{
			myCommand.CommandText = "Update AccountInfo set AccountTitle = '" + title + "', CompanyName = '" + companyname+"', AccountStatus = '" + accstatus + "' where Account = '" + accno +"'";
			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException e)
			{
				MessageBox.Show(e.Message);
			}
		}


		public void GetResolution()
		{
			myCommand.CommandText = "select * from Resolution where id = '" + 1 + "'";
			
			try
			{
				myReader = myCommand.ExecuteReader();
				try
				{
					using (myReader) 
					{
						while(myReader.Read())
						{
							resx = myReader.GetInt32(1);
							resy = myReader.GetInt32(2);		
						}
					}
				}
				catch(IndexOutOfRangeException ie)
				{
					MessageBox.Show(ie.Message);
				}
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}

		}

		public int GetResX()
		{
			return resx;
		}

		public int GetResY()
		{
			return resy;
		}

		public void CWUpdateResolution(string Xres,string Yres)
		{
			myCommand.CommandText = "Update Resolution set XRes = '" + Xres + "', YRes = '"+ Yres+"' where id ='1' ";
			try
			{
				int i = myCommand.ExecuteNonQuery();
				
			}
			catch(OdbcException e)
			{
				MessageBox.Show(e.Message);
			}
		}

		public string GetDetails(string accountno)
		{
			myCommand.CommandText = "select AccountDetails from AccountInfo where Account = '" + accountno + "'";
			
			try
			{
				myReader = myCommand.ExecuteReader();
				try
				{
					using (myReader) 
					{
						while(myReader.Read())
						{
							return myReader.GetString(0);
						}
					}
				}
				catch(IndexOutOfRangeException ie)
				{
					MessageBox.Show(ie.Message);
				}
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}
			return "";
				
		}
		

		public void InsertNewRec(string AccountNo , string AccountTitle,string capturedby)
		{
			myCommand.CommandText = "insert into AccountInfo(Account,AccountTitle,CapturedDate,CompanyName,ACCOUNTDETAILS,AccountStatus,CapturedBy) values('"+AccountNo + "','"+ AccountTitle+"','"+ System.DateTime.Now.ToShortDateString() + "','<Company Name>','<Account Details Here>','Pending for verification','"+ capturedby+"')";
			
			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException e)
			{
				MessageBox.Show(e.Message);
			}
		}

		public int GetMaxId(string accountno)
		{
			
			int identity = 0;
			int i=0;

			myCommand.CommandText = "select SigId from Signatories where Account = '" + accountno + "'";
			
			try
			{
				myReader = myCommand.ExecuteReader();
				
				
					try
					{
						using (myReader) 
						{
								while(myReader.Read())
								{
									
									if (identity <	 myReader.GetInt32(0))
									{
										identity = myReader.GetInt32(0);
										
									}
									
									
									i++;
								}
														
						}
					}
					catch(IndexOutOfRangeException ie)
					{
						MessageBox.Show(ie.Message);
					}
				}
		
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}

			return identity;
		}

		public bool checkSignatoryExists(int identity,string accountno)
		{
			myCommand.CommandText = "select SigId from Signatories where Account = '" + accountno + "'";
			
			try
			{
				myReader = myCommand.ExecuteReader();
				
				
				try
				{
					using (myReader) 
					{
						
						while(myReader.Read())
						{
							if (identity ==	 myReader.GetInt32(0))
							{
								return true;
										
							}
						}
														
					}
				}
				catch(IndexOutOfRangeException ie)
				{
					MessageBox.Show(ie.Message);
				}
			}
		
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}

			return false;
		}
		
		public void UpdateSignatory(int identity,string accountno,string signname,string date,int cosignee,int limit,string grp,string sigstatus)
		{
			myCommand.CommandText = "Update Signatories set SIGNATORYNAME = '"+ signname + "', expirydate = '"+ date+"',CosigneeReq = '"+cosignee.ToString()+"',Limit = '"+ limit.ToString()+"',Grp = '"+ grp +"' where SigId = '" + identity.ToString()+"' and  Account = '" + accountno+"'" ;

			try
			{
				int i = myCommand.ExecuteNonQuery();
			}
			catch(OdbcException e)
			{
				MessageBox.Show(e.Message);
			}

		}

		public void EnterNewSignatory(int id,string name,string accountno,string date,int cosignee,int limit,string grp,string sigstatus)
		{
			myCommand.CommandText = "insert into Signatories(SigId,Account ,SignatoryName,expirydate,CoSigneeReq,Limit,Grp,SignatoryStatus) values('"+id.ToString()+ "','"+ accountno+ "','" + name + "', '" +  date  + "','"+ cosignee.ToString() +"','"+limit.ToString()+"','"+ grp+"','Pending for verification')";
			
			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException e)
			{
				MessageBox.Show(e.Message);
			}
		}


		
		public void InsertSign1(string filename,string accno,int identity)
		{
			rowexists = false;
			
			string fileindb = accno + identity.ToString() + "1.jpeg";
			
			FileStream fs = new FileStream(filename,FileMode.Open,FileAccess.Read);
			long len = fs.Length;
			fs.Close();

			
			myCommand.CommandText = "select * from SigSign1 where sigid = '"+identity.ToString()+"' and account = '"+accno+"'";
			try
			{
				myReader = myCommand.ExecuteReader();
				using (myReader)
				{
					while(myReader.Read())
					{
						rowexists = true;
					}
				}
			}
			catch(OdbcException odbcexp)
			{
				MessageBox.Show(odbcexp.Message);
			}

			if (rowexists)
			{
				myCommand.CommandText = "Update SigSign1 set sign1 = " + " BFILENAME('MYDIR', '" + fileindb +"') , SizeSign1 = '" + len.ToString()+ "' where SigId = '" + identity.ToString()+"' and  Account = '" +accno+"'" ;

				try
				{
					int i = myCommand.ExecuteNonQuery();
				
				}
				catch(OdbcException e)
				{
					MessageBox.Show(e.Message);
				}
			}
			else
			{
				myCommand.CommandText = "insert into SigSign1 values('"+identity.ToString()+"','"+accno+"',BFILENAME('MYDIR', '" + fileindb +"'), '"+ len.ToString()+"' )" ;
				try
				{
					int i = myCommand.ExecuteNonQuery();
				
				}
				catch(OdbcException e)
				{
					MessageBox.Show(e.Message);
				}
			}
		}

		public void InsertSign2(string filename,string accno,int identity)
		{
			rowexists = false;
			string fileindb = accno + identity.ToString() + "2.jpeg";
			
			
			FileStream fs = new FileStream(filename,FileMode.Open,FileAccess.Read);
			long len = fs.Length;
			fs.Close();
			
			myCommand.CommandText = "select * from SigSign2 where sigid = '"+identity.ToString()+"' and account = '"+accno+"'";
			try
			{
				myReader = myCommand.ExecuteReader();
				using (myReader)
				{
					while(myReader.Read())
					{
						rowexists = true;
					}
				}
			}
			catch(OdbcException odbcexp)
			{
				MessageBox.Show(odbcexp.Message);
			}

			if (rowexists)
			{
				myCommand.CommandText = "Update SigSign2 set sign2 = " + " BFILENAME('MYDIR', '" + fileindb +"') , SizeSign2 = '" + len.ToString()+ "' where SigId = '" + identity.ToString()+"' and  Account = '" +accno+"'" ;

				try
				{
					int i = myCommand.ExecuteNonQuery();
				
				}
				catch(OdbcException e)
				{
					MessageBox.Show(e.Message);
				}
			}
			else
			{
				myCommand.CommandText = "insert into SigSign2 values('"+identity.ToString()+"','"+accno+"',BFILENAME('MYDIR', '" + fileindb +"'),'"+ len.ToString()+"')" ;
				try
				{
					int i = myCommand.ExecuteNonQuery();
				
				}
				catch(OdbcException e)
				{
					MessageBox.Show(e.Message);
				}
			}
		}


		public void InsertThumbImp(string filename,string accno,int identity)
		{
			rowexists = false;
			string fileindb = accno + identity.ToString() + "3.jpeg";			
			
			
			FileStream fs = new FileStream(filename,FileMode.Open,FileAccess.Read);
			long len = fs.Length;
			fs.Close();
			myCommand.CommandText = "select * from SigThumb  where sigid = '"+identity.ToString()+"' and account = '"+accno+"'";
			try
			{
				myReader = myCommand.ExecuteReader();
				using (myReader)
				{
					while(myReader.Read())
					{
						rowexists = true;
					}
				}
			}
			catch(OdbcException odbcexp)
			{
				MessageBox.Show(odbcexp.Message);
			}
			if (rowexists)
			{
				myCommand.CommandText = "Update SigThumb set ThumbImp = " + " BFILENAME('MYDIR', '" + fileindb +"') , SizeThumb = '" + len.ToString()+ "' where SigId = '" + identity.ToString()+"' and  Account = '" +accno+"'" ;

				try
				{
					int i = myCommand.ExecuteNonQuery();
				
				}
				catch(OdbcException e)
				{
					MessageBox.Show(e.Message);
				}
			}
			else
			{
				myCommand.CommandText = "insert into SigThumb values('"+identity.ToString()+"','"+accno+"',BFILENAME('MYDIR', '" + fileindb +"'),'"+ len.ToString()+"')" ;
				try
				{
					int i = myCommand.ExecuteNonQuery();
				
				}
				catch(OdbcException e)
				{
					MessageBox.Show(e.Message);
				}
			}
		}

		public void InsertPhoto(string filename,string accno,int identity)
		{
			rowexists = false;
			
			string fileindb = accno + identity.ToString() + "4.jpeg";
			
			FileStream fs = new FileStream(filename,FileMode.Open,FileAccess.Read);
			long len = fs.Length;
			fs.Close();
			

			myCommand.CommandText = "select * from SigPhoto  where sigid = '"+identity.ToString()+"' and account = '"+accno+"'";
			try
			{
				myReader = myCommand.ExecuteReader();
				using (myReader)
				{
					while(myReader.Read())
					{
						rowexists = true;
					}
				}
			}
			catch(OdbcException odbcexp)
			{
				MessageBox.Show(odbcexp.Message);
			}

			
			if (rowexists)
			{
				myCommand.CommandText = "Update SigPhoto set Photo = " + " BFILENAME('MYDIR', '" + fileindb +"') , SizePhoto = '" + len.ToString()+ "' where SigId = '" + identity.ToString()+"' and  Account = '" +accno+"'" ;

				try
				{
					int i = myCommand.ExecuteNonQuery();
				}
				catch(OdbcException e)
				{
					MessageBox.Show(e.Message);
				}
			}
			else
			{
				myCommand.CommandText = "insert into SigPhoto values('"+identity.ToString()+"','"+accno+"',BFILENAME('MYDIR', '" + fileindb +"'),'"+ len.ToString()+"')" ;
				try
				{
					int i = myCommand.ExecuteNonQuery();
				}
				catch(OdbcException e)
				{
					MessageBox.Show(e.Message);
				}
			}
		}
		
		public int GetMaxImgId()
		{
			int identity = 0;
			myCommand.CommandText = "select SignImageId from SignImages ";
			
			try
			{
				myReader = myCommand.ExecuteReader();
				
				
				
				try
				{
					using (myReader) 
					{
						
						while(myReader.Read())
						{
							if (identity <	 myReader.GetInt32(0))
							{
								identity = myReader.GetInt32(0);
							}
						}
														
					}
				}
				catch(IndexOutOfRangeException ie)
				{
					MessageBox.Show(ie.Message);
				}
			}
		
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}

			return identity;
		}

		public void InsertImage(int imgid,string account,int sigid,string filename)
		{
			string folderfilename = "c:\\CaptureWiseFile\\"+filename;
			//EncryptImage.ImgEncrypt imgen = new EncryptImage.ImgEncrypt();
			//imgen.EncryptImg("c:\\temp1.jpeg",folderfilename );
			string rsastr="";// = imgen.GetXmlString();
			FileStream fs = new FileStream(folderfilename,FileMode.Open,FileAccess.Read);
			long len = fs.Length;
			fs.Close();

			myCommand.CommandText = "create or replace directory MyDir as '"+ DirName +"'";
			
			
			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException e)
			{
				MessageBox.Show(e.Message);
			}

			

			myCommand.CommandText = "insert into SignImages(SignImageId,SigId,Account,signImage,imagesize,RSAStr)  Values(' "+ imgid.ToString() +"','" + sigid.ToString() + "','" + account + "',"+ " BFILENAME('MYDIR', '" + folderfilename + "'),'" +len.ToString() +"','" + rsastr +"')";
			
			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException e)
			{
				MessageBox.Show(e.Message);
			}

		}

		public SortedList GetSignatories(string accno)
		{
			int i=0;
			sl.Clear();
			
			myCommand.CommandText = "select * from signatories where account = '" +accno +"'";

			try
			{
				myReader = myCommand.ExecuteReader();
				using (myReader)
				{
					while (myReader.Read())
					{
						
						sl.Add((object)i,(object)myReader.GetInt32(0));
						i++;
					}

				}
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}

			return sl;
		}
		
		public void GetSignatoryInfo(int identity,string accno)
		{

			
			myCommand.CommandText = "select * from signatories where sigid = '"+ identity.ToString()+"' and  account = '" +accno +"'";

			try
			{
				myReader = myCommand.ExecuteReader();
				using (myReader)
				{
					if (myReader.Read())
					{
						signame = myReader.GetString(2);
						expirydate = myReader.GetString(3);
						cosignee = myReader.GetInt32(4);
						limit = myReader.GetInt32(5);
						if (myReader.IsDBNull(6))
						{
							grp = "";
						}
						else
							grp = myReader.GetString(6);

						signatorystatus = myReader.GetString(7);					
					}
				}
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}

			
		}

		public int DeleteSignatories(int identity,string accno)
		{
			int NoOfRowsEffected = 0;
			myCommand.CommandText = "delete from signatories where sigid = '"+ identity.ToString()+"' and  account = '" +accno +"'";

			try
			{
				 NoOfRowsEffected = myCommand.ExecuteNonQuery();
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}
			
			myCommand.CommandText = "delete from SigSign1 where sigid = '"+ identity.ToString()+"' and  account = '" +accno +"'";

			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}

			myCommand.CommandText = "delete from SigSign2 where sigid = '"+ identity.ToString()+"' and  account = '" +accno +"'";

			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}


			myCommand.CommandText = "delete from SigThumb where sigid = '"+ identity.ToString()+"' and  account = '" +accno +"'";

			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}

			
			myCommand.CommandText = "delete from SigPhoto where sigid = '"+ identity.ToString()+"' and  account = '" +accno +"'";

			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}

			myCommand.CommandText = "commit";

			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}
			
			return NoOfRowsEffected;
		}
		
		/*
		 * 
		 * Delete Account
		 * */

		public int DeleteAccount(int identity,string accno)
		{
			int NoOfRowsEffected = 0;
			myCommand.CommandText = "delete from signatories where sigid = '"+ identity.ToString()+"' and  account = '" +accno +"'";

			try
			{
				NoOfRowsEffected = myCommand.ExecuteNonQuery();
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}
			
			myCommand.CommandText = "delete from SigSign1 where sigid = '"+ identity.ToString()+"' and  account = '" +accno +"'";

			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}

			myCommand.CommandText = "delete from SigSign2 where sigid = '"+ identity.ToString()+"' and  account = '" +accno +"'";

			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}


			myCommand.CommandText = "delete from SigThumb where sigid = '"+ identity.ToString()+"' and  account = '" +accno +"'";

			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}

			
			myCommand.CommandText = "delete from SigPhoto where sigid = '"+ identity.ToString()+"' and  account = '" +accno +"'";

			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}

			myCommand.CommandText = "commit";

			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}
			
			myCommand.CommandText = "delete from AccountInfo where Account = '" +accno +"'";

			try
			{
				NoOfRowsEffected = myCommand.ExecuteNonQuery();
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}
			return NoOfRowsEffected;
		}

		public bool GetSign1(int identity,string accno)
		{
			
			bool signexists = false;


			myCommand.CommandText = "select sign1,sizesign1 from SigSign1 where sigid = '"+ identity.ToString()+"' and  account = '" +accno +"'";
			int len = 0;
			
			try
			{
				
				myReader = myCommand.ExecuteReader();
				using (myReader)
				{
					while (myReader.Read())
					{
						bool check = myReader.IsDBNull(0);
						
						
						
						
						len =(int) myReader.GetInt32(1);
						signexists = true;
						

						
						

						byte[] getfile = new byte[len];
						myReader.GetBytes(0,0,getfile,0,len);
						
						
						FileStream fs = new FileStream(temppath+"\\tempsign1.jpeg",FileMode.Create,FileAccess.Write);
						
						fs.Write(getfile,0,(int)len);
						fs.Close();
						
						signexists = true;


					}
				}
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}
			return signexists;
		}


		public bool GetSign2(int identity,string accno)
		{
			
			bool signexists = false;


			myCommand.CommandText = "select sign2,sizesign2 from SigSign2 where sigid = '"+ identity.ToString()+"' and  account = '" +accno +"'";
			int len = 0;
			
			try
			{
				
				myReader = myCommand.ExecuteReader();
				using (myReader)
				{
					while (myReader.Read())
					{
						bool check = myReader.IsDBNull(0);
						
						
						
						
						len =(int) myReader.GetInt32(1);
						signexists = true;
						

						
						

						byte[] getfile = new byte[len];
						myReader.GetBytes(0,0,getfile,0,len);
						
						
						FileStream fs = new FileStream(temppath+"\\tempsign2.jpeg",FileMode.Create,FileAccess.Write);
						
						fs.Write(getfile,0,(int)len);
						fs.Close();
						
						signexists = true;


					}
				}
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}
			return signexists;
		}


		public bool GetThumb(int identity,string accno)
		{
			
			bool signexists = false;


			myCommand.CommandText = "select ThumbImp,sizeThumb from SigThumb where sigid = '"+ identity.ToString()+"' and  account = '" +accno +"'";
			int len = 0;
			
			try
			{
				
				myReader = myCommand.ExecuteReader();
				using (myReader)
				{
					while (myReader.Read())
					{
						bool check = myReader.IsDBNull(0);
						
						
						
						
						len =(int) myReader.GetInt32(1);
						signexists = true;
						

						
						

						byte[] getfile = new byte[len];
						myReader.GetBytes(0,0,getfile,0,len);
						
						
						FileStream fs = new FileStream(temppath+"\\tempThumb.jpeg",FileMode.Create,FileAccess.Write);
						
						fs.Write(getfile,0,(int)len);
						fs.Close();
						
						signexists = true;


					}
				}
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}
			return signexists;
		}

		public bool GetPhoto(int identity,string accno)
		{
			bool signexists = false;


			myCommand.CommandText = "select Photo,SizePhoto from SigPhoto where sigid = '"+ identity.ToString()+"' and  account = '" +accno +"'";
			int len = 0;
			
			try
			{
				
				myReader = myCommand.ExecuteReader();
				using (myReader)
				{
					while (myReader.Read())
					{
						bool check = myReader.IsDBNull(0);
						
						
						
						
						len =(int) myReader.GetInt32(1);
						signexists = true;
						

						
						

						byte[] getfile = new byte[len];
						myReader.GetBytes(0,0,getfile,0,len);
						
						
						FileStream fs = new FileStream(temppath+"\\tempphoto.jpeg",FileMode.Create,FileAccess.Write);
						
						fs.Write(getfile,0,(int)len);
						fs.Close();
						
						signexists = true;


					}
				}
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}
			return signexists;
		}
		
		/*
		 * Purpose:
		 * For checking wether Cross Reference Record exists for certain account
		 * */
		public bool CheckSigRef(string accno)
		{
			bool exists = false;

			myCommand.CommandText = " select * from CrossReferences where Account = '" + accno+ "' ";
			try
			{
				myReader = myCommand.ExecuteReader();
				using (myReader)
				{
					if (myReader.Read())
					{
						exists = true;
						return exists;
					}
				}
				
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}
			return exists;
		}

		public void InsertCrossReference(string accno,int rowid,string grp1,string grp2,string grp3,string grp4,string grp5,string grp6,string limit)
		{
			myCommand.CommandText = "insert into CrossReferences values('" + accno + "','" + rowid.ToString() + "','" + grp1 + "','" + grp2 + "','" + grp3 + "','" + grp4 +"','" + grp5 + "','" + grp6 + "','" + limit + "')";

			try
			{
				myCommand.ExecuteNonQuery();
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}
		}

		public void UpdateCrossReference(string accno,int rowid,string grp1,string grp2,string grp3,string grp4,string grp5,string grp6,string limit)
		{
			myCommand.CommandText = "Update CrossReferences set Group1 = '" + grp1 + "', Group2 = '" + grp2 + "', Group3 = '" + grp3 + "', Group4 = '" + grp4 +"', Group5 = '" + grp5 + "', Group6 = '" + grp6 + "',limit = '"+ limit +"' where Account =  '"+ accno + "' and RowNumber = '"+ rowid.ToString() + "'";

			try
			{
				myCommand.ExecuteNonQuery();

			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}
		}

		public void GetCrossReference(string accno,int rowid)
		{
			myCommand.CommandText = "select Group1,Group2,Group3,Group4,Group5,Group6,limit from CrossReferences where account = '" + accno + "' and RowNumber = '" + rowid.ToString() + "'";
			try
			{
				myReader = myCommand.ExecuteReader();
				using (myReader)
				{
					if (myReader.Read())
					{
						if (myReader.IsDBNull(0))
						{
							group1 = "";
						}
						else
						group1 = myReader.GetString(0);

						if (myReader.IsDBNull(1))
						{
							group2 = "";
						}
						else
						group2 = myReader.GetString(1);

						if (myReader.IsDBNull(2))
						{
							group3 = "";
						}
						else
						group3 = myReader.GetString(2);

						if (myReader.IsDBNull(3))
						{
							group4 = "";
						}
						else
						group4 = myReader.GetString(3);
						
						if (myReader.IsDBNull(4))
						{
							group5 = "";
						}
						else
						group5 = myReader.GetString(4);

						if (myReader.IsDBNull(5))
						{
							group6 = "";
						}
						else
							group6 = myReader.GetString(5);
						
						if (myReader.IsDBNull(6))
						{
							crlimit = "";
						}
						else
						crlimit = myReader.GetString(6);
					}
				}
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}
		}

		public bool ConfUser(string username,string domain)
		{
			myCommand.CommandText = "select * from UserRights";
			
			
			ver=false;
			mod=false;
			cap=false;
			bool authorized = false;
			
			try
			{
				myReader = myCommand.ExecuteReader();
							
				
					using (myReader) 
					{
						while(myReader.Read())
						{
							
							if (myReader.GetString(1).Equals(username) && myReader.GetString(2).Equals(domain))
							{
								authorized = true;
								if (!myReader.IsDBNull(3))
								{
									object t = myReader.GetValue(3);
									
									
									int io=Int32.Parse(t.ToString());
									if ( io == 1)
									{
										cap = true;
									}
								}

								if (!myReader.IsDBNull(4))
								{
									object t = myReader.GetValue(4);
									int io=Int32.Parse(t.ToString());
									if (io == 1)
									{
										mod = true;
									}
								}

								if (!myReader.IsDBNull(5))
								{
									object t = myReader.GetValue(5);
									int io=Int32.Parse(t.ToString());
									
									if (io == 1)
									{
										ver = true;
									}
								}
							}
						}
														
					}
				
			}
		
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}

			//return authorized;
			ver=true;
			mod=true;
			cap=true;

			return true;

		}

		public void UpdateModified(string IPAddress,string accountno)
		{
			myCommand.CommandText = "Update AccountInfo set ACCOUNTSTATUS = 'Pending for verification' , LastModifiedByIP = '"+ IPAddress +"' where Account = '"+accountno+"'" ;

			try
			{
				int i = myCommand.ExecuteNonQuery();
			}
			catch(OdbcException e)
			{
				MessageBox.Show(e.Message);
			}			
			
			myCommand.CommandText = "Update Signatories set SIGNATORYSTATUS= 'Pending for verification'  where Account = '"+accountno+"'" ;
			
			try
			{
				int i = myCommand.ExecuteNonQuery();
			}
			catch(OdbcException e)
			{
				MessageBox.Show(e.Message);
			}
		}

		public void UpdateVerified(string IPAddress,string accountno)
		{
			myCommand.CommandText = "Update AccountInfo set LastVerifiedByIP = '"+ IPAddress +"' where Account = '"+accountno+"'" ;

			try
			{
				int i = myCommand.ExecuteNonQuery();
			}
			catch(OdbcException e)
			{
				MessageBox.Show(e.Message);
			}			
		}

		/*
		 * Get Account Numbers for verifcation
		 * */

		public ArrayList GetAccountNos(string username)
		{
			accnumbers = new ArrayList();
			myCommand.CommandText = "select account from AccountInfo where capturedby <> '"+username+"'" ;
			try
			{
				myReader = myCommand.ExecuteReader();
				using (myReader)
				{
					while (myReader.Read())
					{
						accnumbers.Add((object)myReader.GetString(0));
					}
				}
			}
			catch(OdbcException oe)
			{
				MessageBox.Show(oe.Message);
			}
		
			return accnumbers;
		}
		
		/*
		 * Update Account Status while verification
		 * */
		public void UpdateAccountStatus(string status,string accountno)
		{
			myCommand.CommandText = "Update AccountInfo set AccountStatus = '"+ status+"' where Account = '"+accountno+"'" ;

			try
			{
				int i = myCommand.ExecuteNonQuery();
			}
			catch(OdbcException e)
			{
				MessageBox.Show(e.Message);
			}
		}
		/*
		 * Update Signatory Status while verification
		 * */
		public void UpdateSigStatus(string accountno,string status,string identity)
		{
			myCommand.CommandText = "Update Signatories set SignatoryStatus = '"+ status+"' where Account = '"+accountno+"' and SigId = '"+identity+"'" ;

			try
			{
				int i = myCommand.ExecuteNonQuery();
			}
			catch(OdbcException e)
			{
				MessageBox.Show(e.Message);
			}
		}
		
		public void closecon()
		{
			myConnection.Close();
		}

		public void ExecuteNonQuery(string query)
		{
			myCommand.CommandText = query;

			try
			{
				int i = myCommand.ExecuteNonQuery();
			}
			catch(OdbcException e)
			{
				MessageBox.Show(e.Message);
			}
		}

		public int getSignNum(string account,string signo)
		{
			myCommand.CommandText = "select max(signum) as maxsigno from featuresofsig where account='"+account.Trim()+"' and sigid="+signo.Trim();
			int maxsigno=0;
			try
			{
				myReader=myCommand.ExecuteReader();
				if (myReader.Read())
				{
					maxsigno = Convert.ToInt32(myReader["maxsigno"].ToString());
					maxsigno++;
				}
				myReader.Close();
			}
			catch(OdbcException e)
			{
				MessageBox.Show(e.Message);
			}
			if (!(maxsigno >2))
			{
				maxsigno=3;
			}
			return maxsigno;
		}
		
		public DataTable GetDataTable(string sqlqu)
		{
			DataTable dt=new DataTable();

			OdbcDataAdapter oda = new OdbcDataAdapter(sqlqu,myConnection);
			oda.Fill(dt);
			return dt;
		}
	}
}
